# Kai System Installation and Usage Guide

## 1. Introduction

Welcome to the Kai System! This guide will walk you through the installation and basic usage of your new, Flask-free, multi-window Kai system. The system is designed to be as plug-and-play as possible, providing a native Ubuntu dashboard for seamless interaction.

## 2. Prerequisites

Before you begin, ensure your Ubuntu system has the following installed:

*   **Python 3.8+**: The Kai system is developed with Python 3.11, but should be compatible with Python 3.8 and newer.
    You can check your Python version by running:
    ```bash
    python3 --version
    ```
*   **Tkinter**: Tkinter is usually included with Python installations. If you encounter issues related to `tkinter`, you might need to install it:
    ```bash
    sudo apt update
    sudo apt install python3-tk
    ```

## 3. Installation Steps

Follow these steps to install the Kai System:

### Step 3.1: Download and Extract the Kai System Package

1.  You should have received a `kai_system.zip` file. Download this file to your desired location (e.g., your home directory).
2.  Open a terminal and navigate to the directory where you downloaded the zip file.
3.  Extract the contents of the zip file. This will create a directory named `kai_core`.
    ```bash
    unzip kai_system.zip
    ```

### Step 3.2: Navigate to the Kai System Directory

Change your current directory to the extracted `kai_core` directory:

```bash
cd kai_core
```

## 4. Running the Kai System

To start the Kai System with its multi-window dashboard, execute the `launcher.py` script:

```bash
python3 launcher.py
```

Upon successful execution, you should see the Kai System Dashboard GUI appear. You will also see console output indicating the system's initialization and service startup.

## 5. Basic Usage of the Dashboard

The Kai System Dashboard provides a centralized interface for monitoring and interacting with the system. Here are some key features:

*   **System Overview Tab**: Displays overall system status, quick statistics (commands processed, success rate, active squads), and recent activity logs.
*   **Squad Activity Tab**: Shows the status of individual squads (e.g., Engineering, Trading, Legal) and their activity. You can open specialized windows for each squad from here.
*   **Command Interface Tab**: Allows you to enter and execute commands directly. The output of your commands will be displayed in this tab.
*   **Metrics Tab**: Provides detailed system metrics in JSON format.
*   **Menu Bar (File, View, Tools, Help)**:
    *   **File > New Window**: Opens a new general dashboard window.
    *   **Tools > [Squad Name] Window**: Opens a dedicated window for a specific squad (e.g., Engineering Window, Trading Window). These specialized windows allow you to send commands directly to that squad and view its specific output.

### Interacting with Specialized Squad Windows

When you open a specialized squad window (e.g., 


Engineering Window), you will find a command input area specific to that squad. Commands entered here will be routed directly to the respective squad, allowing for focused interaction and task execution.

## 6. Troubleshooting

*   **`ModuleNotFoundError`**: If you encounter this error, ensure you are in the `kai_core` directory when running `launcher.py`, and that all necessary Python packages are installed. While the system aims to be self-contained, some fundamental Python libraries are assumed.
*   **GUI Not Appearing**: If the dashboard GUI does not appear, check the console output for any error messages. Ensure `tkinter` is correctly installed (see Prerequisites).
*   **`Bad file descriptor` or Network Errors**: These errors should largely be resolved as Flask and network dependencies have been removed. If you still encounter them, please report the issue, as it indicates a deeper problem.
*   **LLM Model Not Found**: The system uses a simulated LLM response if the actual LLM model (e.g., `llama3`) is not found at the configured path. This is expected behavior if you haven't set up the LLM models. The system is designed to function without them, but for full AI capabilities, you will need to integrate your LLM models by placing them in the specified paths within the `kai_core/config.py` file.

## 7. Support

If you encounter any issues or have questions, please reach out. Your feedback is valuable for improving the Kai System.


