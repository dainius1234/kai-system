# Kai System Architecture: Tree Graph Representation

This document provides a hierarchical, text-based representation of the Kai System's architecture, outlining its core components and their relationships.

```
Kai System (Core)
├── launcher.py (System Entry Point)
├── kai.py (Main System Orchestrator)
│   ├── EventBus (Central Communication Hub)
│   ├── Audit (Logging and Auditing Layer)
│   ├── Memory (Long-term and Short-term Data Storage)
│   │   └── PathRegistry (Manages System Paths)
│   ├── LLMManager (Manages Language Models and Clusters)
│   ├── Fusion (Signal Fusion and Decision Scoring)
│   ├── Junior (Junior Agent for Remediation and Support)
│   ├── Supervisor (Monitors and Manages Processes)
│   ├── TaskQueue (Manages Task Prioritization and Execution)
│   ├── Parser (Interprets User Commands)
│   ├── VoiceInterface (Optional: Speech-to-Text/Text-to-Speech)
│   ├── PerformanceMonitor (Optional: Tracks System Performance)
│   ├── SurveyQAModule (Handles Survey Data and QA)
│   ├── Router (Routes Commands to appropriate Squads/LLMs)
│   │   └── OrchestrationEngine (Dynamic Routing Logic)
│   └── Dashboard (Native Ubuntu GUI)
│       ├── dashboard.py (Dashboard Backend Logic)
│       └── dashboard_gui.py (Tkinter GUI Implementation)
│
├── Squads (Specialized Agents/Modules)
│   ├── TradingSquad
│   ├── PlannerSquad
│   ├── LegalSquad
│   ├── AdminSquad
│   ├── AccountingSquad
│   ├── IntelSquad
│   ├── DefenseSquad
│   ├── OffenseSquad
│   ├── EcoSquad
│   ├── PrimeSquad
│   ├── DebugSquad
│   ├── EthicsSquad
│   ├── PlannerSubSquad
│   ├── ConstructionPlanningSquad
│   └── EngineeringSquad
│
├── logging (Centralized Logging)
│   └── centralized_logging.py
│
├── config.py (System Configuration)
├── config.json (LLM and other configurations)
├── validate_unified_system.py (System Validation Script)
├── kai_launcher.log (Launcher Logs)
├── kai_stdout.log (Standard Output Logs)
└── kai_stderr.log (Standard Error Logs)
```

## Component Descriptions:

*   **`launcher.py`**: The primary script to start the entire Kai system.
*   **`kai.py`**: The central orchestrator that initializes and manages all core modules and squads. It's the brain of the operation.
*   **`EventBus`**: A publish-subscribe system for inter-component communication, ensuring loose coupling.
*   **`Audit`**: Records all significant system actions, decisions, and events for transparency and debugging.
*   **`Memory`**: Manages the system's knowledge base, including short-term context and long-term persistent data.
*   **`PathRegistry`**: A sub-component of Memory that registers and manages important file paths within the system.
*   **`LLMManager`**: Responsible for loading, managing, and orchestrating various Language Models, including clustering them by task.
*   **`Fusion`**: Integrates signals and data from various sources to form a coherent understanding and generate decision scores.
*   **`Junior`**: A foundational agent assisting with basic tasks, remediation, and support functions.
*   **`Supervisor`**: Oversees the health and operation of other system processes and components.
*   **`TaskQueue`**: Manages the flow and prioritization of tasks throughout the system.
*   **`Parser`**: Interprets natural language commands from the user and translates them into structured, actionable tasks for the system.
*   **`VoiceInterface`**: (Optional) Enables voice-based interaction with the Kai system, handling speech-to-text and text-to-speech.
*   **`PerformanceMonitor`**: (Optional) Collects and analyzes performance metrics of the system and its components.
*   **`SurveyQAModule`**: A specialized module for processing survey data and performing quality assurance.
*   **`Router`**: Directs incoming commands and tasks to the most appropriate squad or LLM based on dynamic routing logic.
*   **`OrchestrationEngine`**: The core intelligence within the Router that determines the optimal path for a task.
*   **`Dashboard`**: The native Ubuntu GUI, providing a multi-window interface for system monitoring, command input, and specialized squad interactions.
*   **`Squads`**: Independent, specialized agents (e.g., Engineering, Trading, Legal) designed to handle specific types of tasks and domains.
*   **`logging`**: Contains the centralized logging mechanism for the entire system.
*   **`config.py` / `config.json`**: Stores system-wide configurations and settings.
*   **`validate_unified_system.py`**: A script used for validating the overall system integrity and functionality.
*   **Log Files (`.log`)**: Store various system outputs and errors for debugging and historical review.


