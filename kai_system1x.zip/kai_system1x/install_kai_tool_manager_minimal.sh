#!/bin/bash
# Kai Tool Manager Installation Script (Minimal Router Edition)
# Usage: sudo ./install_kai_tool_manager_minimal.sh [/opt/kai-system]

set -euo pipefail
trap 'handle_error $? $LINENO' ERR

# ---- Configuration ----
KAI_ROOT="${1:-/opt/kai-system}"
KAI_USER="kai_sys"
ENV_DIR="$KAI_ROOT/env"
BIN_DIR="$KAI_ROOT/bin"
CONFIG_DIR="$KAI_ROOT/config"
LOG_DIR="$KAI_ROOT/logs"
REGISTRY_FILE="$CONFIG_DIR/tool_registry.json"

# ---- Error Handling ----
handle_error() {
    local exit_code=$1
    local line_no=$2
    echo "[ERROR] Script failed with exit code $exit_code at line $line_no." | tee -a "$LOG_DIR/install.log"
    exit $exit_code
}

# ---- Installation Functions ----
create_structure() {
    echo "Creating directory structure..."
    mkdir -p "$KAI_ROOT"
    mkdir -p "$ENV_DIR" "$BIN_DIR" "$CONFIG_DIR" "$LOG_DIR"
    
    # Create initial environment directories as placeholders
    echo "  |- /env/ (for your manually placed programs)"
    mkdir -p "$ENV_DIR/coding"
    mkdir -p "$ENV_DIR/office"
    mkdir -p "$ENV_DIR/engineering"
    mkdir -p "$ENV_DIR/survey"
    mkdir -p "$ENV_DIR/training"
    mkdir -p "$ENV_DIR/accounting"
    mkdir -p "$ENV_DIR/learning"
    
    # Create initial registry file if it doesn\'t exist
    if [ ! -f "$REGISTRY_FILE" ]; then
        echo '{"version":1,"tools":{}}' > "$REGISTRY_FILE"
        echo "  |- Initial tool_registry.json created."
    else
        echo "  |- tool_registry.json already exists, skipping creation."
    fi
}

create_system_user() {
    echo "Creating system user: $KAI_USER..."
    if ! id "$KAI_USER" &>/dev/null; then
        useradd -r -s /usr/sbin/nologin "$KAI_USER"
        echo "  |- User '$KAI_USER' created."
    else
        echo "  |- User '$KAI_USER' already exists, skipping creation."
    fi
    # Ensure proper ownership and permissions for the Kai root directory
    chown -R "$KAI_USER:" "$KAI_ROOT"
    chmod 2750 "$KAI_ROOT"  # Set SGID for group inheritance
    echo "  |- Ownership and permissions set for $KAI_ROOT."
}

install_dependencies() {
    echo "Installing minimal core dependencies (jq)..."
    apt-get update
    apt-get install -y jq
}

create_cli_tool() {
    echo "Creating kai-tool CLI (minimal router)..."
    
    cat > "$BIN_DIR/kai-tool" <<'EOL'
#!/usr/bin/env python3.12
import os
import sys
import json
import subprocess
import logging
from pathlib import Path

# Setup logging
LOG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../logs/tool_manager.log')
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    filename=LOG_FILE
)
logger = logging.getLogger('kai-tool')

class ToolManager:
    def __init__(self, kai_root):
        self.kai_root = Path(kai_root)
        self.registry_file = self.kai_root / 

