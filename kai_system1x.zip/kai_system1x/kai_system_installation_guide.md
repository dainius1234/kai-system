# Kai System Installation Guide: Ubuntu 24.04 LTS with Python 3.12, N8n, Docker, and Nginx

## Introduction

This comprehensive guide provides step-by-step instructions for installing and configuring the Kai System on Ubuntu 24.04 LTS. The setup leverages Python 3.12 for the core Kai functionalities, with N8n for workflow automation, Docker for containerization, and Nginx as a reverse proxy. This guide focuses on a "brains-only" setup, ensuring a streamlined installation process that includes only the essential components of the Kai System as provided in the `kai_system.zip` package.

Authored by Manus AI

## 1. System Preparation: Ubuntu 24.04 LTS

Before proceeding with the Kai System installation, it is crucial to prepare your Ubuntu 24.04 LTS environment. This involves updating system packages, installing essential build tools, and ensuring a clean slate for the installation process.

### 1.1 Update System Packages

It is always recommended to start with an up-to-date system to avoid potential conflicts and ensure compatibility with the latest software versions. Open your terminal and execute the following commands:

```bash
sudo apt update
sudo apt upgrade -y
sudo apt autoremove -y
```

These commands will refresh your package lists, upgrade all installed packages to their latest versions, and remove any unnecessary dependencies that were installed automatically.

### 1.2 Install Essential Build Tools and Dependencies

Certain packages and build tools are required for compiling and installing various software components, including Python dependencies. Install them using the following command:

```bash
sudo apt install -y build-essential libssl-dev zlib1g-dev \
libncurses5-dev libgdbm-dev libnss3-dev libsqlite3-dev \
libreadline-dev libffi-dev curl libbz2-dev
```

This command installs development libraries and tools necessary for Python compilation and other software installations. `build-essential` provides compilers and other tools, while the `lib` packages provide development headers for various functionalities like SSL, compression, and database interaction.

## 2. Python 3.12 Installation and Configuration

Ubuntu 24.04 LTS might come with Python 3.10 or 3.11 by default. For the Kai System, we specifically require Python 3.12. We will install it from source to ensure the latest version and proper configuration.

### 2.1 Download Python 3.12 Source Code

First, navigate to a temporary directory and download the Python 3.12 source code. You can find the latest stable release on the official Python website. As of this guide, we will use a hypothetical stable release version. Always verify the latest stable release on [python.org](https://www.python.org/downloads/source/) before downloading.

```bash
cd /tmp
wget https://www.python.org/ftp/python/3.12.0/Python-3.12.0.tgz
tar -xf Python-3.12.0.tgz
cd Python-3.12.0
```

This sequence of commands downloads the compressed Python source code, extracts it, and navigates into the extracted directory.

### 2.2 Compile and Install Python 3.12

Now, compile and install Python 3.12. We will use the `altinstall` option to prevent overwriting the default system Python installation, which could lead to system instability.

```bash
./configure --enable-optimizations
sudo make altinstall
```

-   `./configure --enable-optimizations`: This command prepares the Python build. `--enable-optimizations` enables profile-guided optimizations, which can significantly improve Python's performance.
-   `sudo make altinstall`: This command compiles and installs Python. `altinstall` ensures that the new Python executable is installed as `python3.12` (and `pip3.12`), leaving the system's default `python3` and `pip3` untouched. This is crucial for system stability.

### 2.3 Verify Python 3.12 Installation

After the installation, verify that Python 3.12 and its package manager, `pip`, are correctly installed and accessible:

```bash
python3.12 --version
pip3.12 --version
```

You should see output similar to `Python 3.12.0` and the corresponding `pip` version. If these commands do not return the expected versions, review the previous steps for any errors.

### 2.4 Create a Virtual Environment for Kai System

It is highly recommended to use a Python virtual environment for the Kai System. This isolates its dependencies from the system-wide Python installation, preventing conflicts and making dependency management cleaner. Create a virtual environment in your desired installation directory (e.g., `/opt/kai-system`):

```bash
sudo mkdir -p /opt/kai-system
cd /opt/kai-system
python3.12 -m venv venv
source venv/bin/activate
```

-   `sudo mkdir -p /opt/kai-system`: Creates the main directory for the Kai System.
-   `cd /opt/kai-system`: Navigates into the newly created directory.
-   `python3.12 -m venv venv`: Creates a virtual environment named `venv` using Python 3.12.
-   `source venv/bin/activate`: Activates the virtual environment. You will notice `(venv)` prepended to your terminal prompt, indicating that the virtual environment is active.

All subsequent Python package installations for the Kai System should be performed while this virtual environment is active. To deactivate it, simply type `deactivate` in the terminal.

## 3. Kai System Core Setup

This section details how to set up the core Kai System files and install its Python dependencies within the virtual environment.

### 3.1 Extract Kai System Files

Assuming you have the `kai_system.zip` file, transfer it to the `/opt/kai-system` directory and extract its contents. If you are already in `/opt/kai-system` from the previous step, you can skip the `cd` command.

```bash
cd /opt/kai-system
sudo cp /path/to/your/kai_system.zip .
sudo unzip kai_system.zip
```

-   `sudo cp /path/to/your/kai_system.zip .`: Copies the zip file to the current directory. Replace `/path/to/your/kai_system.zip` with the actual path to your downloaded zip file.
-   `sudo unzip kai_system.zip`: Extracts all files from the zip archive. This will create the `kai_core` directory and other related files directly within `/opt/kai-system`.

### 3.2 Install Kai System Python Dependencies

With the virtual environment active, install the necessary Python packages for the Kai System. The `kai_system.zip` should contain a `requirements.txt` file or similar that lists all dependencies. If not, you will need to create one based on the Kai System's modules.

For this guide, we will assume a `requirements.txt` file exists within the extracted `kai_core` directory. If it does not, you will need to manually identify and list the dependencies (e.g., `tkinter`, `fpdf`, `sqlite3`, `requests`, `numpy`, `pandas`, `scipy`, `scikit-learn`, `tensorflow`, `torch`, `transformers`, `speechrecognition`, `pyttsx3`, `pyaudio`, `fastapi`, `uvicorn`, `python-multipart`, `python-dotenv`, `psutil`, `matplotlib`, `seaborn`, `plotly`, `reportlab`, `openpyxl`, `beautifulsoup4`, `lxml`, `pytz`, `email-validator`, `python-dateutil`, `python-slugify`, `markdown`, `weasyprint`, `xhtml2pdf`, `pdf2image`, `Pillow`, `tabulate`).

```bash
source /opt/kai-system/venv/bin/activate
pip install -r kai_core/requirements.txt
```

-   `source /opt/kai-system/venv/bin/activate`: Ensures the virtual environment is active.
-   `pip install -r kai_core/requirements.txt`: Installs all Python packages listed in the `requirements.txt` file. If `requirements.txt` is not present, you will need to manually install each dependency using `pip install <package_name>`.

## 4. Docker Installation and Configuration

Docker will be used to containerize N8n, providing an isolated and consistent environment for the workflow automation platform.

### 4.1 Uninstall Old Docker Versions (if any)

First, remove any older, conflicting Docker installations:

```bash
sudo apt remove docker docker-engine docker.io containerd runc
```

### 4.2 Install Docker Engine

Install Docker from the official Docker repository to ensure you get the latest version. Add Docker's official GPG key and set up the repository:

```bash
sudo apt update
sudo apt install -y ca-certificates curl gnupg
sudo install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
sudo chmod a+r /etc/apt/keyrings/docker.gpg

echo \
  "deb [arch=\"$(dpkg --print-architecture)\" signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu \
  \"$(. /etc/os-release && echo "$VERSION_CODENAME")\" stable" | \
sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
sudo apt update
```

Now, install the Docker Engine, Containerd, and Docker Compose:

```bash
sudo apt install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
```

### 4.3 Verify Docker Installation

Verify that Docker Engine is running correctly by running the `hello-world` image:

```bash
sudo docker run hello-world
```

This command downloads a test image and runs it in a container. If successful, you will see a "Hello from Docker!" message.

### 4.4 Manage Docker as a Non-Root User (Optional but Recommended)

To avoid using `sudo` every time you run a Docker command, add your user to the `docker` group:

```bash
sudo usermod -aG docker $USER
newgrp docker
```

-   `sudo usermod -aG docker $USER`: Adds your current user to the `docker` group.
-   `newgrp docker`: Activates the changes to groups. You might need to log out and log back in for the changes to take full effect.

## 5. Nginx Installation and Configuration

Nginx will serve as a reverse proxy, handling incoming web requests and directing them to the appropriate services (Kai System's dashboard, N8n, etc.). This provides a single entry point, enhances security, and allows for easier management of multiple services.

### 5.1 Install Nginx

Install Nginx using `apt`:

```bash
sudo apt install -y nginx
```

### 5.2 Configure Nginx as a Reverse Proxy

We will create an Nginx configuration file for the Kai System. This configuration will typically proxy requests to the Kai Dashboard (which will run on a specific port) and N8n (also running on a specific port).

Create a new Nginx configuration file (e.g., `/etc/nginx/sites-available/kai_system`):

```bash
sudo nano /etc/nginx/sites-available/kai_system
```

Add the following content to the file. **Note:** You will need to adjust the `proxy_pass` directives to match the actual ports where your Kai Dashboard and N8n instances will be running. For example, if Kai Dashboard runs on `localhost:8000` and N8n on `localhost:5678`.

```nginx
server {
    listen 80;
    server_name your_domain_or_ip;

    location /kai/ {
        proxy_pass http://127.0.0.1:8000/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    location /n8n/ {
        proxy_pass http://127.0.0.1:5678/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # Optional: Serve static files directly if your Kai Dashboard has a static build
    # location /static/ {
    #     alias /opt/kai-system/dashboard/static/;
    #     expires 30d;
    #     access_log off;
    #     log_not_found off;
    # }
}
```

-   Replace `your_domain_or_ip` with your server's domain name or IP address.
-   The `location /kai/` block proxies requests starting with `/kai/` to your Kai Dashboard.
-   The `location /n8n/` block proxies requests starting with `/n8n/` to your N8n instance.

Save and close the file (Ctrl+X, Y, Enter).

### 5.3 Enable Nginx Configuration and Restart

Create a symbolic link from your `sites-available` configuration to `sites-enabled` to activate it, then test the Nginx configuration and restart the service:

```bash
sudo ln -s /etc/nginx/sites-available/kai_system /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
sudo systemctl enable nginx
```

-   `sudo ln -s ...`: Creates the symbolic link.
-   `sudo nginx -t`: Tests the Nginx configuration for syntax errors. If there are no errors, you will see `test is successful`.
-   `sudo systemctl restart nginx`: Restarts the Nginx service to apply the new configuration.
-   `sudo systemctl enable nginx`: Ensures Nginx starts automatically on system boot.

## 6. N8n Installation via Docker Compose

We will use Docker Compose to set up N8n, which simplifies the deployment and management of multi-container Docker applications. This approach is recommended for N8n as it handles database setup and other dependencies.

### 6.1 Create N8n Docker Compose File

Navigate to a suitable directory for your Docker Compose files (e.g., `/opt/n8n`) and create a `docker-compose.yml` file:

```bash
sudo mkdir -p /opt/n8n
cd /opt/n8n
sudo nano docker-compose.yml
```

Add the following content to the `docker-compose.yml` file. This configuration sets up N8n with a PostgreSQL database for persistent data storage.

```yaml
version: '3.8'

services:
  n8n:
    image: n8n.io/n8n
    restart: always
    ports:
      - "5678:5678" # Expose N8n on port 5678
    environment:
      - DB_TYPE=postgresdb
      - DB_POSTGRESDB_HOST=postgresql
      - DB_POSTGRESDB_PORT=5432
      - DB_POSTGRESDB_DATABASE=n8n
      - DB_POSTGRESDB_USER=n8n
      - DB_POSTGRESDB_PASSWORD=n8n
      - N8N_BASIC_AUTH_ACTIVE=true
      - N8N_BASIC_AUTH_USER=user
      - N8N_BASIC_AUTH_PASSWORD=password
      - WEBHOOK_URL=http://your_domain_or_ip/n8n/
      - N8N_HOST=localhost
      - N8N_PORT=5678
      - N8N_PROTOCOL=http
    volumes:
      - ~/.n8n:/home/node/.n8n
    depends_on:
      - postgresql

  postgresql:
    image: postgres:13
    restart: always
    environment:
      - POSTGRES_DB=n8n
      - POSTGRES_USER=n8n
      - POSTGRES_PASSWORD=n8n
    volumes:
      - pg_data:/var/lib/postgresql/data

volumes:
  pg_data:
```

**Important Considerations for N8n Configuration:**

-   **`ports: - 


      - "5678:5678"`: This maps port 5678 on your host machine to port 5678 inside the N8n container. If you change this, remember to update the Nginx configuration accordingly.
-   **`environment`**: These variables configure N8n and its connection to the PostgreSQL database. 
    -   `N8N_BASIC_AUTH_USER` and `N8N_BASIC_AUTH_PASSWORD`: **Change these to strong, unique credentials immediately.**
    -   `WEBHOOK_URL`: Replace `your_domain_or_ip` with your actual domain or IP address that Nginx is configured to use. This is crucial for N8n webhooks to function correctly.
-   **`volumes`**: The `~/.n8n:/home/node/.n8n` volume ensures that your N8n data (workflows, credentials, etc.) persists on your host machine even if the container is removed or recreated. `pg_data` is a named volume for PostgreSQL data.

Save and close the file (Ctrl+X, Y, Enter).

### 6.2 Start N8n with Docker Compose

From the directory containing your `docker-compose.yml` file (`/opt/n8n`), start N8n in detached mode:

```bash
sudo docker compose up -d
```

-   `sudo docker compose up -d`: This command builds (if necessary) and starts the services defined in your `docker-compose.yml` in the background. You can check the status of your containers with `sudo docker compose ps`.

### 6.3 Access N8n

Once N8n is running, you should be able to access its web interface through the Nginx reverse proxy. Open your web browser and navigate to `http://your_domain_or_ip/n8n/`. You will be prompted for the basic authentication credentials you set in the `docker-compose.yml` file.

## 7. Running the Kai System and N8n Integration

With all components installed, this section outlines how to run the Kai System and integrate it with N8n for advanced workflow automation.

### 7.1 Running the Kai System

Navigate to your Kai System installation directory and activate its virtual environment. Then, you can run the `launcher.py` script to start the Kai System.

```bash
cd /opt/kai-system
source venv/bin/activate
python3.12 launcher.py
```

This will start the Kai System, including its native Ubuntu dashboard. You should see output in your terminal indicating the system's initialization and status.

### 7.2 Integrating Kai System with N8n

The Kai System is designed to expose API endpoints or webhooks for interaction with external automation tools like N8n. While the Kai System has moved away from Flask for its internal backend, it can still expose functionalities that N8n can consume.

**Method 1: Using Kai's Internal Webhooks (Recommended for "Brains Only" Setup)**

The Kai System has an internal webhook mechanism that N8n can trigger. This is the most direct way to integrate without needing to set up a separate API layer for Kai.

1.  **Identify Kai's Webhook Endpoints**: The Kai System's `eventbus` and `router` can be configured to listen for specific events or commands via internal webhooks. You will need to consult the `kai_core/webhooks/n8n_trigger.py` (if present) or the `EventBus` and `Router` implementations in `kai.py` to understand the exact webhook structure and expected payloads.

2.  **Create an N8n Workflow**: In N8n, create a new workflow. Start with a "Webhook" node. Configure this node to listen for incoming requests. The URL provided by this Webhook node will be the target for Kai to send data to.

3.  **Configure Kai to Send Data to N8n**: Within the Kai System's code (e.g., in a squad's `handle_command` method or a specific event handler), you will need to add logic to send an HTTP POST request to the N8n Webhook URL. This can be done using Python's `requests` library.

    Example Python snippet within Kai (conceptual):

    ```python
    import requests
    
    n8n_webhook_url = "YOUR_N8N_WEBHOOK_URL_FROM_N8N_NODE"
    payload = {"kai_event": "command_processed", "data": {"command": "analyze market", "result": "..."}}
    
    try:
        response = requests.post(n8n_webhook_url, json=payload)
        if response.status_code == 200:
            self._log_and_notify("Successfully sent data to N8n.")
        else:
            self._log_and_notify(f"Failed to send data to N8n: {response.status_code} - {response.text}", level=\'ERROR\')
    except Exception as e:
        self._log_and_notify(f"Error sending data to N8n: {e}", level=\'ERROR\')
    ```

4.  **Process Data in N8n**: After the Webhook node in N8n, you can add other nodes (e.g., "Code" node for Python processing, "HTTP Request" node to interact with external APIs, or various service-specific nodes) to process the data received from Kai.

**Method 2: Exposing Kai Functionality via a Lightweight Python Web Server (e.g., FastAPI)**

While the Kai System's dashboard handles local backend functionalities, for N8n to directly trigger specific Kai commands, you might consider running a very lightweight, dedicated FastAPI application within the Kai System's virtual environment. This FastAPI app would expose a minimal API that N8n can call.

1.  **Create a FastAPI Application**: Inside your `/opt/kai-system` directory, create a new Python file (e.g., `kai_api.py`) with a simple FastAPI application.

    ```python
    # kai_api.py
    from fastapi import FastAPI
    from pydantic import BaseModel
    import uvicorn
    import sys
    import os

    # Add kai_core to sys.path
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), 'kai_core')))

    from kai import Kai

    app = FastAPI()
    kai_instance = Kai(enable_voice=False, enable_monitoring=False) # Initialize Kai without voice/monitoring for API

    class CommandRequest(BaseModel:
        command: str

    @app.post("/execute_kai_command/")
    async def execute_kai_command(request: CommandRequest):
        response, success, confidence, scorecard = kai_instance.run_command(request.command)
        return {"response": response, "success": success, "confidence": confidence, "scorecard": scorecard}

    if __name__ == "__main__":
        uvicorn.run(app, host="0.0.0.0", port=8001) # Run on a different port than the dashboard
    ```

2.  **Install FastAPI and Uvicorn**: Ensure these are installed in your Kai virtual environment:

    ```bash
    source /opt/kai-system/venv/bin/activate
    pip install fastapi uvicorn
    ```

3.  **Run the FastAPI Application**: You can run this FastAPI application in the background or as a separate service.

    ```bash
    cd /opt/kai-system
    source venv/bin/activate
    nohup python3.12 kai_api.py > kai_api.log 2>&1 &
    ```

4.  **Configure Nginx (if using)**: If you want Nginx to proxy requests to this FastAPI application, add another `location` block to your Nginx configuration (e.g., `/etc/nginx/sites-available/kai_system`):

    ```nginx
    location /kai_api/ {
        proxy_pass http://127.0.0.1:8001/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
    ```

    Remember to restart Nginx after modifying its configuration.

5.  **Create an N8n Workflow to Call Kai API**: In N8n, use an "HTTP Request" node to call the FastAPI endpoint (e.g., `http://your_domain_or_ip/kai_api/execute_kai_command/`).

## 8. Post-Installation and Maintenance

### 8.1 System Updates

Regularly update your Ubuntu system and Python packages to ensure security and access to the latest features:

```bash
sudo apt update && sudo apt upgrade -y
cd /opt/kai-system
source venv/bin/activate
pip install --upgrade pip
pip install --upgrade -r kai_core/requirements.txt # If you have a requirements.txt
```

For Docker containers, you can update N8n by pulling the latest image and recreating the container:

```bash
cd /opt/n8n
sudo docker compose pull
sudo docker compose up -d
```

### 8.2 Troubleshooting

-   **Check Logs**: Always start by checking the logs for Kai System (`kai_stdout.log`, `kai_stderr.log`, and any logs generated by the Kai System's `Audit` layer), Nginx (`/var/log/nginx/error.log`, `/var/log/nginx/access.log`), and Docker containers (`sudo docker logs <container_name_or_id>`).
-   **Firewall**: Ensure your firewall (UFW) is configured to allow traffic on ports 80 (HTTP), 443 (HTTPS, if configured), and any other ports your services are directly exposed on.
-   **Permissions**: Verify that the Kai System files and directories have the correct permissions.

## References

[1] Python.org. (n.d.). *Python Source Releases*. Retrieved from [https://www.python.org/downloads/source/](https://www.python.org/downloads/source/)
[2] Docker Documentation. (n.d.). *Install Docker Engine on Ubuntu*. Retrieved from [https://docs.docker.com/engine/install/ubuntu/](https://docs.docker.com/engine/install/ubuntu/)
[3] Nginx Documentation. (n.d.). *Installing NGINX*. Retrieved from [https://nginx.org/en/docs/install.html](https://nginx.org/en/docs/install.html)
[4] N8n Documentation. (n.d.). *Installation via Docker Compose*. Retrieved from [https://docs.n8n.io/getting-started/installation/docker-compose/](https://docs.n8n.io/getting-started/installation/docker-compose/)
[5] FastAPI Documentation. (n.d.). *Deployment*. Retrieved from [https://fastapi.tiangolo.com/deployment/](https://fastapi.tiangolo.com/deployment/)


