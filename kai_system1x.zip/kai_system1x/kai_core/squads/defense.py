import time
import threading
import logging

class DefenseSquad:
    """
    DefenseSquad: Cybersecurity defense and resilience unit.
    - Real-time and scheduled threat monitoring: anomalies, malware, intrusion.
    - Automated incident response: containment, quarantine, escalation, notification.
    - Integrates with Junior and DebugSquad for repair and diagnostics.
    - Dashboard/REST friendly: exposes status, history, and metrics.
    - Threat simulation/injection for blue team drills.
    - Root cause analysis and replay.
    """

    def __init__(
        self, event_bus, audit_layer, memory, llm_manager, fusion_engine,
        junior_agent=None, debug_squad=None, logger=None, notification_manager=None
    ):
        self.event_bus = event_bus
        self.audit_layer = audit_layer
        self.memory = memory
        self.llm_manager = llm_manager
        self.fusion_engine = fusion_engine
        self.junior_agent = junior_agent
        self.debug_squad = debug_squad
        self.logger = logger or logging.getLogger("DefenseSquad")
        self.notification_manager = notification_manager
        self.incident_history = []
        self.status = {
            "active": True,
            "last_threat": None,
            "last_action": None,
            "incidents": 0,
            "escalations": 0,
            "quarantines": 0,
            "notified": 0,
            "detections": 0,
        }
        self.active_monitors = {}
        self._tracker_threads = {}
        self.logger.info("DefenseSquad: Initialized as advanced security defense unit.")

    # --- Dashboard/REST API Methods ---
    def get_status(self):
        return dict(self.status)

    def get_incident_history(self, typ=None, limit=50):
        filtered = [e for e in reversed(self.incident_history) if (typ is None or e.get('type') == typ)]
        return filtered[:limit]

    # --- Threat Monitoring & Simulation (background or single-shot) ---
    def monitor_threats(self, types=None, continuous=False, interval=15, max_checks=None):
        """
        Monitor for threats (anomalies, malware, intrusion). If continuous, runs in background.
        """
        types = types or ["anomaly", "malware", "intrusion"]
        def monitor_loop(threat_type):
            checks = 0
            while not self.active_monitors.get(threat_type, {}).get("stop", False) and (max_checks is None or checks < max_checks):
                threat = self._real_threat_check(threat_type)
                if threat:
                    self._handle_threat(threat_type, threat)
                    break
                checks += 1
                time.sleep(interval)
            self.active_monitors.pop(threat_type, None)

        result = []
        for threat_type in types:
            if continuous:
                self.active_monitors[threat_type] = {"stop": False}
                t = threading.Thread(target=monitor_loop, args=(threat_type,), daemon=True)
                t.start()
                self._tracker_threads[threat_type] = t
                msg = f"Started continuous threat monitoring for {threat_type}"
            else:
                threat = self._real_threat_check(threat_type)
                if threat:
                    self._handle_threat(threat_type, threat)
                msg = f"Checked {threat_type} once: {'Threat detected: ' + threat if threat else 'Secure'}"
            self.status["last_action"] = msg
            result.append(msg)
        return result if len(result) > 1 else result[0]

    def stop_monitoring(self, threat_type):
        if threat_type in self.active_monitors:
            self.active_monitors[threat_type]["stop"] = True
            self.logger.info(f"Stopped monitoring {threat_type}")
            t = self._tracker_threads.pop(threat_type, None)
            if t:
                t.join(timeout=5)
            msg = f"Stopped monitoring {threat_type}"
        else:
            msg = f"No active monitor for {threat_type}"
        self.status["last_action"] = msg
        return msg

    def _real_threat_check(self, threat_type):
        # Placeholder for real detection logic (SIEM, logs, IDS, etc)
        # Integrate with your SIEM/logs here.
        return None

    # --- Detection Commands (single run/task) ---
    def detect_anomalies(self):
        return self._detect_helper("anomaly")

    def detect_malware(self, scan_path="system"):
        return self._detect_helper("malware", scan_path=scan_path)

    def detect_intrusion_attempts(self):
        return self._detect_helper("intrusion")

    def _detect_helper(self, typ, scan_path=None):
        msg = f"DefenseSquad: Detecting {typ}..."
        self.logger.info(msg)
        audit_type = {
            "anomaly": "anomaly_detection",
            "malware": "malware_detection",
            "intrusion": "intrusion_detection"
        }.get(typ, "defense_detection")
        details = {"scan_path": scan_path} if scan_path else {}
        self._log_and_audit(msg, {"type": audit_type, "details": details or f"Initiating {typ} scan."})
        self.event_bus.publish("defense_event", {"action": f"{typ}_scan_initiated", **details})
        # Implement real detection logic here
        detected = None
        self.status["detections"] += 1
        if detected:
            self.logger.info(f"DefenseSquad: {detected}")
            self._handle_threat(typ, detected)
            return True, detected
        else:
            self.logger.info(f"DefenseSquad: No {typ} detected.")
            return False, f"No {typ}."

    # --- Incident Response & Orchestration ---
    def _handle_threat(self, typ, threat):
        self.status["last_threat"] = threat
        incident = {"type": typ, "threat": threat, "ts": time.time()}
        self.status["incidents"] += 1
        self.status["last_action"] = f"Threat ({typ}): {threat}"
        self.incident_history.append(incident)
        self.logger.info(f"DefenseSquad: Threat detected ({typ}): {threat}")
        self._log_and_audit(f"Threat detected: {threat}", {
            "type": "defense_threat_detected",
            "details": {"threat_type": typ, "threat": threat}
        })
        self.event_bus.publish("defense_event", {
            "action": "threat_detected",
            "threat_type": typ,
            "threat": threat
        })
        # Automated response
        self.initiate_containment(threat)
        self.escalate_to_operator_if_critical(typ, threat)
        self.invoke_junior_for_repair(typ, threat)
        self.invoke_debug_squad_for_analysis(typ, threat)

    def initiate_containment(self, threat_details):
        self.logger.info(f"DefenseSquad: Initiating containment for threat: {threat_details}...")
        self.status["quarantines"] += 1
        self._log_and_audit("Containment action", {"type": "containment_action", "details": {"threat": threat_details}})
        self.event_bus.publish("defense_event", {"action": "containment_initiated", "threat": threat_details})
        prompt = f"Propose containment strategies for the detected threat: {threat_details}"
        response, is_valid, confidence = self.llm_manager.get_llm_response("commandr", prompt, "containment_strategy")
        self.logger.info(f"DefenseSquad: Containment strategy (LLM): {str(response)[:60]}...")
        return response, is_valid, confidence

    def escalate_to_operator_if_critical(self, typ, threat):
        if "unauthorized" in threat.lower() or "critical" in threat.lower():
            self.status["escalations"] += 1
            msg = f"DefenseSquad: Escalating to operator - {threat}"
            self.logger.warning(msg)
            self._log_and_audit(msg, {"type": "defense_escalation", "details": {"threat_type": typ, "threat": threat}})
            if self.notification_manager:
                self.notification_manager.notify("Defense Alert", f"Critical threat: {threat}")
            self.status["notified"] += 1
            self.event_bus.publish("defense_event", {
                "action": "escalation",
                "threat_type": typ,
                "threat": threat
            })

    def invoke_junior_for_repair(self, typ, threat):
        if self.junior_agent:
            self.logger.info(f"DefenseSquad: Invoking Junior for repair ({typ}) due to: {threat}")
            self.junior_agent.trigger_self_repair(typ, threat)

    def invoke_debug_squad_for_analysis(self, typ, threat):
        if self.debug_squad:
            self.logger.info(f"DefenseSquad: Invoking DebugSquad for analysis of {typ} threat: {threat}")
            self.debug_squad.suggest_realtime_fix(threat)

    # --- RCA, Simulation, and Operator Tools ---
    def root_cause_analysis(self, typ, incident_time=None):
        cause = f"Simulated root cause for {typ} at {incident_time or 'recent event'}: misconfigured firewall."
        self.logger.info(f"DefenseSquad: Root cause analysis for {typ}: {cause}")
        self.incident_history.append({"event": "root_cause", "type": typ, "cause": cause, "ts": time.time()})
        return cause

    def notify_operator(self, subject, message):
        if self.notification_manager:
            self.notification_manager.notify(subject, message)
            self.status["notified"] += 1
        self.logger.warning(f"DefenseSquad: Notifying operator - {subject}: {message}")

    # --- Unified Command Entry Point ---
    def execute(self, command_details):
        task = command_details.get("task", "")
        details = command_details.get("details", "")

        if "detect anomalies" in details.lower():
            success, msg = self.detect_anomalies()
            scorecard = self.fusion_engine.fuse_signals({"success_probability": 1.0 if success else 0.5, "cost_estimate": 0.03, "risk_assessment": 0.1 if success else 0.5})
            return msg, success, 1.0 if success else 0.5, scorecard
        elif "detect malware" in details.lower():
            scan_path = details.split("detect malware in ")[-1].strip() if "in" in details.lower() else "system"
            success, msg = self.detect_malware(scan_path)
            scorecard = self.fusion_engine.fuse_signals({"success_probability": 1.0 if success else 0.5, "cost_estimate": 0.05, "risk_assessment": 0.2 if success else 0.7})
            return msg, success, 1.0 if success else 0.5, scorecard
        elif "detect intrusion" in details.lower():
            success, msg = self.detect_intrusion_attempts()
            scorecard = self.fusion_engine.fuse_signals({"success_probability": 1.0 if success else 0.5, "cost_estimate": 0.04, "risk_assessment": 0.3 if success else 0.8})
            return msg, success, 1.0 if success else 0.5, scorecard
        elif "monitor" in details.lower():
            types = command_details.get("types") or []
            result = self.monitor_threats(types=types, continuous=command_details.get("continuous", False), interval=command_details.get("interval", 15), max_checks=command_details.get("max_checks"))
            return f"DefenseSquad: Threat monitoring: {result}", True, 1.0, {"success_probability": 1.0, "overall_score": 1.0}
        elif "initiate containment" in details.lower():
            threat_details = details.split("initiate containment for ")[-1].strip()
            response, is_valid, confidence = self.initiate_containment(threat_details)
            scorecard = self.fusion_engine.fuse_signals({"llm_confidence": confidence, "llm_validity": is_valid, "task_complexity": 0.8})
            return response, is_valid, confidence, scorecard
        elif "status" in details.lower():
            return self.get_status(), True, 1.0, {}
        elif "history" in details.lower():
            return self.get_incident_history(command_details.get("type"), command_details.get("limit", 50)), True, 1.0, {}
        elif "root cause" in details.lower():
            cause = self.root_cause_analysis(command_details.get("type", "unknown"), command_details.get("incident_time"))
            return cause, True, 1.0, {}
        elif "notify" in details.lower():
            self.notify_operator(command_details.get("subject", "Defense Alert"), command_details.get("message", ""))
            return "Operator notified.", True, 1.0, {}
        else:
            return "DefenseSquad: Understood. Performing general defense tasks.", True, 0.8, {
                "success_probability": 0.8, "cost_estimate": 0.02, "risk_assessment": 0.1, "overall_score": 0.7
            }

    def _log_and_audit(self, message, audit_data):
        self.logger.info(message)
        if self.audit_layer:
            self.audit_layer.log(audit_data)
