import time
import threading
import logging

class PrimeSquad:
    """
    PrimeSquad: Mission command, strategic fusion, and orchestration layer.
    - Executes and oversees master strategies, cross-squad and EcoSquad coordination, outcome evaluation.
    - Pulls real-time context from all squads for deep risk fusion and strategy validation.
    - Background monitoring for strategic anomalies, red flags, and missed goals—auto-notifies and escalates.
    - Dashboard/GUI ready: exposes status, live event feed, history, scorecards, and unified entry for all actions.
    - Proactively suggests strategy corrections and signals to PlannerSquad if outcomes deviate.
    """

    def __init__(
        self, event_bus, audit_layer, memory, llm_manager, fusion_engine, eco_squad,
        planner_squad=None, admin_squad=None, accounting_squad=None, construction_squad=None, trading_squad=None, legal_squad=None,
        notification_manager=None, logger=None
    ):
        self.event_bus = event_bus
        self.audit_layer = audit_layer
        self.memory = memory
        self.llm_manager = llm_manager
        self.fusion_engine = fusion_engine
        self.eco_squad = eco_squad
        self.planner_squad = planner_squad
        self.admin_squad = admin_squad
        self.accounting_squad = accounting_squad
        self.construction_squad = construction_squad
        self.trading_squad = trading_squad
        self.legal_squad = legal_squad
        self.notification_manager = notification_manager
        self.logger = logger or logging.getLogger("PrimeSquad")
        self.status = {
            "last_action": None,
            "last_result": None,
            "tasks_run": 0,
            "alerts_sent": 0,
            "active_background": False,
            "last_scorecard": None,
        }
        self.history = []
        self._stop_tracking = False
        self._tracker_thread = None
        self.logger.info("PrimeSquad: Initialized as primary mission/strategy layer.")

    # --- Master Strategy Execution ---
    def execute_master_strategy(self, strategy_details):
        self.logger.info(f"PrimeSquad: Executing master strategy: {strategy_details}...")
        self._log_and_audit("Master Strategy Execution", {"type": "master_strategy_execution", "details": {"strategy": strategy_details}})
        self.event_bus.publish("prime_event", {"action": "strategy_initiated", "strategy": strategy_details})

        # Pull cross-squad context for fusion and validation
        context = self._cross_squad_context()
        self.logger.info("PrimeSquad: Pulling cross-squad context for strategy fusion...")

        # EcoSquad validation
        self.logger.info("PrimeSquad: Coordinating with EcoSquad for validation...")
        eco_results, eco_valid, eco_confidence = self.eco_squad.run_parallel_squads(f"validate strategy: {strategy_details}")
        self.logger.info(f"PrimeSquad: EcoSquad validation results: {eco_results}")

        # Master execution with LLM
        prompt = (
            f"Execute the master strategy: {strategy_details}. "
            f"Consider cross-squad context:\n{context}\n"
            f"Evaluate outcome, escalate risks, recommend next actions."
        )
        response, is_valid, confidence = self.llm_manager.get_llm_response("llama3", prompt, "strategy_execution")
        self.logger.info(f"PrimeSquad: Strategy execution outcome (LLM): {str(response)[:80]}...")

        # Fuse all signals
        scorecard = self.fusion_engine.fuse_signals({
            "llm_confidence": confidence,
            "llm_validity": is_valid,
            "task_complexity": 0.9,
            "eco_validation_validity": eco_valid,
            "eco_validation_confidence": eco_confidence,
        })
        self.status["last_scorecard"] = scorecard
        self._update_status("Master strategy executed", response)
        self._add_history("master_strategy", {
            "strategy": strategy_details,
            "result": response,
            "eco_result": eco_results,
            "valid": is_valid,
            "confidence": confidence,
            "eco_valid": eco_valid,
            "eco_confidence": eco_confidence,
            "scorecard": scorecard
        })
        # Notify operator/GUI on low confidence or major deviation
        if not is_valid or confidence < 0.7 or not eco_valid:
            self._notify_operator("Master strategy flagged", f"{response} | Eco validation: {eco_results}")

        # Suggest correction to PlannerSquad if deviation detected
        if self.planner_squad and (not is_valid or not eco_valid):
            try:
                self.planner_squad.execute({
                    "task": "strategy_correction",
                    "details": f"PrimeSquad suggests review/correction for: {strategy_details} | {response}"
                })
            except Exception as e:
                self.logger.error(f"PrimeSquad: Failed to escalate to PlannerSquad: {e}")

        return response, is_valid, confidence, scorecard

    # --- Background Strategic Monitoring ---
    def start_background_tracking(self, interval=180):
        if self._tracker_thread and self._tracker_thread.is_alive():
            self.logger.info("PrimeSquad: Background tracking already running.")
            return
        self._stop_tracking = False
        def tracker():
            while not self._stop_tracking:
                try:
                    self.background_check()
                except Exception as e:
                    self.logger.error(f"PrimeSquad: Error in background_check: {e}")
                time.sleep(interval)
        self._tracker_thread = threading.Thread(target=tracker, daemon=True)
        self._tracker_thread.start()
        self.status["active_background"] = True
        self.logger.info("PrimeSquad: Background strategic tracking started.")

    def stop_background_tracking(self):
        self._stop_tracking = True
        self.status["active_background"] = False
        if self._tracker_thread:
            self._tracker_thread.join(timeout=5)
        self.logger.info("PrimeSquad: Background tracking stopped.")

    def background_check(self):
        """
        Periodically check for anomalies, red flags, missed goals, and push to dashboard/events.
        """
        now = time.time()
        issues = []
        # Legal/compliance risk signal
        if self.legal_squad and getattr(self.legal_squad, "get_status", None):
            legal_status = self.legal_squad.get_status()
            if "risk" in str(legal_status.get("last_result", "")).lower():
                issues.append("Legal/compliance risk flagged.")
                self._notify_operator("Strategic Risk", legal_status.get("last_result"))
        # Missed goals or negative signals from planner
        if self.planner_squad and getattr(self.planner_squad, "get_status", None):
            planner_status = self.planner_squad.get_status()
            if planner_status.get("last_result") and "fail" in str(planner_status.get("last_result")).lower():
                issues.append("PlannerSquad reported a failure.")
                self._notify_operator("Planner Failure", planner_status.get("last_result"))
        # Add more squad checks as needed...

        self.status["last_action"] = "Background check"
        self.status["last_result"] = f"Strategic issues: {issues if issues else 'none'}"
        self.status["tasks_run"] += 1
        self.status["last_check"] = now
        self._add_history("background_check", {"issues": issues, "ts": now})
        self.event_bus.publish("prime_event", {"action": "background_check", "issues": issues, "timestamp": now})

    def _cross_squad_context(self):
        """Aggregate context from connected squads for strategy and risk fusion."""
        context = {}
        if self.planner_squad: context['planner'] = self.planner_squad.get_status()
        if self.admin_squad: context['admin'] = self.admin_squad.get_status()
        if self.accounting_squad: context['accounting'] = self.accounting_squad.get_status()
        if self.construction_squad: context['construction'] = self.construction_squad.get_status()
        if self.trading_squad: context['trading'] = self.trading_squad.get_status()
        if self.legal_squad: context['legal'] = self.legal_squad.get_status()
        if self.eco_squad and hasattr(self.eco_squad, "get_status"):
            context['eco'] = self.eco_squad.get_status()
        return context

    # --- Status/History/Replay/Notification ---
    def get_status(self):
        return dict(self.status)

    def get_history(self, kind=None, limit=50):
        filtered = [e for e in reversed(self.history) if (kind is None or e.get('type') == kind)]
        return filtered[:limit]

    def replay_history(self, kind=None):
        self.logger.info("PrimeSquad: Replaying prime squad history...")
        filtered = [e for e in self.history if (kind is None or e.get('type') == kind)]
        for event in filtered:
            print(f"  [{time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(event['ts']))}] {event}")

    def _notify_operator(self, subject, message):
        if self.notification_manager:
            self.notification_manager.notify(subject, message)
            self.status["alerts_sent"] += 1
        self.logger.warning(f"PrimeSquad: Notifying operator - {subject}: {message}")

    def _update_status(self, action, result):
        self.status.update({
            "last_action": action,
            "last_result": result,
            "tasks_run": self.status["tasks_run"] + 1
        })

    def _add_history(self, kind, data):
        entry = dict(type=kind, ts=time.time(), **data)
        self.history.append(entry)

    def _log_and_audit(self, message, audit_data):
        self.logger.info(message)
        if self.audit_layer:
            self.audit_layer.log(audit_data)

    # --- Unified Command Entry for Dashboard/GUI/API ---
    def execute(self, command_details):
        task = command_details.get("task", "")
        details = command_details.get("details", "")

        if "execute master strategy" in details.lower():
            strategy_details = details.split("execute master strategy: ")[-1].strip()
            response, is_valid, confidence, scorecard = self.execute_master_strategy(strategy_details)
            return response, is_valid, confidence, scorecard
        elif "start background" in details.lower():
            interval = command_details.get("interval", 180)
            self.start_background_tracking(interval=interval)
            return "PrimeSquad: Background tracking started.", True, 1.0, {}
        elif "stop background" in details.lower():
            self.stop_background_tracking()
            return "PrimeSquad: Background tracking stopped.", True, 1.0, {}
        elif "status" in details.lower():
            return self.get_status(), True, 1.0, {}
        elif "history" in details.lower():
            kind = command_details.get("kind")
            limit = command_details.get("limit", 50)
            return self.get_history(kind, limit), True, 1.0, {}
        elif "replay" in details.lower():
            kind = command_details.get("kind")
            self.replay_history(kind)
            return "History replayed.", True, 1.0, {}
        elif "notify" in details.lower():
            self._notify_operator(command_details.get("subject", "Prime Alert"), command_details.get("message", ""))
            return "Operator notified.", True, 1.0, {}
        else:
            return "PrimeSquad: Understood. Performing general prime tasks.", True, 0.8, {
                "success_probability": 0.8, "cost_estimate": 0.02, "risk_assessment": 0.1, "overall_score": 0.7
            }
