import time
import threading
import logging

class PlannerSquad:
    """
    PlannerSquad: Autonomous, connected, and proactive planning/strategy unit.
    - Oversees and dynamically adjusts short/long-term goals and missions.
    - Advises on strategies using live cross-squad context (Admin, Accounting, Construction, Trading).
    - Runs background tracking/forecasting for goals, risks, and opportunities.
    - GUI/API ready: exposes status, live event/history feed, and unified actions.
    - Notifies operator and GUI on milestones, blockers, or strategic pivots.
    """

    def __init__(
        self, event_bus, audit_layer, memory, llm_manager, fusion_engine,
        admin_squad=None, accounting_squad=None, construction_planning_squad=None, trading_squad=None,
        notification_manager=None, logger=None
    ):
        self.event_bus = event_bus
        self.audit_layer = audit_layer
        self.memory = memory
        self.llm_manager = llm_manager
        self.fusion_engine = fusion_engine
        self.admin_squad = admin_squad
        self.accounting_squad = accounting_squad
        self.construction_planning_squad = construction_planning_squad
        self.trading_squad = trading_squad
        self.notification_manager = notification_manager
        self.logger = logger or logging.getLogger("PlannerSquad")
        self.history = []
        self.status = {
            "last_action": None,
            "last_result": None,
            "tasks_run": 0,
            "alerts_sent": 0,
            "last_goal_check": None,
            "tracked_goals": {},
            "active_background": False,
        }
        self._stop_tracking = False
        self._tracker_thread = None
        self.logger.info("PlannerSquad: Initialized for advanced mission, goal, and strategy planning.")

    # --- Background Live Tracking and Forecasting ---
    def start_background_tracking(self, interval=30):
        """Launch background tracking of goals and squad statuses for live GUI."""
        if self._tracker_thread and self._tracker_thread.is_alive():
            self.logger.info("PlannerSquad: Background tracking already running.")
            return
        self._stop_tracking = False
        def tracker():
            while not self._stop_tracking:
                try:
                    self.background_check()
                except Exception as e:
                    self.logger.error(f"PlannerSquad: Error in background_check: {e}")
                time.sleep(interval)
        self._tracker_thread = threading.Thread(target=tracker, daemon=True)
        self._tracker_thread.start()
        self.status["active_background"] = True
        self.logger.info("PlannerSquad: Background goal/squad tracking started.")

    def stop_background_tracking(self):
        self._stop_tracking = True
        self.status["active_background"] = False
        if self._tracker_thread:
            self._tracker_thread.join(timeout=5)
        self.logger.info("PlannerSquad: Background tracking stopped.")

    def background_check(self):
        """Check and update goal/squad statuses, detect risks, and advise if needed."""
        now = time.time()
        # Gather squad status
        admin_status = self.admin_squad.get_status() if self.admin_squad else {}
        accounting_status = self.accounting_squad.get_status() if self.accounting_squad else {}
        construction_status = self.construction_planning_squad.get_status() if self.construction_planning_squad else {}
        trading_status = self.trading_squad.get_status() if self.trading_squad else {}
        tracked_goals = self.status["tracked_goals"]

        issues = []
        # Example: auto-detect issues from connected squads
        if accounting_status.get("budget_status") == "overrun":
            issues.append("Budget overrun (Accounting)")
            self._notify_operator("Budget Issue", "Accounting squad reports a budget overrun.")
        if construction_status.get("milestone_status") == "delayed":
            issues.append("Construction milestone delay")
            self._notify_operator("Milestone Issue", "Construction squad reports delayed milestone.")
        if admin_status.get("permit_status") == "pending":
            issues.append("Admin permit pending")
        if trading_status.get("market_risk") == "high":
            issues.append("High market risk (Trading)")

        # Check for overdue/incomplete goals
        overdue_goals = [gid for gid, g in tracked_goals.items()
                         if g.get("due") and g["due"] < now and g.get("status") != "done"]
        if overdue_goals:
            issues.extend([f"Goal overdue: {gid}" for gid in overdue_goals])
            for gid in overdue_goals:
                self._notify_operator("Goal Overdue", f"Goal {gid} is past due.")

        # Proactive strategy advice if any issue detected
        if issues:
            advice, valid, conf = self.advise_on_strategy(" & ".join(issues))
            self._add_history("auto_strategy_advice", {"issues": issues, "advice": advice, "valid": valid, "confidence": conf})
            self.status["last_result"] = advice
        else:
            self.status["last_result"] = "Background check: All clear"

        self.status["last_action"] = "Background check"
        self.status["last_goal_check"] = now
        self.status["tasks_run"] += 1
        self.event_bus.publish("planner_event", {"action": "background_check", "issues": issues, "timestamp": now})

    # --- Strategic Advising and Planning ---
    def advise_on_strategy(self, goal_details):
        self.logger.info(f"PlannerSquad: Advising on strategy for goal: {goal_details}...")
        # Gather context from connected squads
        admin_ctx = self.admin_squad.get_status() if self.admin_squad else {}
        accounting_ctx = self.accounting_squad.get_status() if self.accounting_squad else {}
        construction_ctx = self.construction_planning_squad.get_status() if self.construction_planning_squad else {}
        trading_ctx = self.trading_squad.get_status() if self.trading_squad else {}

        context_summary = (
            f"Admin: {admin_ctx}\n"
            f"Accounting: {accounting_ctx}\n"
            f"Construction: {construction_ctx}\n"
            f"Trading: {trading_ctx}\n"
        )
        self._log_and_audit("Strategy Advising", {
            "type": "strategy_advising",
            "details": {
                "goal": goal_details,
                "context": context_summary
            }
        })
        self.event_bus.publish("planner_event", {
            "action": "strategy_advising",
            "goal": goal_details,
            "context": context_summary
        })
        prompt = (
            f"Given this context:\n{context_summary}\n"
            f"Advise on the smartest, most effective strategies to achieve: {goal_details}.\n"
            f"Consider cross-squad coordination, resource allocation, and risk mitigation."
        )
        response, is_valid, confidence = self.llm_manager.get_llm_response("llama3", prompt, "strategy_advising")
        self.logger.info(f"PlannerSquad: Strategic advice (LLM): {str(response)[:120]}...")
        self._update_status("Strategic advising", response)
        self._add_history("strategy_advising", {"goal": goal_details, "result": response, "valid": is_valid, "confidence": confidence})
        if confidence < 0.6 or not is_valid:
            self._notify_operator("Low confidence in strategy advice", response)
        return response, is_valid, confidence

    def oversee_mission_planning(self, mission_details):
        self.logger.info(f"PlannerSquad: Overseeing mission planning for: {mission_details}...")
        self._log_and_audit("Mission Planning", {"type": "mission_planning", "details": mission_details})
        self.event_bus.publish("planner_event", {"action": "planning_initiated", "mission": mission_details})
        prompt = f"Develop a high-level plan for the mission: {mission_details}"
        response, is_valid, confidence = self.llm_manager.get_llm_response("llama3", prompt, "mission_planning")
        self.logger.info(f"PlannerSquad: Mission plan (LLM): {str(response)[:80]}...")
        self._update_status("Mission planning", response)
        self._add_history("mission_planning", {"mission": mission_details, "result": response, "valid": is_valid, "confidence": confidence})
        return response, is_valid, confidence

    def track_goals(self, goal_id, status, due=None):
        self.logger.info(f"PlannerSquad: Tracking goal {goal_id}, status: {status}...")
        self.memory.update_shared_data(f"goal_{goal_id}", status)
        self.status["tracked_goals"][goal_id] = {"status": status, "due": due}
        self._log_and_audit("Goal Tracking", {"type": "goal_tracking", "details": {"goal_id": goal_id, "status": status, "due": due}})
        self.event_bus.publish("planner_event", {"action": "goal_updated", "goal_id": goal_id, "status": status, "due": due})
        self._add_history("goal_tracking", {"goal_id": goal_id, "status": status, "due": due})

    def realign_priority(self, task_id, new_priority):
        self.logger.info(f"PlannerSquad: Realigning priority for task {task_id} to {new_priority}...")
        self._log_and_audit("Priority Realignment", {"type": "priority_realign", "details": {"task_id": task_id, "new_priority": new_priority}})
        self.event_bus.publish("planner_event", {"action": "priority_realigned", "task_id": task_id, "new_priority": new_priority})
        self._add_history("priority_realign", {"task_id": task_id, "new_priority": new_priority})

    def optimize_timeline(self, project_id):
        self.logger.info(f"PlannerSquad: Optimizing timeline for project {project_id}...")
        self._log_and_audit("Timeline Optimization", {"type": "timeline_optimization", "details": {"project_id": project_id}})
        self.event_bus.publish("planner_event", {"action": "timeline_optimized", "project_id": project_id})
        prompt = f"Optimize the timeline for project {project_id}."
        response, is_valid, confidence = self.llm_manager.get_llm_response("mixtral", prompt, "timeline_optimization")
        self.logger.info(f"PlannerSquad: Timeline optimization (LLM): {str(response)[:80]}...")
        self._update_status("Timeline optimization", response)
        self._add_history("timeline_optimization", {"project_id": project_id, "result": response, "valid": is_valid, "confidence": confidence})
        return response, is_valid, confidence

    def provide_briefing(self, topic):
        self.logger.info(f"PlannerSquad: Providing briefing on: {topic}...")
        self._log_and_audit("Briefing Provided", {"type": "briefing_provided", "details": {"topic": topic}})
        self.event_bus.publish("planner_event", {"action": "briefing_provided", "topic": topic})
        prompt = f"Prepare a concise briefing on {topic}."
        response, is_valid, confidence = self.llm_manager.get_llm_response("llama2", prompt, "briefing_generation")
        self.logger.info(f"PlannerSquad: Briefing (LLM): {str(response)[:80]}...")
        self._update_status("Briefing", response)
        self._add_history("briefing", {"topic": topic, "result": response, "valid": is_valid, "confidence": confidence})
        return response, is_valid, confidence

    # --- Dashboard/History/Status/Replay ---
    def get_status(self):
        return dict(self.status)

    def get_history(self, kind=None, limit=50):
        filtered = [e for e in reversed(self.history) if (kind is None or e.get('type') == kind)]
        return filtered[:limit]

    def replay_history(self, kind=None):
        self.logger.info("PlannerSquad: Replaying planning history...")
        filtered = [e for e in self.history if (kind is None or e.get('type') == kind)]
        for event in filtered:
            print(f"  [{time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(event['ts']))}] {event}")

    # --- Operator Notification ---
    def _notify_operator(self, subject, message):
        if self.notification_manager:
            self.notification_manager.notify(subject, message)
            self.status["alerts_sent"] += 1
        self.logger.warning(f"PlannerSquad: Notifying operator - {subject}: {message}")

    # --- Helpers for Status and History ---
    def _update_status(self, action, result):
        self.status.update({
            "last_action": action,
            "last_result": result,
            "tasks_run": self.status["tasks_run"] + 1
        })

    def _add_history(self, kind, data):
        entry = dict(type=kind, ts=time.time(), **data)
        self.history.append(entry)

    def _log_and_audit(self, message, audit_data):
        self.logger.info(message)
        if self.audit_layer:
            self.audit_layer.log(audit_data)

    # --- Unified Command Entry Point for Dashboard/GUI/API ---
    def execute(self, command_details):
        """
        Unified entry for dashboard GUI or API to trigger planning tasks.
        Status/history are always updated for GUI polling or push.
        """
        task = command_details.get("task", "")
        details = command_details.get("details", "")

        if "advise strategy" in details.lower():
            goal_details = details.split("advise strategy for ")[-1].strip()
            response, is_valid, confidence = self.advise_on_strategy(goal_details)
            scorecard = self.fusion_engine.fuse_signals({
                "llm_confidence": confidence, "llm_validity": is_valid, "task_complexity": 0.85
            })
            return response, is_valid, confidence, scorecard
        elif "plan mission" in details.lower():
            mission_details = details.split("plan mission ")[-1].strip()
            response, is_valid, confidence = self.oversee_mission_planning(mission_details)
            scorecard = self.fusion_engine.fuse_signals({
                "llm_confidence": confidence, "llm_validity": is_valid, "task_complexity": 0.7
            })
            return response, is_valid, confidence, scorecard
        elif "track goal" in details.lower():
            import re
            pattern = r"track goal (.+?) status (.+?)(?: due ([0-9]+))?$"
            match = re.match(pattern, details.lower())
            if match:
                goal_id = match.group(1)
                status = match.group(2)
                due = float(match.group(3)) if match.group(3) else None
                self.track_goals(goal_id, status, due)
                return f"PlannerSquad: Goal {goal_id} status updated to {status}.", True, 1.0, {
                    "success_probability": 1.0, "cost_estimate": 0.01, "risk_assessment": 0.0, "overall_score": 1.0
                }
            else:
                return "PlannerSquad: Invalid 'track goal' command format.", False, 0.5, {
                    "success_probability": 0.5, "cost_estimate": 0.01, "risk_assessment": 0.1, "overall_score": 0.4
                }
        elif "realign priority" in details.lower():
            parts = details.split("realign priority ")[-1].strip().split(" to ")
            if len(parts) == 2:
                task_id = parts[0]
                new_priority = parts[1]
                self.realign_priority(task_id, new_priority)
                return f"PlannerSquad: Priority for task {task_id} realigned to {new_priority}.", True, 1.0, {
                    "success_probability": 1.0, "cost_estimate": 0.01, "risk_assessment": 0.0, "overall_score": 1.0
                }
            else:
                return "PlannerSquad: Invalid 'realign priority' command format.", False, 0.5, {
                    "success_probability": 0.5, "cost_estimate": 0.01, "risk_assessment": 0.1, "overall_score": 0.4
                }
        elif "optimize timeline" in details.lower():
            project_id = details.split("optimize timeline for ")[-1].strip()
            response, is_valid, confidence = self.optimize_timeline(project_id)
            scorecard = self.fusion_engine.fuse_signals({
                "llm_confidence": confidence, "llm_validity": is_valid, "task_complexity": 0.6
            })
            return response, is_valid, confidence, scorecard
        elif "provide briefing" in details.lower():
            topic = details.split("provide briefing on ")[-1].strip()
            response, is_valid, confidence = self.provide_briefing(topic)
            scorecard = self.fusion_engine.fuse_signals({
                "llm_confidence": confidence, "llm_validity": is_valid, "task_complexity": 0.5
            })
            return response, is_valid, confidence, scorecard
        elif "start background" in details.lower():
            interval = command_details.get("interval", 30)
            self.start_background_tracking(interval=interval)
            return "Background tracking started.", True, 1.0, {}
        elif "stop background" in details.lower():
            self.stop_background_tracking()
            return "Background tracking stopped.", True, 1.0, {}
        elif "status" in details.lower():
            return self.get_status(), True, 1.0, {}
        elif "history" in details.lower():
            kind = command_details.get("kind")
            limit = command_details.get("limit", 50)
            return self.get_history(kind, limit), True, 1.0, {}
        elif "replay" in details.lower():
            kind = command_details.get("kind")
            self.replay_history(kind)
            return "History replayed.", True, 1.0, {}
        elif "notify" in details.lower():
            self._notify_operator(command_details.get("subject", "Planner Alert"), command_details.get("message", ""))
            return "Operator notified.", True, 1.0, {}
        else:
            return "PlannerSquad: Understood. Performing general planning tasks.", True, 0.8, {
                "success_probability": 0.8, "cost_estimate": 0.02, "risk_assessment": 0.1, "overall_score": 0.7
            }
