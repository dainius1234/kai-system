import sqlite3
import os
import json
import hashlib
import datetime
import threading
import time
import csv
from pathlib import Path
from typing import Dict, Union, Optional, List
import shutil
from fpdf import FPDF
import matplotlib.pyplot as plt
import smtplib
from email.mime.text import MIMEText

class PersonalConfig:
    def __init__(self):
        self.business_name = "Regal Industries"
        self.owner_name = "Dainius Aukstaitis"
        self.unique_tax_id = "PX 27 31 51D"
        self.tax_reminder_days = 14
        self.favorite_categories = ["Software", "Equipment", "Training"]
        self.personal_allowances = {
            'home_office': 312,
            'mileage_rate': 0.45
        }
        self.your_tax_deadlines = {
            'vat': [
                datetime.date(datetime.date.today().year, 1, 31),
                datetime.date(datetime.date.today().year, 4, 30),
                datetime.date(datetime.date.today().year, 7, 31),
                datetime.date(datetime.date.today().year, 10, 31)
            ],
            'self_assessment': datetime.date(datetime.date.today().year, 1, 31)
        }
        self.yearly_targets = {
            'revenue': 150000,
            'profit_margin': 0.35
        }
        # Email/SMS configuration for reminders
        self.email_address = "your@email.com"
        self.email_password = "your_app_password"
        self.smtp_server = "smtp.gmail.com"
        self.smtp_port = 587
        self.sms_number = None  # e.g., "+1234567890" (requires Twilio or similar integration)

        # Recurring expenses config (supplier, amount, category, day_of_month)
        self.recurring_expenses = [
            {"supplier": "AWS", "amount": 99, "category": "Software", "day_of_month": 15},
            {"supplier": "Rent", "amount": 1200, "category": "Office", "day_of_month": 1}
        ]
        # Shoebox folder for auto intake
        self.shoebox_folder = "./shoebox_receipts"
        # Backup folder
        self.backup_folder = "./accounting_backups"

class BrotherAccountingSystem:
    def __init__(self, personal_config: PersonalConfig):
        self.config = personal_config
        self.db_identifier = self.config.unique_tax_id.replace("-", "_")
        self.db_path = f"{self.db_identifier}.db"
        self.conn = sqlite3.connect(self.db_path)
        self._create_tables()

    def _create_tables(self):
        with self.conn:
            self.conn.executescript(f"""
                CREATE TABLE IF NOT EXISTS {self.db_identifier}_receipts (
                    id INTEGER PRIMARY KEY,
                    file_hash TEXT UNIQUE NOT NULL,
                    date TEXT NOT NULL,
                    supplier TEXT NOT NULL,
                    amount REAL NOT NULL,
                    category TEXT NOT NULL,
                    description TEXT,
                    favorite BOOLEAN DEFAULT 0,
                    approved BOOLEAN DEFAULT 1,
                    audit_log TEXT
                );
                CREATE TABLE IF NOT EXISTS {self.db_identifier}_invoices (
                    id INTEGER PRIMARY KEY,
                    client TEXT NOT NULL,
                    number TEXT UNIQUE NOT NULL,
                    date TEXT NOT NULL,
                    due_date TEXT NOT NULL,
                    amount REAL NOT NULL,
                    status TEXT DEFAULT 'pending',
                    approved BOOLEAN DEFAULT 1,
                    audit_log TEXT
                );
                CREATE TABLE IF NOT EXISTS {self.db_identifier}_tax_optimizations (
                    id INTEGER PRIMARY KEY,
                    date TEXT NOT NULL,
                    strategy TEXT NOT NULL,
                    potential_saving REAL NOT NULL,
                    implemented BOOLEAN DEFAULT 0
                );
            """)

    def parse_receipt(self, file_path: str) -> dict:
        # AI/OCR stub; replace with real service as needed
        return {
            "date": datetime.date.today(),
            "supplier": Path(file_path).stem,
            "amount": 50.0,
            "category": self.config.favorite_categories[0]
        }

    def add_receipt(self, file_path: str, user: str = "owner") -> Dict[str, Union[str, float]]:
        data = self.parse_receipt(file_path)
        file_hash = hashlib.sha256(Path(file_path).read_bytes()).hexdigest()
        if self.conn.execute(
            f"SELECT 1 FROM {self.db_identifier}_receipts WHERE file_hash=?",
            (file_hash,)
        ).fetchone():
            return {'status': 'duplicate'}
        try:
            is_favorite = 1 if data["category"] in self.config.favorite_categories else 0
            needs_approval = 1 if data["amount"] > 1000 else 0
            audit_log = json.dumps([{
                "action": "added",
                "by": user,
                "timestamp": datetime.datetime.now().isoformat()
            }])
            self.conn.execute(
                f"""INSERT INTO {self.db_identifier}_receipts 
                (file_hash, date, supplier, amount, category, favorite, approved, audit_log) 
                VALUES (?,?,?,?,?,?,?,?)""",
                (file_hash, data["date"].isoformat(), data["supplier"], data["amount"], data["category"], is_favorite, not needs_approval, audit_log)
            )
            self.conn.commit()
            return {
                'status': 'pending_approval' if needs_approval else 'success',
                'amount': data["amount"],
                'category': data["category"],
                'favorite': bool(is_favorite),
                'approved': not needs_approval,
                'message': f"Added to your {data['category']} expenses"
            }
        except Exception as e:
            return {'status': 'error', 'error': str(e)}

    # --- Recurring Expenses Automation ---
    def process_recurring_expenses(self):
        today = datetime.date.today()
        for exp in self.config.recurring_expenses:
            if today.day == exp.get("day_of_month", 1):
                file_hash = hashlib.sha256(f"{exp['supplier']}{today}".encode()).hexdigest()
                if not self.conn.execute(
                    f"SELECT 1 FROM {self.db_identifier}_receipts WHERE file_hash=?",
                    (file_hash,)
                ).fetchone():
                    audit_log = json.dumps([{"action": "auto-recurring", "timestamp": datetime.datetime.now().isoformat()}])
                    self.conn.execute(
                        f"""INSERT INTO {self.db_identifier}_receipts
                        (file_hash, date, supplier, amount, category, favorite, approved, audit_log)
                        VALUES (?,?,?,?,?,?,?,?)""",
                        (
                            file_hash,
                            today.isoformat(),
                            exp["supplier"],
                            exp["amount"],
                            exp["category"],
                            1,
                            1,
                            audit_log
                        )
                    )
                    self.conn.commit()

    # --- Shoebox Intake Automation ---
    def process_shoebox_folder(self):
        shoebox = Path(self.config.shoebox_folder)
        shoebox.mkdir(exist_ok=True)
        for file in shoebox.iterdir():
            if file.is_file():
                self.add_receipt(str(file))
                file.unlink()

    # --- Email/SMS Reminders ---
    def send_email(self, subject, body):
        try:
            msg = MIMEText(body)
            msg['Subject'] = subject
            msg['From'] = self.config.email_address
            msg['To'] = self.config.email_address
            with smtplib.SMTP(self.config.smtp_server, self.config.smtp_port) as server:
                server.starttls()
                server.login(self.config.email_address, self.config.email_password)
                server.send_message(msg)
            return True
        except Exception as e:
            print(f"Email failed: {e}")
            return False

    def send_deadline_reminder(self, deadline_info):
        subject = f"Reminder: {deadline_info['deadline_name']} in {deadline_info['days_left']} days"
        body = f"Hi {self.config.owner_name},\n\nThis is your reminder: {deadline_info['deadline_name']} is due on {deadline_info['date']:%d %b %Y} ({deadline_info['days_left']} days left).\n\nStay ahead!"
        self.send_email(subject, body)

    def send_monthly_summary(self, summary):
        subject = f"Monthly Accounting Summary for {self.config.owner_name}"
        body = f"Hi {self.config.owner_name},\n\nHere's your monthly summary:\n\n{summary}\n\nStay organized!"
        self.send_email(subject, body)

    # --- Bank CSV Import & Reconcile ---
    def import_bank_csv(self, csv_path: str):
        imported = []
        with open(csv_path, newline='') as f:
            reader = csv.DictReader(f)
            for row in reader:
                amount = float(row.get("Amount", 0))
                date = row.get("Date")
                supplier = row.get("Supplier") or row.get("Description")
                # Try to match receipt by amount and date
                r = self.conn.execute(
                    f"SELECT id FROM {self.db_identifier}_receipts WHERE amount=? AND date=? AND supplier=?",
                    (amount, date, supplier)
                ).fetchone()
                if not r:
                    # Add unmatched as a new record
                    file_hash = hashlib.sha256(f"{supplier}{date}{amount}".encode()).hexdigest()
                    self.conn.execute(
                        f"""INSERT INTO {self.db_identifier}_receipts
                        (file_hash, date, supplier, amount, category, favorite, approved, audit_log)
                        VALUES (?,?,?,?,?,?,?,?)""",
                        (
                            file_hash,
                            date,
                            supplier,
                            amount,
                            "Uncategorized",
                            0,
                            1,
                            json.dumps([{"action": "imported-bank", "timestamp": datetime.datetime.now().isoformat()}])
                        )
                    )
                    imported.append({"supplier": supplier, "amount": amount, "date": date})
        self.conn.commit()
        return imported

    # --- Auto-Backup ---
    def backup_db(self):
        Path(self.config.backup_folder).mkdir(exist_ok=True)
        backup_path = Path(self.config.backup_folder) / f"{self.db_identifier}_{datetime.date.today().isoformat()}.db"
        shutil.copy2(self.db_path, backup_path)
        return str(backup_path)

    # --- Monthly Auto-Export ---
    def auto_export_monthly_reports(self):
        year = datetime.date.today().year
        month = datetime.date.today().month
        start = datetime.date(year, month, 1)
        end = datetime.date(year, month, 28)
        for d in range(31,27,-1):
            try:
                end = datetime.date(year, month, d)
                break
            except:
                continue
        csv_path = self.generate_csv_report(str(start), str(end))
        return csv_path

    # --- Analytics and Reporting as before ---
    def generate_csv_report(self, start_date: str, end_date: str, out_path: Optional[str] = None) -> str:
        rows = self.conn.execute(
            f"SELECT date, supplier, amount, category FROM {self.db_identifier}_receipts WHERE date BETWEEN ? AND ?",
            (start_date, end_date)
        ).fetchall()
        out_path = out_path or f"{self.db_identifier}_report_{start_date}_to_{end_date}.csv"
        with open(out_path, "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["Date", "Supplier", "Amount", "Category"])
            writer.writerows(rows)
        return out_path

    def financial_health_check(self) -> Dict[str, Union[str, float]]:
        current_year = datetime.date.today().year
        start_date = datetime.date(current_year, 1, 1).isoformat()
        end_date = datetime.date(current_year, 12, 31).isoformat()
        revenue = self.conn.execute(
            f"SELECT COALESCE(SUM(amount), 0) FROM {self.db_identifier}_invoices WHERE date BETWEEN ? AND ?",
            (start_date, end_date)
        ).fetchone()[0] or 0
        expenses = self.conn.execute(
            f"SELECT COALESCE(SUM(amount), 0) FROM {self.db_identifier}_receipts WHERE date BETWEEN ? AND ?",
            (start_date, end_date)
        ).fetchone()[0] or 0
        profit = revenue - expenses
        profit_margin = profit / revenue if revenue > 0 else 0
        target_margin = self.config.yearly_targets['profit_margin']
        margin_status = "on track" if profit_margin >= target_margin else "needs improvement"
        return {
            'year': current_year,
            'revenue': revenue,
            'expenses': expenses,
            'profit': profit,
            'profit_margin': f"{profit_margin:.1%}",
            'target_margin': f"{target_margin:.0%}",
            'margin_status': margin_status,
            'recommendation': "Review high-cost categories" if margin_status == "needs improvement" else "Great work!"
        }

    def get_overdue_invoices(self) -> List[dict]:
        today = datetime.date.today().isoformat()
        rows = self.conn.execute(
            f"SELECT client, number, due_date FROM {self.db_identifier}_invoices WHERE status = 'pending' AND due_date < ?",
            (today,)
        ).fetchall()
        return [{"client": c, "number": n, "due_date": d} for c, n, d in rows]

class AccountingSquad:
    def __init__(self, brother_system: BrotherAccountingSystem, audit_layer=None, event_bus=None, admin_squad=None, construction_planning_squad=None):
        self.system = brother_system
        self.personal_config = brother_system.config
        self.audit_layer = audit_layer
        self.event_bus = event_bus
        self.admin_squad = admin_squad
        self.construction_planning_squad = construction_planning_squad
        self.paused = False
        self.shutdown_flag = False
        self._reminder_thread = None

    def link_admin(self, admin_squad):
        self.admin_squad = admin_squad

    def link_construction_planning(self, construction_planning_squad):
        self.construction_planning_squad = construction_planning_squad

    def _log_and_notify(self, message, level='INFO'):
        if self.audit_layer:
            self.audit_layer.log(f"AccountingSquad: {message}", level=level)
        if self.event_bus:
            self.event_bus.publish(f"accounting_event", {"message": message, "level": level})

    def pause(self):
        self.paused = True
        self._log_and_notify("AccountingSquad paused. No tasks will be processed.", level="INFO")

    def resume(self):
        self.paused = False
        self._log_and_notify("AccountingSquad resumed.", level="INFO")

    def shutdown(self):
        self.shutdown_flag = True
        self._log_and_notify("AccountingSquad shutdown requested.", level="INFO")

    def _check_paused(self):
        if self.shutdown_flag:
            return True, "AccountingSquad is shut down."
        if self.paused:
            return True, "AccountingSquad is paused."
        return False, ""

    # --- Main life automation thread ---
    def start_life_automation_thread(self):
        def loop():
            while not self.shutdown_flag:
                # Recurring expenses
                self.system.process_recurring_expenses()
                # Shoebox receipts
                self.system.process_shoebox_folder()
                # Backup
                backup_path = self.system.backup_db()
                self._log_and_notify(f"Auto-backup completed: {backup_path}")

                # Monthly reports and summary on the 1st of each month
                today = datetime.date.today()
                if today.day == 1:
                    csv_path = self.system.auto_export_monthly_reports()
                    self._log_and_notify(f"Monthly report exported: {csv_path}")
                    summary = json.dumps(self.system.financial_health_check(), indent=2)
                    self.system.send_monthly_summary(summary)

                # Deadline reminders
                deadline = self.personal_config.get_next_deadline()
                if 'days_left' in deadline and deadline['days_left'] <= self.personal_config.tax_reminder_days:
                    self.system.send_deadline_reminder(deadline)
                    self._log_and_notify(f"Email reminder sent for: {deadline['deadline_name']}")

                # Overdue invoices notification (could email/SMS as well)
                for inv in self.system.get_overdue_invoices():
                    self._log_and_notify(f"OVERDUE INVOICE: {inv['number']} for {inv['client']} (due {inv['due_date']})", level='WARNING')

                # Sleep 24h for real deployment; for demo/test, use shorter
                time.sleep(24*3600)
        if not self._reminder_thread or not self._reminder_thread.is_alive():
            t = threading.Thread(target=loop, daemon=True)
            t.start()
            self._reminder_thread = t

    def handle_command(self, command: str, user: str = "owner") -> Dict:
        paused, msg = self._check_paused()
        if paused:
            return {'status': 'paused', 'message': msg}
        self._log_and_notify(f"Received command: {command}", level='INFO')
        cmd = command.lower().strip()
        if "receipt" in cmd:
            file_path = command.split("receipt")[-1].strip()
            if not file_path:
                return {'status': 'error', 'message': 'Please specify file path'}
            return self.system.add_receipt(file_path, user=user)
        elif "import bank" in cmd:
            file_path = command.split("import bank")[-1].strip()
            if not file_path:
                return {'status': 'error', 'message': 'Please specify CSV file path'}
            imported = self.system.import_bank_csv(file_path)
            return {'status': 'success', 'imported': imported}
        elif "backup" in cmd:
            backup_path = self.system.backup_db()
            return {'status': 'success', 'backup_path': backup_path}
        elif "pause" == cmd:
            self.pause()
            return {'status': 'paused'}
        elif "resume" == cmd:
            self.resume()
            return {'status': 'resumed'}
        elif "shutdown" == cmd:
            self.shutdown()
            return {'status': 'shutdown'}
        return {'status': 'unrecognized_command', 'message': 'Unrecognized command.'}
