import time
import logging
import threading
import random

class DebugSquad:
    """
    DebugSquad: Advanced script error monitoring, diagnosis, and self-repair coordination.
    - Monitors scripts for runtime errors and logs incidents.
    - Alerts a junior agent for self-repair when errors are detected.
    - Suggests real-time fixes using LLM manager (AI model).
    - Supports diagnostic history and event replay for post-mortem analysis.
    - Integrates with telemetry, supports live status, and exposes API for dashboards.
    """

    def __init__(self, event_bus, audit_layer, memory, llm_manager, fusion_engine, junior_agent, logger=None):
        self.event_bus = event_bus
        self.audit_layer = audit_layer
        self.memory = memory
        self.llm_manager = llm_manager
        self.fusion_engine = fusion_engine
        self.junior_agent = junior_agent
        self.logger = logger or logging.getLogger("DebugSquad")
        self.diagnostic_history = []
        self.active_monitors = {}
        self._tracker_threads = {}
        self.status = {
            "last_script_checked": None,
            "last_error": None,
            "last_fix_suggestion": None,
            "monitored_scripts": [],
            "alerts_sent": 0,
            "errors_detected": 0,
            "last_action": None,
        }
        self.logger.info("DebugSquad: Initialized for script error detection, diagnosis, and recovery.")

    def monitor_script_errors(self, script_name, continuous=False, interval=10, max_checks=5):
        """
        Monitors a script for errors. If continuous=True, does repeated checks in a separate thread.
        Returns (error_detected, error_details or 'No errors.')
        """
        def monitor_loop():
            checks = 0
            while not self.active_monitors.get(script_name, {}).get("stop", False) and (max_checks is None or checks < max_checks):
                error_detected, msg = self._single_script_check(script_name)
                if error_detected:
                    break
                checks += 1
                time.sleep(interval)
            self.active_monitors.pop(script_name, None)

        if continuous:
            self.active_monitors[script_name] = {"stop": False}
            t = threading.Thread(target=monitor_loop, daemon=True)
            t.start()
            self._tracker_threads[script_name] = t
            self.status["monitored_scripts"].append(script_name)
            self.status["last_action"] = f"Started continuous monitoring for {script_name}"
            return f"Started monitoring {script_name} in background"
        else:
            error_detected, msg = self._single_script_check(script_name)
            self.status["last_script_checked"] = script_name
            self.status["last_error"] = msg if error_detected else None
            self.status["last_action"] = f"Checked {script_name} once"
            return error_detected, msg

    def stop_monitoring(self, script_name):
        """Stop a background monitor if running."""
        if script_name in self.active_monitors:
            self.active_monitors[script_name]["stop"] = True
            t = self._tracker_threads.pop(script_name, None)
            if t:
                t.join(timeout=5)
            self.status["last_action"] = f"Stopped monitoring {script_name}"
            return f"Stopped monitoring {script_name}"
        return f"No monitor found for {script_name}"

    def _single_script_check(self, script_name):
        msg = f"DebugSquad: Monitoring {script_name} for errors..."
        self.logger.info(msg)
        self._log_and_audit(msg, {"type": "script_error_monitoring", "details": {"script": script_name}})
        self.event_bus.publish("debug_event", {"action": "error_monitoring_initiated", "script": script_name})
        # Integrate with real error detection here (or simulated for now)
        error_detected = False  # Set to True to simulate an error for real detection
        if error_detected:
            error_details = f"Detected error in {script_name}: Division by zero."
            msg = f"DebugSquad: Error detected in {script_name}: {error_details}"
            self.logger.error(msg)
            self.status["errors_detected"] += 1
            self._log_and_audit(msg, {"type": "script_error_detected", "details": {"script": script_name, "error": error_details}})
            self.diagnostic_history.append({"script": script_name, "event": "error_detected", "error": error_details, "timestamp": time.time()})
            self.alert_junior(script_name, error_details)
            return True, error_details
        else:
            msg = f"DebugSquad: No errors detected in {script_name}."
            self.logger.info(msg)
            self._log_and_audit(msg, {"type": "script_clean", "details": {"script": script_name}})
            self.diagnostic_history.append({"script": script_name, "event": "no_error", "timestamp": time.time()})
            return False, "No errors."

    def alert_junior(self, script_name, error_details):
        """
        Alerts the junior agent to trigger a self-repair operation.
        """
        msg = f"DebugSquad: Alerting Junior about error in {script_name}: {error_details}"
        self.logger.warning(msg)
        self.status["alerts_sent"] += 1
        self._log_and_audit(msg, {
            "type": "junior_alert",
            "details": {"script": script_name, "error": error_details}
        })
        self.event_bus.publish("debug_event", {
            "action": "junior_alerted",
            "script": script_name,
            "error": error_details
        })
        if self.junior_agent:
            self.junior_agent.trigger_self_repair(script_name, error_details)

    def suggest_realtime_fix(self, error_details):
        """
        Uses the LLM manager to suggest a real-time fix for an error.
        Returns (response, is_valid, confidence)
        """
        msg = f"DebugSquad: Suggesting real-time fix for: {error_details}..."
        self.logger.info(msg)
        self._log_and_audit(msg, {
            "type": "realtime_fix_suggestion",
            "details": {"error": error_details}
        })
        self.event_bus.publish("debug_event", {
            "action": "fix_suggestion_initiated",
            "error": error_details
        })
        prompt = f"Suggest a real-time fix for the following error: {error_details}"
        response, is_valid, confidence = self.llm_manager.get_llm_response("mixtral", prompt, "fix_suggestion")
        self.logger.info(f"DebugSquad: Real-time fix suggestion (LLM): {str(response)[:100]}...")
        self.status["last_fix_suggestion"] = response
        self.diagnostic_history.append({
            "event": "fix_suggestion", "error": error_details, "response": response,
            "is_valid": is_valid, "confidence": confidence, "timestamp": time.time()
        })
        return response, is_valid, confidence

    def simulate_error_injection(self, script_name, error_type="division_by_zero"):
        """
        Simulates injecting an error into a script for testing the debug pipeline.
        """
        msg = f"DebugSquad: Injecting simulated '{error_type}' error into {script_name}."
        self.logger.warning(msg)
        self._log_and_audit(msg, {
            "type": "error_injection",
            "details": {"script": script_name, "error_type": error_type}
        })
        error_details = f"Injected error in {script_name}: {error_type.replace('_', ' ').capitalize()}."
        self.diagnostic_history.append({"script": script_name, "event": "error_injected", "error": error_details, "timestamp": time.time()})
        self.alert_junior(script_name, error_details)

    def replay_diagnostic_history(self, script_name=None):
        """
        Replays diagnostic events for a script or all scripts.
        """
        self.logger.info("DebugSquad: Replaying diagnostic history...")
        filtered = [e for e in self.diagnostic_history if (script_name is None or e.get('script') == script_name)]
        for event in filtered:
            print(f"  [{time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(event['timestamp']))}] {event}")

    def get_status(self):
        return dict(self.status)

    def get_diagnostic_history(self, script_name=None, limit=50):
        filtered = [e for e in reversed(self.diagnostic_history) if (script_name is None or e.get('script') == script_name)]
        return filtered[:limit]

    def execute(self, command_details):
        """
        Main entry point to trigger debug tasks via command dict.
        Returns (result_msg, success_bool, confidence, scorecard_dict)
        """
        task = command_details.get("task", "")
        details = command_details.get("details", "")

        if "monitor script errors" in details.lower():
            script_name = details.split("monitor script errors for ")[-1].strip()
            success, msg = self.monitor_script_errors(script_name)
            scorecard = self.fusion_engine.fuse_signals({
                "success_probability": 1.0 if not success else 0.5,
                "cost_estimate": 0.03,
                "risk_assessment": 0.1 if success else 0.5
            })
            return msg, not success, 1.0 if not success else 0.5, scorecard
        elif "suggest fix" in details.lower():
            error_details = details.split("suggest fix for ")[-1].strip()
            response, is_valid, confidence = self.suggest_realtime_fix(error_details)
            scorecard = self.fusion_engine.fuse_signals({
                "llm_confidence": confidence,
                "llm_validity": is_valid,
                "task_complexity": 0.7
            })
            return response, is_valid, confidence, scorecard
        elif "inject error" in details.lower():
            script_name = details.split("inject error in ")[-1].strip()
            self.simulate_error_injection(script_name)
            scorecard = self.fusion_engine.fuse_signals({
                "success_probability": 1.0,
                "cost_estimate": 0.01,
                "risk_assessment": 0.9
            })
            return f"Injected error in {script_name}", True, 1.0, scorecard
        elif "replay history" in details.lower():
            script_name = details.split("replay history for ")[-1].strip() if "for" in details else None
            self.replay_diagnostic_history(script_name)
            return "Diagnostic history replayed.", True, 1.0, {}
        elif "status" in details.lower():
            return self.get_status(), True, 1.0, {}
        else:
            return (
                "DebugSquad: Understood. Performing general debug tasks.",
                True,
                0.8,
                {"success_probability": 0.8, "cost_estimate": 0.02, "risk_assessment": 0.1, "overall_score": 0.7},
            )

    def _log_and_audit(self, message, audit_data):
        self.logger.info(message)
        if self.audit_layer:
            self.audit_layer.log(audit_data)
