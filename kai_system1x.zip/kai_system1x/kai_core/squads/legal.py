import time
import threading
import logging

class LegalSquad:
    """
    LegalSquad: Autonomous legal advisory, compliance, and risk mitigation unit.
    - Monitors, analyzes, and forecasts legal/regulatory changes globally and locally.
    - Prepares contracts, assesses risk, provides regulatory advice, and proactively warns on compliance issues.
    - Integrates with other squads (Planner, Admin, Accounting, Trading, Construction) for cross-domain strategy.
    - Background tracking for law/risk/events; pushes live updates to dashboard/operator.
    - Offers scenario simulation, compliance scorecards, and action recommendations.
    """

    def __init__(
        self, event_bus, audit_layer, memory, llm_manager, fusion_engine,
        planner_squad=None, admin_squad=None, accounting_squad=None, trading_squad=None, construction_squad=None,
        notification_manager=None, logger=None
    ):
        self.event_bus = event_bus
        self.audit_layer = audit_layer
        self.memory = memory
        self.llm_manager = llm_manager
        self.fusion_engine = fusion_engine
        self.planner_squad = planner_squad
        self.admin_squad = admin_squad
        self.accounting_squad = accounting_squad
        self.trading_squad = trading_squad
        self.construction_squad = construction_squad
        self.notification_manager = notification_manager
        self.logger = logger or logging.getLogger("LegalSquad")
        self.status = {
            "last_action": None,
            "last_result": None,
            "tasks_run": 0,
            "alerts_sent": 0,
            "active_background": False,
            "last_risk_forecast": None,
        }
        self.history = []
        self._stop_tracking = False
        self._tracker_thread = None
        self.logger.info("LegalSquad: Initialized for advanced legal advisory and compliance.")

    # --- Background Law & Risk Tracking and Forecasting ---
    def start_background_tracking(self, jurisdictions, interval=1800):
        """Monitor laws/risk in background and forecast legal issues for dashboard/GUI."""
        if self._tracker_thread and self._tracker_thread.is_alive():
            self.logger.info("LegalSquad: Background tracking already running.")
            return
        self._stop_tracking = False
        def tracker():
            while not self._stop_tracking:
                try:
                    self.background_check(jurisdictions)
                except Exception as e:
                    self.logger.error(f"LegalSquad: Error in background_check: {e}")
                time.sleep(interval)
        self._tracker_thread = threading.Thread(target=tracker, daemon=True)
        self._tracker_thread.start()
        self.status["active_background"] = True
        self.logger.info("LegalSquad: Background law/risk tracking started.")

    def stop_background_tracking(self):
        self._stop_tracking = True
        self.status["active_background"] = False
        if self._tracker_thread:
            self._tracker_thread.join(timeout=5)
        self.logger.info("LegalSquad: Background tracking stopped.")

    def background_check(self, jurisdictions):
        now = time.time()
        issues = []
        for jurisdiction in jurisdictions:
            response, is_valid, confidence = self.monitor_local_laws(jurisdiction)
            if not is_valid or confidence < 0.7 or "risk" in response.lower() or "change" in response.lower():
                self._notify_operator(f"Legal update or issue in {jurisdiction}", response)
                issues.append(f"{jurisdiction}: legal update or risk")
        # Proactive compliance forecasting with LLMs
        forecast, valid, conf = self.forecast_compliance_risks(jurisdictions)
        self.status["last_risk_forecast"] = forecast
        self._add_history("risk_forecast", {"jurisdictions": jurisdictions, "forecast": forecast, "valid": valid, "confidence": conf, "ts": now})
        self.status["last_action"] = "Background check"
        self.status["last_result"] = f"Checked: {jurisdictions} ({', '.join(issues) if issues else 'all clear'})"
        self.status["tasks_run"] += 1
        self.status["last_check"] = now
        self.event_bus.publish("legal_event", {"action": "background_check", "issues": issues, "forecast": forecast, "timestamp": now})

    def forecast_compliance_risks(self, jurisdictions):
        ctx = self._cross_squad_context()
        prompt = (
            f"Given legal context in {jurisdictions} and operational status:\n{ctx}\n"
            f"Forecast upcoming compliance risks, recommend mitigations, and estimate impact."
        )
        forecast, is_valid, confidence = self.llm_manager.get_llm_response("commandr", prompt, "compliance_forecasting")
        self.logger.info(f"LegalSquad: Compliance risk forecast: {str(forecast)[:80]}...")
        if not is_valid or confidence < 0.7:
            self._notify_operator("Low-confidence compliance forecast", forecast)
        return forecast, is_valid, confidence

    def _cross_squad_context(self):
        planner_ctx = self.planner_squad.get_status() if self.planner_squad else {}
        admin_ctx = self.admin_squad.get_status() if self.admin_squad else {}
        accounting_ctx = self.accounting_squad.get_status() if self.accounting_squad else {}
        trading_ctx = self.trading_squad.get_status() if self.trading_squad else {}
        construction_ctx = self.construction_squad.get_status() if self.construction_squad else {}
        return (
            f"Planner: {planner_ctx}\n"
            f"Admin: {admin_ctx}\n"
            f"Accounting: {accounting_ctx}\n"
            f"Trading: {trading_ctx}\n"
            f"Construction: {construction_ctx}\n"
        )

    # --- Legal Operations ---
    def monitor_local_laws(self, jurisdiction):
        self.logger.info(f"LegalSquad: Monitoring local laws for {jurisdiction}...")
        self._log_and_audit("Law Monitoring", {"type": "law_monitoring", "details": {"jurisdiction": jurisdiction}})
        self.event_bus.publish("legal_event", {"action": "law_monitoring_initiated", "jurisdiction": jurisdiction})
        prompt = f"Summarize recent legal changes in {jurisdiction} relevant to AI, privacy, and business."
        response, is_valid, confidence = self.llm_manager.get_llm_response("commandr", prompt, "law_monitoring")
        self.logger.info(f"LegalSquad: Law monitoring (LLM): {str(response)[:80]}...")
        self._update_status("Law monitoring", response)
        self._add_history("law_monitoring", {"jurisdiction": jurisdiction, "result": response, "valid": is_valid, "confidence": confidence})
        return response, is_valid, confidence

    def prepare_contract(self, contract_type, parties):
        self.logger.info(f"LegalSquad: Preparing {contract_type} contract for {parties}...")
        self._log_and_audit("Contract Preparation", {"type": "contract_preparation", "details": {"type": contract_type, "parties": parties}})
        self.event_bus.publish("legal_event", {"action": "contract_preparation_initiated", "type": contract_type})
        prompt = f"Draft a standard {contract_type} contract between {parties}. Highlight compliance, dispute, and risk clauses."
        response, is_valid, confidence = self.llm_manager.get_llm_response("commandr", prompt, "contract_drafting")
        self.logger.info(f"LegalSquad: Contract preparation (LLM): {str(response)[:80]}...")
        self._update_status("Contract preparation", response)
        self._add_history("contract_preparation", {"type": contract_type, "parties": parties, "result": response, "valid": is_valid, "confidence": confidence})
        return response, is_valid, confidence

    def advise_on_regulations(self, topic):
        self.logger.info(f"LegalSquad: Advising on regulations for {topic}...")
        self._log_and_audit("Regulatory Advice", {"type": "regulatory_advice", "details": {"topic": topic}})
        self.event_bus.publish("legal_event", {"action": "regulatory_advice_initiated", "topic": topic})
        prompt = f"Explain key regulations related to {topic}, and advise on compliance and reporting."
        response, is_valid, confidence = self.llm_manager.get_llm_response("commandr", prompt, "regulatory_advice")
        self.logger.info(f"LegalSquad: Regulatory advice (LLM): {str(response)[:80]}...")
        self._update_status("Regulatory advice", response)
        self._add_history("regulatory_advice", {"topic": topic, "result": response, "valid": is_valid, "confidence": confidence})
        return response, is_valid, confidence

    def assess_risk_exposure(self, scenario):
        self.logger.info(f"LegalSquad: Assessing risk exposure for scenario: {scenario}...")
        self._log_and_audit("Risk Assessment", {"type": "risk_assessment", "details": {"scenario": scenario}})
        self.event_bus.publish("legal_event", {"action": "risk_assessment_initiated", "scenario": scenario})
        ctx = self._cross_squad_context()
        prompt = (
            f"Given this scenario: {scenario}\n"
            f"and these operational contexts:\n{ctx}\n"
            f"Analyze potential legal, compliance, and dispute risks. Recommend mitigations and next actions."
        )
        response, is_valid, confidence = self.llm_manager.get_llm_response("commandr", prompt, "risk_assessment")
        self.logger.info(f"LegalSquad: Risk assessment (LLM): {str(response)[:80]}...")
        self._update_status("Risk assessment", response)
        self._add_history("risk_assessment", {"scenario": scenario, "result": response, "valid": is_valid, "confidence": confidence})
        return response, is_valid, confidence

    # --- Dashboard/History/Status/Replay ---
    def get_status(self):
        return dict(self.status)

    def get_history(self, kind=None, limit=50):
        filtered = [e for e in reversed(self.history) if (kind is None or e.get('type') == kind)]
        return filtered[:limit]

    def replay_history(self, kind=None):
        self.logger.info("LegalSquad: Replaying legal history...")
        filtered = [e for e in self.history if (kind is None or e.get('type') == kind)]
        for event in filtered:
            print(f"  [{time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(event['ts']))}] {event}")

    def _notify_operator(self, subject, message):
        if self.notification_manager:
            self.notification_manager.notify(subject, message)
            self.status["alerts_sent"] += 1
        self.logger.warning(f"LegalSquad: Notifying operator - {subject}: {message}")

    # --- Helpers for Status and History ---
    def _update_status(self, action, result):
        self.status.update({
            "last_action": action,
            "last_result": result,
            "tasks_run": self.status["tasks_run"] + 1
        })

    def _add_history(self, kind, data):
        entry = dict(type=kind, ts=time.time(), **data)
        self.history.append(entry)

    def _log_and_audit(self, message, audit_data):
        self.logger.info(message)
        if self.audit_layer:
            self.audit_layer.log(audit_data)

    # --- Unified Command Entry Point for Dashboard/GUI/API ---
    def execute(self, command_details):
        """
        Unified entry for dashboard GUI or API to trigger legal tasks.
        Status/history are always updated for GUI polling or push.
        """
        task = command_details.get("task", "")
        details = command_details.get("details", "")

        if "monitor laws" in details.lower():
            jurisdiction = details.split("monitor laws for ")[-1].strip()
            response, is_valid, confidence = self.monitor_local_laws(jurisdiction)
            scorecard = self.fusion_engine.fuse_signals({
                "llm_confidence": confidence, "llm_validity": is_valid, "task_complexity": 0.7
            })
            return response, is_valid, confidence, scorecard
        elif "prepare contract" in details.lower():
            parts = details.split("prepare contract ")[-1].strip().split(" for ")
            if len(parts) == 2:
                contract_type = parts[0]
                parties = parts[1]
                response, is_valid, confidence = self.prepare_contract(contract_type, parties)
                scorecard = self.fusion_engine.fuse_signals({
                    "llm_confidence": confidence, "llm_validity": is_valid, "task_complexity": 0.8
                })
                return response, is_valid, confidence, scorecard
            else:
                return "LegalSquad: Invalid 'prepare contract' command format.", False, 0.5, {
                    "success_probability": 0.5, "cost_estimate": 0.01, "risk_assessment": 0.1, "overall_score": 0.4
                }
        elif "advise on regulations" in details.lower():
            topic = details.split("advise on regulations for ")[-1].strip()
            response, is_valid, confidence = self.advise_on_regulations(topic)
            scorecard = self.fusion_engine.fuse_signals({
                "llm_confidence": confidence, "llm_validity": is_valid, "task_complexity": 0.75
            })
            return response, is_valid, confidence, scorecard
        elif "assess risk" in details.lower():
            scenario = details.split("assess risk for ")[-1].strip()
            response, is_valid, confidence = self.assess_risk_exposure(scenario)
            scorecard = self.fusion_engine.fuse_signals({
                "llm_confidence": confidence, "llm_validity": is_valid, "task_complexity": 0.85
            })
            return response, is_valid, confidence, scorecard
        elif "start background" in details.lower():
            jurisdictions = command_details.get("jurisdictions", [])
            interval = command_details.get("interval", 1800)
            self.start_background_tracking(jurisdictions, interval=interval)
            return "LegalSquad: Background tracking started.", True, 1.0, {}
        elif "stop background" in details.lower():
            self.stop_background_tracking()
            return "LegalSquad: Background tracking stopped.", True, 1.0, {}
        elif "forecast compliance" in details.lower():
            jurisdictions = command_details.get("jurisdictions", [])
            forecast, is_valid, confidence = self.forecast_compliance_risks(jurisdictions)
            scorecard = self.fusion_engine.fuse_signals({
                "llm_confidence": confidence, "llm_validity": is_valid, "task_complexity": 0.9
            })
            return forecast, is_valid, confidence, scorecard
        elif "status" in details.lower():
            return self.get_status(), True, 1.0, {}
        elif "history" in details.lower():
            kind = command_details.get("kind")
            limit = command_details.get("limit", 50)
            return self.get_history(kind, limit), True, 1.0, {}
        elif "replay" in details.lower():
            kind = command_details.get("kind")
            self.replay_history(kind)
            return "History replayed.", True, 1.0, {}
        elif "notify" in details.lower():
            self._notify_operator(command_details.get("subject", "Legal Alert"), command_details.get("message", ""))
            return "Operator notified.", True, 1.0, {}
        else:
            return "LegalSquad: Understood. Performing general legal tasks.", True, 0.8, {
                "success_probability": 0.8, "cost_estimate": 0.02, "risk_assessment": 0.1, "overall_score": 0.7
            }
