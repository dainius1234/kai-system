import time

class EthicsSquad:
    def __init__(self, event_bus, audit_layer, memory, llm_manager, fusion_engine):
        self.event_bus = event_bus
        self.audit_layer = audit_layer
        self.memory = memory
        self.llm_manager = llm_manager
        self.fusion_engine = fusion_engine
        self.ethical_rules = self._load_ethical_rules()
        self.override_requests = {}
        print("EthicsSquad: Initialized and ready for ethical validation with user veto power.")

    def _load_ethical_rules(self):
        rules = self.memory.get("ethical_rules")
        if rules:
            return rules
        default_rules = [
            "Do not generate harmful content.",
            "Do not engage in illegal activities.",
            "Prioritize user safety and privacy.",
            "Ensure transparency in AI decision-making."
        ]
        self.memory["ethical_rules"] = default_rules
        return default_rules

    def update_rules(self, new_rules):
        self.ethical_rules = new_rules
        self.memory["ethical_rules"] = new_rules
        self.audit_layer.log({
            "type": "ethical_rules_update",
            "details": {"new_rules": new_rules, "time": time.time()}
        })
        self.event_bus.publish("ethics_event", {
            "action": "rules_updated",
            "new_rules": new_rules
        })
        print("EthicsSquad: Ethical rules updated.")

    def request_human_review(self, output_text, reason="Manual review requested"):
        self.audit_layer.log({
            "type": "human_review_requested",
            "details": {"output": output_text, "reason": reason, "time": time.time()}
        })
        self.event_bus.publish("ethics_event", {
            "action": "human_review_requested",
            "output": output_text,
            "reason": reason
        })
        print("EthicsSquad: Human review requested for output.")

    def explain_last_validation(self):
        history = self.memory.get("validation_history", [])
        if not history:
            return "No validations performed yet."
        last = history[-1]
        return (
            f"Output: {last['output']}\n"
            f"Action: {last['action']}\n"
            f"Response: {last['response']}\n"
            f"Confidence: {last['confidence']}\n"
            f"Timestamp: {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(last['time']))}"
        )

    def validate_output(self, output_text, action_details, user_override=False):
        print(f"EthicsSquad: Validating output: {output_text[:80]}...")
        self.audit_layer.log({
            "type": "ethical_validation",
            "details": {"output": output_text, "action": action_details}
        })
        self.event_bus.publish("ethics_event", {
            "action": "validation_initiated",
            "output": output_text
        })

        prompt = (
            "You are the Ethics Agent for an autonomous AI system. "
            f"Here are the ethical rules: {self.ethical_rules}. "
            "Given the following output, state strictly if it violates any rule. "
            f"Output: \"{output_text}\". "
            "Respond ONLY with 'Compliant', 'Violation: [reason]', or 'Uncertain: [reason]'."
        )
        response, is_compliant, confidence = self.llm_manager.get_llm_response(
            "ethics_llm", prompt, "ethical_check"
        )
        response = str(response).strip()
        print(f"EthicsSquad: LLM response: {response}")

        self.audit_layer.log({
            "type": "ethics_llm_response",
            "details": {"response": response, "confidence": confidence}
        })
        self.memory.setdefault("validation_history", []).append({
            "output": output_text,
            "action": action_details,
            "response": response,
            "confidence": confidence,
            "time": time.time()
        })

        violation = response.lower().startswith("violation")
        uncertain = response.lower().startswith("uncertain")
        compliant = response.lower().startswith("compliant")

        if uncertain:
            keywords = ["hack", "scam", "exploit", "phish", "illegal", "theft", "steal"]
            if any(word in output_text.lower() for word in keywords):
                violation = True
                response = "Violation: Keyword policy match (auto fallback)."
                compliant = False
            else:
                response = "Uncertain: No violation by fallback, but human review suggested."
                compliant = False

        if (violation or uncertain) and user_override:
            print("EthicsSquad: User override detected. Proceeding despite warning.")
            self.audit_layer.log({
                "type": "user_override",
                "details": {
                    "output": output_text,
                    "action": action_details,
                    "original_response": response,
                    "time": time.time()
                }
            })
            self.event_bus.publish("ethics_event", {
                "action": "user_override",
                "output": output_text,
                "original_response": response
            })
            scorecard = self.fusion_engine.fuse_signals({
                "ethical_compliance": 0.0 if violation else 0.5,
                "llm_confidence": confidence,
                "risk_assessment": 1.0 if violation else 0.5,
                "override": True
            })
            warning_msg = (
                "WARNING: This action may violate ethical or legal rules. "
                "Proceeding due to user override. You are responsible for the consequences."
            )
            print(warning_msg)
            return True, f"{warning_msg} (Original ethics decision: {response})", confidence, scorecard

        if violation:
            print(f"EthicsSquad: Violation detected: {response[:80]}")
            self.audit_layer.log({
                "type": "ethical_violation",
                "details": {
                    "output": output_text,
                    "action": action_details,
                    "reason": response
                }
            })
            self.event_bus.publish("ethics_event", {
                "action": "violation_detected",
                "output": output_text,
                "reason": response
            })
            scorecard = self.fusion_engine.fuse_signals({
                "ethical_compliance": 0.0,
                "llm_confidence": confidence,
                "risk_assessment": 0.95
            })
            return False, response, confidence, scorecard

        if compliant:
            print("EthicsSquad: Output passed ethical validation.")
            scorecard = self.fusion_engine.fuse_signals({
                "ethical_compliance": 1.0,
                "llm_confidence": confidence,
                "risk_assessment": 0.05
            })
            return True, response, confidence, scorecard

        print("EthicsSquad: Uncertain. Human review recommended.")
        self.event_bus.publish("ethics_event", {
            "action": "human_review",
            "output": output_text,
            "reason": response
        })
        scorecard = self.fusion_engine.fuse_signals({
            "ethical_compliance": 0.5,
            "llm_confidence": confidence,
            "risk_assessment": 0.5
        })
        return None, response, confidence, scorecard

    def log_violation(self, violation_details):
        print(f"EthicsSquad: Logging ethical violation: {violation_details}")
        self.audit_layer.log({
            "type": "ethical_violation_logged",
            "details": violation_details
        })
        self.event_bus.publish("ethics_event", {
            "action": "violation_logged",
            "details": violation_details
        })

    def execute(self, command_details):
        task = command_details.get("task")
        details = command_details.get("details", "")
        user_override = command_details.get("user_override", False)
        if "validate output" in details.lower():
            parts = details.split("validate output ")
            if len(parts) > 1:
                output_text_part = parts[1].split(" for ethical compliance")[0].strip()
                if output_text_part.startswith("'") and output_text_part.endswith("'"):
                    output_text = output_text_part[1:-1]
                else:
                    output_text = output_text_part
                action_details = command_details.get("action_details", "N/A")
                result = self.validate_output(output_text, action_details, user_override=user_override)
                return f"EthicsSquad: Ethical validation result: {result[1]}", result[0], result[2], result[3]
            else:
                return (
                    "EthicsSquad: Invalid validate output command format.",
                    False, 0.5, {
                        "ethical_compliance": 0.0,
                        "llm_confidence": 0.0,
                        "risk_assessment": 1.0
                    }
                )
        else:
            return (
                "EthicsSquad: Understood. Performing general ethics tasks.",
                True, 0.8, {
                    "success_probability": 0.8,
                    "cost_estimate": 0.02,
                    "risk_assessment": 0.1,
                    "overall_score": 0.7
                }
            )
