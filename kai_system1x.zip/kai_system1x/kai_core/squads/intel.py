import time
import threading
import logging

class IntelSquad:
    """
    IntelSquad: Advanced open-source intelligence (OSINT) gatherer and analytics unit.
    - Active/passive recon (single and continuous) on entities/targets.
    - Target collection, enrichment, and scoring based on criteria.
    - Risk and opportunity vector mapping.
    - Simulation/testing, replay, and audit history.
    - Operator notifications for high-risk or actionable findings.
    - Dashboard/REST API ready: status, history, metrics for live GUI integration.
    """

    def __init__(
        self, event_bus, audit_layer, memory, llm_manager, fusion_engine,
        notification_manager=None, logger=None
    ):
        self.event_bus = event_bus
        self.audit_layer = audit_layer
        self.memory = memory
        self.llm_manager = llm_manager
        self.fusion_engine = fusion_engine
        self.notification_manager = notification_manager
        self.logger = logger or logging.getLogger("IntelSquad")
        self.history = []
        self.status = {
            "last_action": None,
            "last_result": None,
            "tasks_run": 0,
            "alerts_sent": 0,
            "active_recon_targets": [],
        }
        self.active_monitors = {}
        self._tracker_threads = {}
        self.logger.info("IntelSquad: Initialized as advanced open-source intelligence gatherer.")

    # --- Reconnaissance, Targeting, and Risk Mapping ---
    def perform_recon(self, target, continuous=False, interval=30, max_checks=None):
        """
        Recon on a target (active/passive). If continuous, runs in background.
        Results, errors, and progress are logged and sent to dashboard via status/history.
        """
        def recon_loop():
            checks = 0
            while not self.active_monitors.get(target, {}).get("stop", False) and (max_checks is None or checks < max_checks):
                result = self._single_recon(target)
                if result:
                    break
                checks += 1
                time.sleep(interval)
            self.active_monitors.pop(target, None)
            if target in self.status["active_recon_targets"]:
                self.status["active_recon_targets"].remove(target)

        if continuous:
            self.active_monitors[target] = {"stop": False}
            t = threading.Thread(target=recon_loop, daemon=True)
            t.start()
            self._tracker_threads[target] = t
            self.status["active_recon_targets"].append(target)
            msg = f"Started continuous recon for {target}"
            self.status["last_action"] = msg
            return msg
        else:
            return self._single_recon(target)

    def stop_recon(self, target):
        """Stop a continuous recon on a given target."""
        if target in self.active_monitors:
            self.active_monitors[target]["stop"] = True
            self.logger.info(f"Stopping continuous recon for {target}...")
            t = self._tracker_threads.pop(target, None)
            if t:
                t.join(timeout=5)

    def _single_recon(self, target):
        self.logger.info(f"IntelSquad: Performing reconnaissance on {target}...")
        self._log_and_audit("Recon", {"type": "reconnaissance", "details": {"target": target}})
        self.event_bus.publish("intel_event", {"action": "recon_initiated", "target": target})
        prompt = f"Gather open-source intelligence on {target}."
        response, is_valid, confidence = self.llm_manager.get_llm_response("hermes", prompt, "reconnaissance")
        self.logger.info(f"IntelSquad: Reconnaissance (LLM): {str(response)[:80]}...")
        self.status.update({"last_action": f"Recon on {target}", "last_result": response, "tasks_run": self.status["tasks_run"] + 1})
        entry = {"type": "recon", "target": target, "result": response, "valid": is_valid, "confidence": confidence, "ts": time.time()}
        self.history.append(entry)
        if confidence < 0.6 or not is_valid:
            self._notify_operator(f"Low-confidence recon on {target}", response)
        return response, is_valid, confidence

    def collect_targets(self, criteria):
        self.logger.info(f"IntelSquad: Collecting targets based on criteria: {criteria}...")
        self._log_and_audit("Target Collection", {"type": "target_collection", "details": {"criteria": criteria}})
        self.event_bus.publish("intel_event", {"action": "target_collection_initiated", "criteria": criteria})
        prompt = f"Identify and rank potential targets based on the following criteria: {criteria}."
        response, is_valid, confidence = self.llm_manager.get_llm_response("hermes", prompt, "target_collection")
        self.logger.info(f"IntelSquad: Target collection (LLM): {str(response)[:80]}...")
        self.status.update({"last_action": f"Target collection for {criteria}", "last_result": response, "tasks_run": self.status["tasks_run"] + 1})
        entry = {"type": "target_collection", "criteria": criteria, "result": response, "valid": is_valid, "confidence": confidence, "ts": time.time()}
        self.history.append(entry)
        if confidence < 0.6 or not is_valid:
            self._notify_operator(f"Low-confidence target collection for {criteria}", response)
        return response, is_valid, confidence

    def map_risk_opportunity_vectors(self, entity):
        self.logger.info(f"IntelSquad: Mapping risk/opportunity vectors for {entity}...")
        self._log_and_audit("Risk/Opportunity Mapping", {"type": "risk_opportunity_mapping", "details": {"entity": entity}})
        self.event_bus.publish("intel_event", {"action": "risk_opportunity_mapping_initiated", "entity": entity})
        prompt = f"Analyze and map risk and opportunity vectors for {entity}."
        response, is_valid, confidence = self.llm_manager.get_llm_response("hermes", prompt, "risk_opportunity_mapping")
        self.logger.info(f"IntelSquad: Risk/Opportunity Mapping (LLM): {str(response)[:80]}...")
        self.status.update({"last_action": f"Risk mapping for {entity}", "last_result": response, "tasks_run": self.status["tasks_run"] + 1})
        entry = {"type": "risk_opportunity", "entity": entity, "result": response, "valid": is_valid, "confidence": confidence, "ts": time.time()}
        self.history.append(entry)
        if ("high risk" in response.lower() or not is_valid):
            self._notify_operator("High risk detected", response)
        return response, is_valid, confidence

    # --- Dashboard/History/Status API ---
    def get_status(self):
        """Return live status for dashboard GUI."""
        return dict(self.status)

    def get_history(self, kind=None, limit=50):
        """Return history for dashboard GUI timeline/table."""
        filtered = [e for e in reversed(self.history) if (kind is None or e.get('type') == kind)]
        return filtered[:limit]

    # --- Operator Notification ---
    def _notify_operator(self, subject, message):
        if self.notification_manager:
            self.notification_manager.notify(subject, message)
            self.status["alerts_sent"] += 1
        self.logger.warning(f"IntelSquad: Notifying operator - {subject}: {message}")

    # --- Replay and Simulation for Audit/Testing ---
    def replay_history(self, kind=None):
        self.logger.info("IntelSquad: Replaying intelligence history...")
        filtered = [e for e in self.history if (kind is None or e.get('type') == kind)]
        for event in filtered:
            print(f"  [{time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(event['ts']))}] {event}")

    # --- Unified Command Entry Point for GUI/API ---
    def execute(self, command_details):
        """
        Main entry for the dashboard GUI or API to trigger intelligence tasks.
        Results and status are always updated for dashboard polling or websocket push.
        """
        task = command_details.get("task", "")
        details = command_details.get("details", "")

        if "perform recon" in details.lower():
            target = details.split("perform recon on ")[-1].strip()
            response, is_valid, confidence = self.perform_recon(target)
            scorecard = self.fusion_engine.fuse_signals({
                "llm_confidence": confidence, "llm_validity": is_valid, "task_complexity": 0.7
            })
            return response, is_valid, confidence, scorecard
        elif "collect targets" in details.lower():
            criteria = details.split("collect targets based on ")[-1].strip()
            response, is_valid, confidence = self.collect_targets(criteria)
            scorecard = self.fusion_engine.fuse_signals({
                "llm_confidence": confidence, "llm_validity": is_valid, "task_complexity": 0.75
            })
            return response, is_valid, confidence, scorecard
        elif "map risk opportunity" in details.lower():
            entity = details.split("map risk opportunity vectors for ")[-1].strip()
            response, is_valid, confidence = self.map_risk_opportunity_vectors(entity)
            scorecard = self.fusion_engine.fuse_signals({
                "llm_confidence": confidence, "llm_validity": is_valid, "task_complexity": 0.8
            })
            return response, is_valid, confidence, scorecard
        elif "status" in details.lower():
            return self.get_status(), True, 1.0, {}
        elif "history" in details.lower():
            kind = command_details.get("kind")
            limit = command_details.get("limit", 50)
            return self.get_history(kind, limit), True, 1.0, {}
        elif "replay" in details.lower():
            kind = command_details.get("kind")
            self.replay_history(kind)
            return "History replayed.", True, 1.0, {}
        elif "notify" in details.lower():
            self._notify_operator(command_details.get("subject", "Intel Alert"), command_details.get("message", ""))
            return "Operator notified.", True, 1.0, {}
        else:
            return "IntelSquad: Understood. Performing general intelligence tasks.", True, 0.8, {
                "success_probability": 0.8, "cost_estimate": 0.02,
                "risk_assessment": 0.1, "overall_score": 0.7
            }

    def _log_and_audit(self, message, audit_data):
        self.logger.info(message)
        if self.audit_layer:
            self.audit_layer.log(audit_data)
