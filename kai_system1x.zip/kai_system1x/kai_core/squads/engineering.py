import csv
import numpy as np
import matplotlib.pyplot as plt
from scipy.spatial import Delaunay
import ezdxf
import matplotlib.tri as mtri
import triangle as tr
import pandas as pd
from matplotlib.backends.backend_pdf import PdfPages
from PIL import Image
import pytesseract
import pdfplumber
import os
from typing import List, Tuple, Dict, Any, Optional
import logging
from kai_core.eventbus.eventbus import EventBus

# SurfaceModel class must be imported or defined above this class.
# It is assumed to implement: from_leica, from_dxf, triangulate, contour, multi_layer_cut_fill, points, breaklines.

class EngineeringSquad:
    """
    EngineeringSquad: Provides survey data ingestion, conversion, QA, and reporting.
    Supports dashboard pause/resume/shutdown and robust event handling.
    """
    def __init__(
        self,
        event_bus: EventBus,
        audit_layer=None,
        memory=None,
        llm_manager=None,
        junior_agent=None,
        path_registry=None,
        logger: Optional[logging.Logger] = None,
    ):
        self.event_bus = event_bus
        self.audit_layer = audit_layer
        self.memory = memory
        self.llm_manager = llm_manager
        self.junior_agent = junior_agent
        self.path_registry = path_registry
        self.logger = logger or logging.getLogger("EngineeringSquad")
        self.paused = False
        self.shutdown_flag = False
        self.event_bus.subscribe("engineering_log", self.handle_log_event)
        self.event_bus.subscribe("engineering_error", self.handle_error_event)
        self.logger.debug("EngineeringSquad initialized and event bus subscriptions set.")

    # --- Dashboard Control Methods ---
    def pause(self):
        self.paused = True
        msg = "Engineering squad paused."
        self.publish_status(msg)
        self.logger.info(msg)

    def resume(self):
        self.paused = False
        msg = "Engineering squad resumed."
        self.publish_status(msg)
        self.logger.info(msg)

    def shutdown(self):
        self.shutdown_flag = True
        msg = "Engineering squad shutdown requested."
        self.publish_status(msg)
        self.logger.info(msg)

    # --- EventBus Publishing ---
    def handle_log_event(self, event_type, details):
        self.logger.info(f"[LOG] {event_type}: {details}")

    def handle_error_event(self, event_type, details):
        self.logger.error(f"[ERROR] {event_type}: {details}")

    def publish_log(self, msg: str):
        self.event_bus.publish('engineering_log', msg)

    def publish_error(self, msg: str):
        self.event_bus.publish('engineering_error', msg)

    def publish_status(self, msg: str):
        self.event_bus.publish('status', {"squad": "engineering", "message": msg})

    # --- File Upload Handler (optional, dashboard integration) ---
    def handle_uploaded_file(self, file_path):
        msg = f"File uploaded to engineering: {file_path}"
        self.publish_log(msg)
        return True, msg

    # --- Utility Methods (check paused/shutdown) ---
    def _check_paused(self):
        if self.paused:
            return True, "Engineering squad is paused."
        if self.shutdown_flag:
            return True, "Engineering squad is shut down."
        return False, ""

    # --- Main Functionalities ---
    def convert_excel_to_csv(self, excel_path, output_csv_path):
        paused, msg = self._check_paused()
        if paused:
            return False, msg
        try:
            df = pd.read_excel(excel_path)
            df.to_csv(output_csv_path, index=False)
            self.publish_log(f'Successfully converted Excel {excel_path} to CSV {output_csv_path}')
            return True, f'Successfully converted Excel {excel_path} to CSV {output_csv_path}'
        except Exception as e:
            self.publish_error(f'Error converting Excel to CSV: {e}')
            return False, f'Error converting Excel to CSV: {e}'

    def convert_pdf_to_csv(self, pdf_path, output_csv_path):
        paused, msg = self._check_paused()
        if paused:
            return False, msg
        try:
            all_text = ''
            with pdfplumber.open(pdf_path) as pdf:
                for page in pdf.pages:
                    all_text += (page.extract_text() or '') + '\n'
            lines = all_text.strip().split('\n')
            if not lines:
                self.publish_error(f'No text extracted from PDF: {pdf_path}')
                return False, 'No text extracted from PDF'
            with open(output_csv_path, 'w', newline='') as csvfile:
                writer = csv.writer(csvfile)
                for line in lines:
                    writer.writerow(line.split())
            self.publish_log(f'Successfully converted PDF {pdf_path} to CSV {output_csv_path}')
            return True, f'Successfully converted PDF {pdf_path} to CSV {output_csv_path}'
        except Exception as e:
            self.publish_error(f'Error converting PDF to CSV: {e}')
            return False, f'Error converting PDF to CSV: {e}'

    def convert_image_to_csv(self, image_path, output_csv_path):
        paused, msg = self._check_paused()
        if paused:
            return False, msg
        try:
            text = pytesseract.image_to_string(Image.open(image_path))
            if not text.strip():
                self.publish_error(f'No text recognized from image: {image_path}')
                return False, 'No text recognized from image'
            lines = text.strip().split('\n')
            with open(output_csv_path, 'w', newline='') as csvfile:
                writer = csv.writer(csvfile)
                for line in lines:
                    writer.writerow(line.split())
            self.publish_log(f'Successfully converted image {image_path} to CSV {output_csv_path}')
            return True, f'Successfully converted image {image_path} to CSV {output_csv_path}'
        except Exception as e:
            self.publish_error(f'Error converting image to CSV: {e}')
            return False, f'Error converting image to CSV: {e}'

    def ingest_leica_csv(self, csv_path):
        paused, msg = self._check_paused()
        if paused:
            return False, msg
        try:
            surf_model = SurfaceModel.from_leica(csv_path)
            self.publish_log(f'Successfully ingested Leica CSV: {csv_path}')
            return True, f'Successfully ingested Leica CSV: {csv_path}'
        except Exception as e:
            self.publish_error(f'Error ingesting Leica CSV: {e}')
            return False, f'Error ingesting Leica CSV: {e}'

    def compare_survey_data(self, design_csv_path, asbuilt_csv_path):
        paused, msg = self._check_paused()
        if paused:
            return False, msg
        try:
            design_df = pd.read_csv(design_csv_path)
            asbuilt_df = pd.read_csv(asbuilt_csv_path)
            comparison_results = f'Design CSV has {len(design_df)} points.\nAs-Built CSV has {len(asbuilt_df)} points.\n'
            merged_df = pd.merge(design_df, asbuilt_df, on=['X', 'Y', 'Z'], how='outer', indicator=True)
            new_points_in_asbuilt = merged_df[merged_df['_merge'] == 'right_only']
            if not new_points_in_asbuilt.empty:
                comparison_results += f'\nFound {len(new_points_in_asbuilt)} points in As-Built not in Design (based on X,Y,Z match):\n'
                comparison_results += new_points_in_asbuilt.to_string()
            else:
                comparison_results += '\nAll As-Built points (based on X,Y,Z) found in Design.'
            self.publish_log(f'Comparison complete: {comparison_results}')
            return True, comparison_results
        except Exception as e:
            self.publish_error(f'Error comparing survey data: {e}')
            return False, f'Error comparing survey data: {e}'

    def generate_asb_report(self, csv_path, dxf_path, formations, output_pdf_path, output_csv_path=None):
        paused, msg = self._check_paused()
        if paused:
            return False, msg
        try:
            surf = SurfaceModel.from_leica(csv_path)
            if dxf_path and os.path.exists(dxf_path):
                dxf_surf = SurfaceModel.from_dxf(dxf_path)
                surf.points += dxf_surf.points
                surf.breaklines += dxf_surf.breaklines
            surf.triangulate()
            contour_png = output_pdf_path.replace(".pdf", "_contour.png")
            surf.contour(contour_png)
            summary = surf.multi_layer_cut_fill(formations)
            summary_df = pd.DataFrame(summary)
            # Save optional CSV
            if output_csv_path:
                summary_df.to_csv(output_csv_path, index=False)
                self.publish_log(f"ASB report CSV summary saved: {output_csv_path}")
            # Generate PDF
            with PdfPages(output_pdf_path) as pdf:
                # Table
                plt.figure(figsize=(8, 1 + len(formations)*0.5))
                plt.axis('off')
                plt.title('Cut/Fill Volumes')
                table = plt.table(
                    cellText=summary_df.values,
                    colLabels=summary_df.columns,
                    loc='center'
                )
                table.auto_set_font_size(False)
                table.set_fontsize(10)
                table.scale(1, 1.5)
                pdf.savefig(); plt.close()
                # Contour plot
                img = plt.imread(contour_png); plt.figure(figsize=(10,8))
                plt.imshow(img); plt.axis('off')
                pdf.savefig(); plt.close()
            self.publish_log(f'Successfully generated AS-BUILT report: {output_pdf_path}')
            return True, f'Successfully generated AS-BUILT report: {output_pdf_path}'
        except Exception as e:
            self.publish_error(f'Error generating ASB report: {e}')
            return False, f'Error generating ASB report: {e}'

    def generate_qa_report(self, csv_path, dxf_path, formation, output_pdf_path):
        return self.generate_asb_report(csv_path, dxf_path, [{'name': 'Formation', 'level': formation}], output_pdf_path)

    def validate_surface(self, csv_path):
        paused, msg = self._check_paused()
        if paused:
            return False, msg
        try:
            sm = SurfaceModel.from_leica(csv_path)
            num_points = len(sm.points)
            elevs = [p[2] for p in sm.points]
            min_elev, max_elev = min(elevs), max(elevs)
            summary = {
                'num_points': num_points,
                'min_elevation': min_elev,
                'max_elevation': max_elev,
                'has_breaklines': bool(sm.breaklines)
            }
            msg = f"Validation: Points={num_points}, Elevation range=({min_elev}, {max_elev}), Breaklines={bool(sm.breaklines)}"
            self.publish_log(msg)
            return True, summary
        except Exception as e:
            self.publish_error(f'Error validating surface: {e}')
            return False, f'Error validating surface: {e}'

    # --- Dashboard Chat/Command Entry Point ---
    def process_command(self, command):
        cmd = (command or "").strip().lower()
        paused, msg = self._check_paused()
        if paused:
            return {"response": msg}
        # Basic command routing -- extend for richer chat/command support
        if cmd in ("pause", "resume", "shutdown"):
            getattr(self, cmd)()
            return {"response": f"Engineering squad: {cmd} command processed."}
        if cmd == "status":
            return {"response": f"Engineering squad is {'paused' if self.paused else 'active'}."}
        return {"response": f"Engineering squad received: '{command}'"}

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    event_bus = EventBus()
    squad = EngineeringSquad(event_bus)
    # Now you can call squad.* methods and all logs/errors are handled via EventBus and logger.
