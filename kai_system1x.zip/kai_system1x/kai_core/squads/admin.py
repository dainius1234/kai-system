import threading
import datetime
import logging
import time
from collections import deque, defaultdict
from pathlib import Path
from typing import Dict, Any, Optional, List, Callable
import importlib.util
import sys

# --- External integrations (replace with your actual implementations) ---
from kai_core.memory.memory import Memory  # Your persistent key-value store
from kai_core.audit.audit_layer import AuditLayer  # Your audit/log system
from kai_core.notifier.notifier import Notifier  # Push notifications
from kai_core.llm.llm_manager import LLMManager  # LLM/AI interface
from kai_core.fusion.fusion_engine import FusionEngine  # Signal fusion/decision
from kai_core.event.event_bus import EventBus  # Pub/sub for events

# --- Plugin system expects Python modules in plugin_dir with a 'run(params)' function ---

class AdminTask:
    def __init__(self, action: str, params: dict = None, initiator: str = "system", tenant: str = "default"):
        self.action = action
        self.params = params or {}
        self.initiator = initiator
        self.tenant = tenant
        self.status = "pending"
        self.result = None
        self.created_at = datetime.datetime.now().isoformat()
        self.started_at = None
        self.completed_at = None

class AdminSquad:
    """
    Ultimate AdminSquad for Kai:
    - REST API & WebSocket integration, SIEM, secrets, multi-tenancy, RBAC, policy engine, plugin, self-heal, LLM, etc.
    - Integrated with construction planning and accounting squads.
    """
    def __init__(
        self,
        event_bus: EventBus,
        audit_layer: AuditLayer,
        memory: Memory,
        llm_manager: LLMManager,
        fusion_engine: FusionEngine,
        notifier: Optional[Notifier] = None,
        logger: Optional[logging.Logger] = None,
        plugin_dir: str = "./admin_plugins",
        construction_planning_squad=None,
        accounting_squad=None
    ):
        self.event_bus = event_bus
        self.audit_layer = audit_layer
        self.memory = memory
        self.llm_manager = llm_manager
        self.fusion_engine = fusion_engine
        self.notifier = notifier
        self.logger = logger or logging.getLogger("AdminSquad")
        self.paused = False
        self.shutdown_flag = False
        self.tenants = defaultdict(self._init_tenant_struct)
        self._plugin_dir = Path(plugin_dir)
        self._plugins = {}
        self._load_plugins()
        self._task_queue = deque()
        self._task_queue_lock = threading.Lock()
        self._batch_thread = threading.Thread(target=self._process_task_queue, daemon=True)
        self._batch_thread.start()
        self._publish_status("AdminSquad initialized.", level="info", tenant="default")

        # Integration with other squads
        self.construction_planning_squad = construction_planning_squad
        self.accounting_squad = accounting_squad

        # Subscribe to system-wide events for cross-squad integration
        if self.event_bus:
            self.event_bus.subscribe("construction_project_created", self._on_construction_event)
            self.event_bus.subscribe("construction_reports_generated", self._on_construction_event)
            self.event_bus.subscribe("accounting_event", self._on_accounting_event)
            self.event_bus.subscribe("admin_status", self._on_admin_event)

    def _init_tenant_struct(self):
        return {
            "users": set(),
            "roles": defaultdict(set),  # role -> set of users
            "tasks": deque(),
            "audit_log": [],
            "last_activity": None,
        }

    def link_construction_planning(self, squad):
        self.construction_planning_squad = squad

    def link_accounting(self, squad):
        self.accounting_squad = squad

    # --------------- Event Handlers ---------------
    def _on_construction_event(self, event):
        if isinstance(event, dict):
            if event.get("project_name"):
                self._publish_status(f"[Admin] Event from Construction: {event.get('project_name')} {event.get('reports', '')}")
            if event.get("type") == "construction_reports_generated" and self.accounting_squad:
                self.accounting_squad.receive_construction_report(event["project_name"], event.get("reports", {}))

    def _on_accounting_event(self, event):
        if isinstance(event, dict) and 'type' in event:
            self._publish_status(f"[Admin] Accounting event: {event['type']}")
            if event["type"] == "budget_overrun" and self.construction_planning_squad:
                self.construction_planning_squad.handle_budget_overrun(event.get("project_name"), event.get("details", {}))

    def _on_admin_event(self, event):
        if isinstance(event, dict) and "paused" in event.get("message", "").lower():
            self.paused = True
            if self.construction_planning_squad and hasattr(self.construction_planning_squad, "pause"):
                self.construction_planning_squad.pause()
            if self.accounting_squad and hasattr(self.accounting_squad, "pause"):
                self.accounting_squad.pause()

    # --------------- Plugin Loader ---------------
    def _load_plugins(self):
        if not self._plugin_dir.exists() or not self._plugin_dir.is_dir():
            self.logger.warning(f"Plugin directory {self._plugin_dir} does not exist.")
            return
        for plugin_file in self._plugin_dir.glob("*.py"):
            plugin_name = plugin_file.stem
            try:
                spec = importlib.util.spec_from_file_location(plugin_name, plugin_file)
                module = importlib.util.module_from_spec(spec)
                sys.modules[plugin_name] = module
                spec.loader.exec_module(module)
                self._plugins[plugin_name] = module
                self.logger.info(f"Loaded plugin: {plugin_name}")
            except Exception as e:
                self.logger.error(f"Failed to load plugin {plugin_name}: {e}")

    def get_plugin(self, name: str):
        return self._plugins.get(name)

    # --------------- Task Queue System ---------------
    def submit_task(self, action: str, params: dict = None, initiator: str = "system", tenant: str = "default"):
        task = AdminTask(action, params, initiator, tenant)
        with self._task_queue_lock:
            self._task_queue.append(task)
        self.logger.info(f"Task submitted: {action} by {initiator} for tenant {tenant}")
        return task

    def _process_task_queue(self):
        while not self.shutdown_flag:
            if self.paused:
                time.sleep(1)
                continue
            try:
                with self._task_queue_lock:
                    task = self._task_queue.popleft() if self._task_queue else None
                if task:
                    self._process_task(task)
                else:
                    time.sleep(0.1)
            except Exception as e:
                self.logger.error(f"Error in task processor: {e}")
                time.sleep(1)

    def _process_task(self, task: AdminTask):
        task.started_at = datetime.datetime.now().isoformat()
        try:
            # RBAC and policy check
            if not self._policy_check(task):
                task.status = "denied"
                task.result = "Policy denied action"
                self.logger.warning(f"Task denied by policy: {task.action}")
                return

            # Plugin hook
            plugin = self.get_plugin(task.action)
            if plugin and hasattr(plugin, "run"):
                result = plugin.run(task.params)
            else:
                # Fallback: LLM suggestion
                result = self.llm_manager.suggest_action(vars(task))

            task.status = "completed"
            task.result = result
            self.logger.info(f"Task completed: {task.action} result={result}")
        except Exception as e:
            task.status = "failed"
            task.result = str(e)
            self.logger.error(f"Task failed: {e}")
        finally:
            task.completed_at = datetime.datetime.now().isoformat()
            self._audit_task(task)

    def _audit_task(self, task: AdminTask):
        # Send to audit layer and persist in memory
        if self.audit_layer and hasattr(self.audit_layer, "log_task"):
            self.audit_layer.log_task(vars(task))
        # Store in-memory audit log as fallback
        tenant_log = self.tenants[task.tenant]["audit_log"]
        tenant_log.append(vars(task))
        self.memory.set(f"admin_audit_{task.tenant}", tenant_log)

    # --------------- RBAC & Policy ---------------
    def add_user(self, username: str, tenant: str = "default"):
        self.tenants[tenant]["users"].add(username)
        self.tenants[tenant]["last_activity"] = datetime.datetime.now().isoformat()

    def assign_role(self, username: str, role: str, tenant: str = "default"):
        self.tenants[tenant]["roles"][role].add(username)
        self.tenants[tenant]["last_activity"] = datetime.datetime.now().isoformat()

    def check_role(self, username: str, role: str, tenant: str = "default") -> bool:
        return username in self.tenants[tenant]["roles"].get(role, set())

    def remove_user(self, username: str, tenant: str = "default"):
        self.tenants[tenant]["users"].discard(username)
        for role_users in self.tenants[tenant]["roles"].values():
            role_users.discard(username)
        self.tenants[tenant]["last_activity"] = datetime.datetime.now().isoformat()

    def _policy_check(self, task: AdminTask) -> bool:
        # Example: Only allow if initiator has 'admin' role
        return self.check_role(task.initiator, 'admin', task.tenant)

    # --------------- Notification, Status, and Pause ---------------
    def _publish_status(self, message: str, level: str = "info", tenant: str = "default"):
        event = {
            "timestamp": datetime.datetime.now().isoformat(),
            "level": level,
            "message": message,
            "tenant": tenant
        }
        if self.notifier and hasattr(self.notifier, "notify"):
            self.notifier.notify(event)
        self.logger.log(getattr(logging, level.upper(), logging.INFO), message)
        self.memory.set(f"admin_status_{tenant}", event)

    def pause(self):
        self.paused = True
        self._publish_status("AdminSquad paused.", level="warning")

    def resume(self):
        self.paused = False
        self._publish_status("AdminSquad resumed.", level="info")

    def shutdown(self):
        self.shutdown_flag = True
        self._publish_status("AdminSquad shutting down.", level="critical")

    # --------------- Integration Examples ---------------
    def trigger_construction_report(self, project_name):
        if self.construction_planning_squad and hasattr(self.construction_planning_squad, "generate_reports"):
            return self.construction_planning_squad.generate_reports(project_name=project_name)
        else:
            return {"status": "error", "message": "No construction planning squad connected."}

    def trigger_accounting_reconcile(self, project_name):
        if self.accounting_squad and hasattr(self.accounting_squad, "reconcile_project"):
            return self.accounting_squad.reconcile_project(project_name=project_name)
        else:
            return {"status": "error", "message": "No accounting squad connected."}

    # --------------- Secrets ---------------
    def get_secret(self, key: str):
        # Example: Use your secrets manager
        return self.memory.get_secret(key)

    def set_secret(self, key: str, value: str):
        # Example: Use your secrets manager
        return self.memory.set_secret(key, value)

    # --------------- LLM/AI Hook Example ---------------
    def suggest_next_action(self, context: Dict[str, Any]) -> str:
        return self.llm_manager.suggest_action(context)

    # --------------- Utility / Info ---------------
    def list_plugins(self) -> List[str]:
        return list(self._plugins.keys())

    def list_tasks(self, tenant: str = "default") -> List[Dict[str, Any]]:
        return list(self.tenants[tenant]["audit_log"])

    def get_audit_log(self, tenant: str = "default") -> List[Dict[str, Any]]:
        return list(self.tenants[tenant]["audit_log"])
