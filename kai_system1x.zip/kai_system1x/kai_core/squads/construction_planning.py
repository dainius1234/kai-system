
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from datetime import datetime, timedelta
import numpy as np
import os
from kai_core.memory.path_registry import PathRegistry

class ConstructionPlanner:
    def __init__(self, project_name, start_date, end_date, path_registry: PathRegistry, work_days=[0,1,2,3,4]):
        self.project_name = project_name
        self.start_date = datetime.strptime(start_date, "%Y-%m-%d")
        self.end_date = datetime.strptime(end_date, "%Y-%m-%d")
        self.path_registry = path_registry
        self.work_days = set(work_days)
        self.holidays = set()
        self.resources = {}
        self.activities = []
        self.schedule = pd.DataFrame()

    def add_holiday(self, holiday_date):
        d = datetime.strptime(holiday_date, "%Y-%m-%d")
        self.holidays.add(d)

    def add_resource(self, resource_type, quantity, cost_rate):
        self.resources[resource_type] = {
            "quantity": quantity,
            "cost_rate": cost_rate,
        }

    def add_activity(self, activity_id, name, trade, duration, predecessors=None, resource_req=None, status="Not Started", cost=0, budget=0, risk_level="Low"):
        act = {
            "activity_id": activity_id,
            "name": name,
            "trade": trade,
            "duration": duration,
            "predecessors": predecessors or [],
            "resource_req": resource_req or {},
            "status": status,
            "cost": cost,
            "budget": budget,
            "risk_level": risk_level
        }
        self.activities.append(act)

    def update_project_budget(self, new_budget):
        for act in self.activities:
            act["budget"] = new_budget

    def calculate_schedule(self):
        if not self.activities:
            self.schedule = pd.DataFrame()
            return
        df = pd.DataFrame(self.activities)
        df["early_start"] = None
        df["early_finish"] = None
        act_id_to_finish = {}
        for idx, row in df.iterrows():
            if not row["predecessors"]:
                start = self._next_workday(self.start_date)
            else:
                max_pred_finish = max(
                    [act_id_to_finish.get(pred, self.start_date) for pred in row["predecessors"]],
                    default=self.start_date
                )
                start = self._next_workday(max_pred_finish)
            finish = self._add_workdays(start, row["duration"])
            df.at[idx, "early_start"] = start
            df.at[idx, "early_finish"] = finish
            act_id_to_finish[row["activity_id"]] = finish
        self.schedule = df

    def _next_workday(self, date):
        while date.weekday() not in self.work_days or date in self.holidays:
            date += timedelta(days=1)
        return date

    def _add_workdays(self, date, days):
        count = 0
        current = date
        while count < days:
            if current.weekday() in self.work_days and current not in self.holidays:
                count += 1
                if count == days:
                    break
            current += timedelta(days=1)
        return current

    def export_excel_schedule(self):
        if self.schedule is None or self.schedule.empty:
            self.calculate_schedule()
        output_dir = self.path_registry.get_path("reports") or "."
        os.makedirs(output_dir, exist_ok=True)
        file_path = os.path.join(output_dir, f"{self.project_name}_schedule.xlsx")
        self.schedule.to_excel(file_path, index=False)
        return file_path

    def plot_long_term_schedule(self):
        if self.schedule is None or self.schedule.empty:
            self.calculate_schedule()
        fig, ax = plt.subplots(figsize=(12, 6))
        for idx, row in self.schedule.iterrows():
            ax.barh(
                row["name"],
                (row["early_finish"] - row["early_start"]).days,
                left=row["early_start"],
                color="skyblue"
            )
        ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y-%m-%d"))
        plt.title(f"Long-Term Project Schedule: {self.project_name}")
        plt.xlabel("Date")
        plt.ylabel("Activity")
        plt.tight_layout()
        output_dir = self.path_registry.get_path("reports") or "."
        os.makedirs(output_dir, exist_ok=True)
        file_path = os.path.join(output_dir, f"{self.project_name}_gantt.png")
        plt.savefig(file_path)
        plt.close(fig)
        return file_path

    def plot_two_week_lookahead(self):
        if self.schedule is None or self.schedule.empty:
            self.calculate_schedule()
        fig, ax = plt.subplots(figsize=(12, 6))
        lookahead_start = datetime.now()
        lookahead_end = lookahead_start + timedelta(days=14)
        sched = self.schedule[
            (self.schedule["early_start"] <= lookahead_end) &
            (self.schedule["early_finish"] >= lookahead_start)
        ]
        for idx, row in sched.iterrows():
            ax.barh(
                row["name"],
                (row["early_finish"] - row["early_start"]).days,
                left=row["early_start"],
                color="orange"
            )
        ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y-%m-%d"))
        plt.title(f"2-Week Lookahead: {self.project_name}")
        plt.xlabel("Date")
        plt.ylabel("Activity")
        plt.tight_layout()
        output_dir = self.path_registry.get_path("reports") or "."
        os.makedirs(output_dir, exist_ok=True)
        file_path = os.path.join(output_dir, f"{self.project_name}_lookahead.png")
        plt.savefig(file_path)
        plt.close(fig)
        return file_path

    def plot_resource_utilization(self):
        if self.schedule is None or self.schedule.empty:
            self.calculate_schedule()
        timeline = pd.date_range(self.start_date, self.end_date)
        utilization = {res: np.zeros(len(timeline)) for res in self.resources}
        for idx, row in self.schedule.iterrows():
            act_req = row["resource_req"] if "resource_req" in row and row["resource_req"] else {}
            start_idx = (row["early_start"] - self.start_date).days
            end_idx = (row["early_finish"] - self.start_date).days
            for res, qty in act_req.items():
                if res in utilization:
                    utilization[res][start_idx:end_idx] += qty
        fig, ax = plt.subplots(figsize=(12, 6))
        for res, data in utilization.items():
            ax.plot(timeline, data, label=res)
        plt.legend()
        plt.title(f"Resource Utilization: {self.project_name}")
        plt.xlabel("Date")
        plt.ylabel("Resource Usage")
        plt.tight_layout()
        output_dir = self.path_registry.get_path("reports") or "."
        os.makedirs(output_dir, exist_ok=True)
        file_path = os.path.join(output_dir, f"{self.project_name}_resource_utilization.png")
        plt.savefig(file_path)
        plt.close(fig)
        return file_path

    def to_dict(self):
        return {
            "project_name": self.project_name,
            "start_date": self.start_date.strftime("%Y-%m-%d"),
            "end_date": self.end_date.strftime("%Y-%m-%d"),
            "resources": self.resources,
            "activities": self.activities,
            "holidays": [d.strftime("%Y-%m-%d") for d in self.holidays]
        }

class ConstructionPlanningSquad:
    def __init__(
        self,
        event_bus,
        audit_layer,
        memory,
        llm_manager,
        junior_agent,
        path_registry: PathRegistry,
        admin_squad=None,
        accounting_squad=None
    ):
        self.event_bus = event_bus
        self.audit_layer = audit_layer
        self.memory = memory
        self.llm_manager = llm_manager
        self.junior_agent = junior_agent
        self.path_registry = path_registry
        self.planners = {}  # project_name -> ConstructionPlanner
        self.current_project_name = None
        self.admin_squad = admin_squad
        self.accounting_squad = accounting_squad
        self.paused = False
        if self.event_bus:
            self.event_bus.subscribe("admin_status", self._on_admin_event)
            self.event_bus.subscribe("accounting_event", self._on_accounting_event)

    def link_admin(self, admin_squad):
        self.admin_squad = admin_squad

    def link_accounting(self, accounting_squad):
        self.accounting_squad = accounting_squad

    def _on_admin_event(self, event):
        if isinstance(event, dict) and "paused" in event.get("message", "").lower():
            self.paused = True
        if isinstance(event, dict) and "resumed" in event.get("message", "").lower():
            self.paused = False

    def _on_accounting_event(self, event):
        if (
            isinstance(event, dict)
            and event.get("type") == "budget_update"
            and self.current_project_name
        ):
            planner = self.planners.get(self.current_project_name)
            if planner and hasattr(planner, "update_project_budget"):
                new_budget = event.get("budget")
                planner.update_project_budget(new_budget)

    def create_project(self, project_name, start_date, end_date, work_days=[0, 1, 2, 3, 4]):
        if self.paused:
            raise RuntimeError("System is paused.")
        if project_name in self.planners:
            raise ValueError(f"Project '{project_name}' already exists.")
        planner = ConstructionPlanner(project_name, start_date, end_date, self.path_registry, work_days)
        self.planners[project_name] = planner
        self.current_project_name = project_name
        self._persist_state()
        self.audit_layer.log({"type": "construction_project_created", "project_name": project_name})
        self.event_bus.publish("construction_project_created", {"project_name": project_name})
        if self.admin_squad:
            self.admin_squad._publish_status(f"Project created: {project_name} by ConstructionPlanningSquad.")
        return planner

    def switch_project(self, project_name):
        if project_name not in self.planners:
            raise ValueError(f"Project '{project_name}' not found.")
        self.current_project_name = project_name

    def add_holiday(self, holiday_date, project_name=None):
        if self.paused:
            raise RuntimeError("System is paused.")
        planner = self._get_planner(project_name)
        planner.add_holiday(holiday_date)
        self._persist_state()

    def add_resource(self, resource_type, quantity, cost_rate, project_name=None):
        if self.paused:
            raise RuntimeError("System is paused.")
        planner = self._get_planner(project_name)
        planner.add_resource(resource_type, quantity, cost_rate)
        self._persist_state()

    def add_activity(self, activity_id, name, trade, duration, predecessors=None,
                     resource_req=None, status="Not Started", cost=0, budget=0,
                     risk_level="Low", project_name=None):
        if self.paused:
            raise RuntimeError("System is paused.")
        planner = self._get_planner(project_name)
        planner.add_activity(activity_id, name, trade, duration, predecessors,
                             resource_req, status, cost, budget, risk_level)
        self._persist_state()
        if self.accounting_squad and hasattr(self.accounting_squad, "register_activity_cost"):
            self.accounting_squad.register_activity_cost(
                project_name=planner.project_name,
                activity_name=name,
                cost=cost,
                budget=budget
            )
        if self.admin_squad and hasattr(self.admin_squad, "_publish_status"):
            self.admin_squad._publish_status(
                f"New activity '{name}' added to {planner.project_name} by ConstructionPlanningSquad."
            )

    def generate_reports(self, project_name=None):
        if self.paused:
            raise RuntimeError("System is paused.")
        planner = self._get_planner(project_name)
        planner.calculate_schedule()
        reports = {
            "excel_report": planner.export_excel_schedule(),
            "long_term_gantt_chart": planner.plot_long_term_schedule(),
            "lookahead_chart": planner.plot_two_week_lookahead(),
            "resource_utilization_chart": planner.plot_resource_utilization()
        }
        self._persist_state()
        self.audit_layer.log({"type": "construction_reports_generated", "project_name": planner.project_name})
        self.event_bus.publish("construction_reports_generated", {"project_name": planner.project_name, "reports": reports})
        if self.admin_squad and hasattr(self.admin_squad, "_publish_status"):
            self.admin_squad._publish_status(f"Reports generated for {planner.project_name}.")
        if self.accounting_squad and hasattr(self.accounting_squad, "notify_reports_generated"):
            self.accounting_squad.notify_reports_generated(planner.project_name, reports)
        return reports

    def get_project_status(self, project_name=None):
        planner = self._get_planner(project_name, required=False)
        if planner:
            return planner.to_dict()
        else:
            return {"error": "No project initialized."}

    def get_activities(self, project_name=None):
        planner = self._get_planner(project_name, required=False)
        if planner:
            return planner.activities
        else:
            return []

    def get_reports_paths(self, project_name=None):
        planner = self._get_planner(project_name, required=False)
        if planner:
            output_dir = planner.path_registry.get_path("reports") or "."
            files = [os.path.join(output_dir, f) for f in os.listdir(output_dir) if planner.project_name in f]
            return files
        return []

    def list_projects(self):
        return list(self.planners.keys())

    def delete_project(self, project_name):
        if project_name in self.planners:
            del self.planners[project_name]
            if self.current_project_name == project_name:
                self.current_project_name = None if not self.planners else next(iter(self.planners))
            self._persist_state()

    def _get_planner(self, project_name=None, required=True):
        name = project_name or self.current_project_name
        if not name or name not in self.planners:
            if required:
                raise RuntimeError("No project initialized or selected.")
            else:
                return None
        return self.planners[name]

    def pause(self):
        self.paused = True
        if self.admin_squad:
            self.admin_squad._publish_status("ConstructionPlanningSquad paused.")

    def resume(self):
        self.paused = False
        if self.admin_squad:
            self.admin_squad._publish_status("ConstructionPlanningSquad resumed.")

    def suggest_next_action(self, context=None):
        ctx = context or {"state": self.get_project_status()}
        if self.llm_manager:
            return self.llm_manager.suggest_action(ctx)
        return None

    def save_to_memory(self):
        data = {
            "projects": {name: planner.to_dict() for name, planner in self.planners.items()},
            "current_project_name": self.current_project_name
        }
        self.memory.set("construction_planning_state", data)

    def load_from_memory(self):
        data = self.memory.get("construction_planning_state")
        if not data:
            return
        self.planners = {}
        for name, project in data.get("projects", {}).items():
            planner = ConstructionPlanner(
                project_name=project["project_name"],
                start_date=project["start_date"],
                end_date=project["end_date"],
                path_registry=self.path_registry
            )
            for holiday in project.get("holidays", []):
                planner.add_holiday(holiday)
            for res, info in project.get("resources", {}).items():
                planner.add_resource(res, info["quantity"], info["cost_rate"])
            for act in project.get("activities", []):
                planner.add_activity(
                    act["activity_id"], act["name"], act["trade"], act["duration"],
                    act.get("predecessors"), act.get("resource_req"), act.get("status"),
                    act.get("cost", 0), act.get("budget", 0), act.get("risk_level", "Low")
                )
            self.planners[name] = planner
        self.current_project_name = data.get("current_project_name")

    def _persist_state(self):
        self.save_to_memory()
