import time
import threading
import logging

class PlannerSubSquad:
    """
    PlannerSubSquad: Smart assistant to PlannerSquad for long-term vision, scenario simulation, and adaptive strategy.
    - Forecasts long-term vision, simulates scenarios, and adapts strategies based on constraints and cross-squad context.
    - Tracks, manages, and escalates constraints, vision drift, and strategic inflection points.
    - Background monitoring for vision/constraint changes; auto-notifies PlannerSquad and GUI.
    - Integrates with PlannerSquad, Admin, Accounting, Construction, Trading, and LegalSquad for richer context.
    - Dashboard/API ready: exposes status, event history, live feedback, and unified actions.
    """

    def __init__(
        self, event_bus, audit_layer, memory, llm_manager, fusion_engine,
        planner_squad=None, admin_squad=None, accounting_squad=None, construction_squad=None, trading_squad=None, legal_squad=None,
        notification_manager=None, logger=None
    ):
        self.event_bus = event_bus
        self.audit_layer = audit_layer
        self.memory = memory
        self.llm_manager = llm_manager
        self.fusion_engine = fusion_engine
        self.planner_squad = planner_squad
        self.admin_squad = admin_squad
        self.accounting_squad = accounting_squad
        self.construction_squad = construction_squad
        self.trading_squad = trading_squad
        self.legal_squad = legal_squad
        self.notification_manager = notification_manager
        self.logger = logger or logging.getLogger("PlannerSubSquad")
        self.status = {
            "last_action": None,
            "last_result": None,
            "tasks_run": 0,
            "alerts_sent": 0,
            "active_background": False,
            "tracked_constraints": [],
        }
        self.history = []
        self._stop_tracking = False
        self._tracker_thread = None
        self.logger.info("PlannerSubSquad: Initialized for advanced long-term vision, scenario, and adaptation.")

    # --- Background Vision & Constraint Monitoring ---
    def start_background_tracking(self, interval=120):
        """Launch background monitoring for vision drift, constraint emergence, and cross-squad alerts."""
        if self._tracker_thread and self._tracker_thread.is_alive():
            self.logger.info("PlannerSubSquad: Background tracking already running.")
            return
        self._stop_tracking = False
        def tracker():
            while not self._stop_tracking:
                try:
                    self.background_check()
                except Exception as e:
                    self.logger.error(f"PlannerSubSquad: Error in background_check: {e}")
                time.sleep(interval)
        self._tracker_thread = threading.Thread(target=tracker, daemon=True)
        self._tracker_thread.start()
        self.status["active_background"] = True
        self.logger.info("PlannerSubSquad: Background vision/constraint tracking started.")

    def stop_background_tracking(self):
        self._stop_tracking = True
        self.status["active_background"] = False
        if self._tracker_thread:
            self._tracker_thread.join(timeout=5)
        self.logger.info("PlannerSubSquad: Background tracking stopped.")

    def background_check(self):
        """
        Periodically check for vision drift, new constraints, cross-squad events, or strategic adjustments.
        Escalate to PlannerSquad and notify GUI if required.
        """
        now = time.time()
        constraints = self.status["tracked_constraints"]
        vision_state = self.memory.get("vision_state", "stable") if hasattr(self.memory, "get") else "stable"
        context = self._cross_squad_context()

        # Example logic for drift and constraint detection; replace with real logic in production
        drift_detected = False  # Replace with real vision drift detection
        new_constraint = None   # Replace with real constraint detection

        # Cross-squad legal/compliance trigger (example)
        if self.legal_squad:
            legal_status = self.legal_squad.get_status()
            if legal_status.get("last_action") == "Risk assessment" and "risk" in (legal_status.get("last_result") or ""):
                self._notify_operator("Legal/Compliance Risk", legal_status.get("last_result"))
                self._escalate_to_planner("legal_risk", legal_status.get("last_result"))

        self.status["last_action"] = "Background check"
        self.status["last_result"] = f"Drift: {drift_detected}, New constraint: {new_constraint}"
        self.status["tasks_run"] += 1
        self.status["last_check"] = now
        self.event_bus.publish("planner_sub_event", {
            "action": "background_check",
            "drift": drift_detected,
            "new_constraint": new_constraint,
            "timestamp": now
        })

    def _cross_squad_context(self):
        """Aggregate context from connected squads for smarter advice and simulation."""
        context = {}
        if self.planner_squad: context['planner'] = self.planner_squad.get_status()
        if self.admin_squad: context['admin'] = self.admin_squad.get_status()
        if self.accounting_squad: context['accounting'] = self.accounting_squad.get_status()
        if self.construction_squad: context['construction'] = self.construction_squad.get_status()
        if self.trading_squad: context['trading'] = self.trading_squad.get_status()
        if self.legal_squad: context['legal'] = self.legal_squad.get_status()
        return context

    def _escalate_to_planner(self, event_type, *args):
        if self.planner_squad and hasattr(self.planner_squad, "execute"):
            try:
                self.planner_squad.execute({
                    "task": "escalation",
                    "details": f"PlannerSubSquad escalation: {event_type} {args}"
                })
            except Exception as e:
                self.logger.error(f"PlannerSubSquad: Failed to escalate to PlannerSquad: {e}")

    # --- Long-Term Vision Forecasting (with context) ---
    def forecast_long_term_vision(self, current_state, context=None):
        ctx_str = f"Context: {context}" if context else ""
        self.logger.info(f"PlannerSubSquad: Forecasting long-term vision based on state: {current_state}... {ctx_str}")
        self._log_and_audit("Long Term Forecast", {"type": "long_term_forecast", "details": {"current_state": current_state, "context": ctx_str}})
        self.event_bus.publish("planner_sub_event", {"action": "forecast_initiated", "state": current_state, "context": ctx_str})
        prompt = (
            f"With current state: {current_state}\n"
            f"and cross-squad context: {ctx_str}\n"
            f"Forecast long-term vision, highlight inflection points, and anticipate cross-domain risks."
        )
        response, is_valid, confidence = self.llm_manager.get_llm_response("llama3", prompt, "long_term_forecast")
        self.logger.info(f"PlannerSubSquad: Long-term forecast (LLM): {str(response)[:80]}...")
        self._update_status("Long-term forecast", response)
        self._add_history("long_term_forecast", {"current_state": current_state, "context": ctx_str, "result": response, "valid": is_valid, "confidence": confidence})
        return response, is_valid, confidence

    # --- Scenario Simulation (new) ---
    def simulate_scenario(self, scenario, context=None):
        ctx_str = f"Context: {context}" if context else ""
        self.logger.info(f"PlannerSubSquad: Simulating scenario: {scenario}... {ctx_str}")
        self._log_and_audit("Scenario Simulation", {"type": "scenario_simulation", "details": {"scenario": scenario, "context": ctx_str}})
        self.event_bus.publish("planner_sub_event", {"action": "scenario_simulation", "scenario": scenario, "context": ctx_str})
        prompt = (
            f"Simulate scenario: {scenario}\n"
            f"with cross-squad context: {ctx_str}\n"
            f"Provide likely outcomes, risks, and recommended adjustments."
        )
        response, is_valid, confidence = self.llm_manager.get_llm_response("mixtral", prompt, "scenario_simulation")
        self.logger.info(f"PlannerSubSquad: Scenario simulation (LLM): {str(response)[:80]}...")
        self._update_status("Scenario simulation", response)
        self._add_history("scenario_simulation", {"scenario": scenario, "context": ctx_str, "result": response, "valid": is_valid, "confidence": confidence})
        return response, is_valid, confidence

    # --- Strategy Adjustment (with context) ---
    def adjust_strategy(self, current_strategy, new_constraints, context=None):
        ctx_str = f"Context: {context}" if context else ""
        self.logger.info(f"PlannerSubSquad: Adjusting strategy {current_strategy} due to new constraints: {new_constraints}... {ctx_str}")
        self._log_and_audit("Strategy Adjustment", {"type": "strategy_adjustment", "details": {"strategy": current_strategy, "constraints": new_constraints, "context": ctx_str}})
        self.event_bus.publish("planner_sub_event", {"action": "strategy_adjustment_initiated", "strategy": current_strategy, "context": ctx_str})
        prompt = (
            f"Adjust the strategy: {current_strategy} considering new constraints: {new_constraints}.\n"
            f"Cross-squad context: {ctx_str}\n"
            f"Suggest adaptive steps and risk mitigations."
        )
        response, is_valid, confidence = self.llm_manager.get_llm_response("mixtral", prompt, "strategy_adjustment")
        self.logger.info(f"PlannerSubSquad: Strategy adjustment (LLM): {str(response)[:80]}...")
        self._update_status("Strategy adjustment", response)
        self._add_history("strategy_adjustment", {"strategy": current_strategy, "constraints": new_constraints, "context": ctx_str, "result": response, "valid": is_valid, "confidence": confidence})
        return response, is_valid, confidence

    # --- Constraint Tracking ---
    def track_new_constraints(self, constraint_details, context=None):
        self.logger.info(f"PlannerSubSquad: Tracking new constraint: {constraint_details}...")
        self.status["tracked_constraints"].append(constraint_details)
        if hasattr(self.memory, "update_shared_data"):
            self.memory.update_shared_data("new_constraint", constraint_details)
        self._log_and_audit("Constraint Tracking", {"type": "constraint_tracking", "details": {"constraint": constraint_details, "context": context}})
        self.event_bus.publish("planner_sub_event", {"action": "constraint_tracked", "constraint": constraint_details, "context": context})
        self._add_history("constraint_tracking", {"constraint": constraint_details, "context": context})

    # --- Auto-Briefing ---
    def auto_brief_kai(self, topic, context=None):
        ctx_str = f"Context: {context}" if context else ""
        self.logger.info(f"PlannerSubSquad: Auto-briefing Kai on path shifts related to: {topic}... {ctx_str}")
        self._log_and_audit("Kai Auto Briefing", {"type": "kai_auto_briefing", "details": {"topic": topic, "context": ctx_str}})
        self.event_bus.publish("planner_sub_event", {"action": "kai_briefing_initiated", "topic": topic, "context": ctx_str})
        prompt = (
            f"Prepare a concise briefing for Kai on recent path shifts concerning {topic}.\n"
            f"Cross-squad context: {ctx_str}\n"
            f"Highlight major changes and their implications."
        )
        response, is_valid, confidence = self.llm_manager.get_llm_response("llama2", prompt, "kai_briefing")
        self.logger.info(f"PlannerSubSquad: Kai auto-briefing (LLM): {str(response)[:80]}...")
        self._update_status("Kai auto-brief", response)
        self._add_history("kai_auto_briefing", {"topic": topic, "context": ctx_str, "result": response, "valid": is_valid, "confidence": confidence})
        return response, is_valid, confidence

    # --- Status, History, Replay, Notification ---
    def get_status(self):
        return dict(self.status)

    def get_history(self, kind=None, limit=50):
        filtered = [e for e in reversed(self.history) if (kind is None or e.get('type') == kind)]
        return filtered[:limit]

    def replay_history(self, kind=None):
        self.logger.info("PlannerSubSquad: Replaying sub-squad history...")
        filtered = [e for e in self.history if (kind is None or e.get('type') == kind)]
        for event in filtered:
            print(f"  [{time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(event['ts']))}] {event}")

    def _notify_operator(self, subject, message):
        if self.notification_manager:
            self.notification_manager.notify(subject, message)
            self.status["alerts_sent"] += 1
        self.logger.warning(f"PlannerSubSquad: Notifying operator - {subject}: {message}")

    def _update_status(self, action, result):
        self.status.update({
            "last_action": action,
            "last_result": result,
            "tasks_run": self.status["tasks_run"] + 1
        })

    def _add_history(self, kind, data):
        entry = dict(type=kind, ts=time.time(), **data)
        self.history.append(entry)

    def _log_and_audit(self, message, audit_data):
        self.logger.info(message)
        if self.audit_layer:
            self.audit_layer.log(audit_data)

    # --- Unified Dashboard/API Command Entry ---
    def execute(self, command_details):
        """
        Unified entry for dashboard or API to trigger sub-squad tasks.
        Status/history are always updated for GUI polling or push.
        """
        task = command_details.get("task", "")
        details = command_details.get("details", "")

        context = self._cross_squad_context()

        if "forecast vision" in details.lower():
            current_state = details.split("forecast vision based on ")[-1].strip()
            response, is_valid, confidence = self.forecast_long_term_vision(current_state, context)
            scorecard = self.fusion_engine.fuse_signals({"llm_confidence": confidence, "llm_validity": is_valid, "task_complexity": 0.8})
            return response, is_valid, confidence, scorecard
        elif "simulate scenario" in details.lower():
            scenario = details.split("simulate scenario: ")[-1].strip()
            response, is_valid, confidence = self.simulate_scenario(scenario, context)
            scorecard = self.fusion_engine.fuse_signals({"llm_confidence": confidence, "llm_validity": is_valid, "task_complexity": 0.85})
            return response, is_valid, confidence, scorecard
        elif "adjust strategy" in details.lower():
            parts = details.split("adjust strategy ")[-1].strip().split(" due to ")
            if len(parts) == 2:
                current_strategy = parts[0]
                new_constraints = parts[1]
                response, is_valid, confidence = self.adjust_strategy(current_strategy, new_constraints, context)
                scorecard = self.fusion_engine.fuse_signals({"llm_confidence": confidence, "llm_validity": is_valid, "task_complexity": 0.75})
                return response, is_valid, confidence, scorecard
            else:
                return "PlannerSubSquad: Invalid adjust strategy command format.", False, 0.5, {"success_probability": 0.5, "cost_estimate": 0.01, "risk_assessment": 0.1, "overall_score": 0.4}
        elif "track constraints" in details.lower():
            constraint_details = details.split("track constraints: ")[-1].strip()
            self.track_new_constraints(constraint_details, context)
            return f"PlannerSubSquad: Tracking constraint: {constraint_details}.", True, 1.0, {"success_probability": 1.0, "cost_estimate": 0.01, "risk_assessment": 0.0, "overall_score": 1.0}
        elif "auto brief kai" in details.lower():
            topic = details.split("auto brief kai on ")[-1].strip()
            response, is_valid, confidence = self.auto_brief_kai(topic, context)
            scorecard = self.fusion_engine.fuse_signals({"llm_confidence": confidence, "llm_validity": is_valid, "task_complexity": 0.6})
            return response, is_valid, confidence, scorecard
        elif "start background" in details.lower():
            interval = command_details.get("interval", 120)
            self.start_background_tracking(interval=interval)
            return "PlannerSubSquad: Background tracking started.", True, 1.0, {}
        elif "stop background" in details.lower():
            self.stop_background_tracking()
            return "PlannerSubSquad: Background tracking stopped.", True, 1.0, {}
        elif "status" in details.lower():
            return self.get_status(), True, 1.0, {}
        elif "history" in details.lower():
            kind = command_details.get("kind")
            limit = command_details.get("limit", 50)
            return self.get_history(kind, limit), True, 1.0, {}
        elif "replay" in details.lower():
            kind = command_details.get("kind")
            self.replay_history(kind)
            return "History replayed.", True, 1.0, {}
        elif "notify" in details.lower():
            self._notify_operator(command_details.get("subject", "PlannerSub Alert"), command_details.get("message", ""))
            return "Operator notified.", True, 1.0, {}
        else:
            return "PlannerSubSquad: Understood. Performing general planner sub-squad tasks.", True, 0.8, {
                "success_probability": 0.8, "cost_estimate": 0.02, "risk_assessment": 0.1, "overall_score": 0.7
            }
