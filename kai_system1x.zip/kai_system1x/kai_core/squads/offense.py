import time
import threading
import logging

class OffenseSquad:
    """
    OffenseSquad: Advanced red-team and adversarial operations unit.
    - Penetration testing (single and continuous) with live status/history for dashboard.
    - AI deception analysis and adversarial model attacks.
    - Simulation/testing support for blue/red team drills.
    - Operator notifications for successful exploits, high-impact or risky findings.
    - Dashboard/REST API ready: exposes status, incident history, replay, and unified execute.
    """

    def __init__(
        self, event_bus, audit_layer, memory, llm_manager, fusion_engine,
        notification_manager=None, logger=None
    ):
        self.event_bus = event_bus
        self.audit_layer = audit_layer
        self.memory = memory
        self.llm_manager = llm_manager
        self.fusion_engine = fusion_engine
        self.notification_manager = notification_manager
        self.logger = logger or logging.getLogger("OffenseSquad")
        self.history = []
        self.status = {
            "last_action": None,
            "last_result": None,
            "tasks_run": 0,
            "alerts_sent": 0,
            "active_pentest_targets": [],
        }
        self.active_monitors = {}
        self._tracker_threads = {}
        self.logger.info("OffenseSquad: Initialized for advanced red-team operations.")

    # --- Penetration Testing (single or continuous) ---
    def perform_penetration_testing(self, target_system, continuous=False, interval=60, max_checks=None):
        """
        Penetration test. If continuous, runs background attack loop.
        Each event updates status/history for dashboard.
        """
        def pentest_loop():
            checks = 0
            while not self.active_monitors.get(target_system, {}).get("stop", False) and (max_checks is None or checks < max_checks):
                result = self._single_pentest(target_system)
                if result:
                    break
                checks += 1
                time.sleep(interval)
            self.active_monitors.pop(target_system, None)
            if target_system in self.status["active_pentest_targets"]:
                self.status["active_pentest_targets"].remove(target_system)

        if continuous:
            self.active_monitors[target_system] = {"stop": False}
            t = threading.Thread(target=pentest_loop, daemon=True)
            t.start()
            self._tracker_threads[target_system] = t
            self.status["active_pentest_targets"].append(target_system)
            msg = f"Started continuous pentest for {target_system}"
            self.status["last_action"] = msg
            return msg
        else:
            return self._single_pentest(target_system)

    def stop_pentest(self, target_system):
        """Stop a continuous pentest on a given target_system."""
        if target_system in self.active_monitors:
            self.active_monitors[target_system]["stop"] = True
            self.logger.info(f"Stopping continuous pentest for {target_system}...")
            t = self._tracker_threads.pop(target_system, None)
            if t:
                t.join(timeout=5)

    def _single_pentest(self, target_system):
        self.logger.info(f"OffenseSquad: Performing penetration testing on {target_system}...")
        self._log_and_audit("Penetration Test", {"type": "penetration_test", "details": {"target": target_system}})
        self.event_bus.publish("offense_event", {"action": "pentest_initiated", "target": target_system})
        prompt = f"Outline a penetration testing strategy for {target_system}."
        response, is_valid, confidence = self.llm_manager.get_llm_response("mixtral", prompt, "pentest_strategy")
        success = confidence > 0.8
        self.logger.info(f"OffenseSquad: Penetration test strategy (LLM): {str(response)[:80]}...")
        self.status.update({"last_action": f"Pentest on {target_system}", "last_result": response, "tasks_run": self.status["tasks_run"] + 1})
        entry = {
            "type": "pentest", "target": target_system, "result": response,
            "valid": is_valid, "confidence": confidence, "success": success, "ts": time.time()
        }
        self.history.append(entry)
        msg = "Penetration successful." if success else "Penetration failed."
        if success:
            self._notify_operator(f"Penetration succeeded on {target_system}", response)
        return response, is_valid, confidence, success, msg

    # --- AI Deception Analysis ---
    def analyze_ai_deception(self, ai_model_output):
        self.logger.info(f"OffenseSquad: Analyzing AI deception in output: {ai_model_output[:50]}...")
        self._log_and_audit("AI Deception Analysis", {"type": "ai_deception_analysis", "details": {"output": ai_model_output}})
        self.event_bus.publish("offense_event", {"action": "ai_deception_analysis_initiated"})
        prompt = f"Analyze the following AI output for signs of deception or manipulation: {ai_model_output}"
        response, is_valid, confidence = self.llm_manager.get_llm_response("hermes", prompt, "ai_deception_analysis")
        self.logger.info(f"OffenseSquad: AI deception analysis (LLM): {str(response)[:80]}...")
        self.status.update({"last_action": "AI deception analysis", "last_result": response, "tasks_run": self.status["tasks_run"] + 1})
        entry = {
            "type": "ai_deception", "output": ai_model_output, "result": response,
            "valid": is_valid, "confidence": confidence, "ts": time.time()
        }
        self.history.append(entry)
        if ("deception" in response.lower() or confidence < 0.6 or not is_valid):
            self._notify_operator("AI Deception Detected", response)
        return response, is_valid, confidence

    # --- Adversarial Model Attack ---
    def break_adversarial_models(self, model_details):
        self.logger.info(f"OffenseSquad: Attempting to break adversarial models: {model_details}...")
        self._log_and_audit("Adversarial Model Break", {"type": "adversarial_model_break", "details": {"model": model_details}})
        self.event_bus.publish("offense_event", {"action": "adversarial_model_break_initiated", "model": model_details})
        prompt = f"Suggest attack vectors to break the adversarial model: {model_details}"
        response, is_valid, confidence = self.llm_manager.get_llm_response("mixtral", prompt, "adversarial_attack_vectors")
        success = confidence > 0.8
        self.logger.info(f"OffenseSquad: Adversarial model attack vectors (LLM): {str(response)[:80]}...")
        self.status.update({"last_action": f"Adversarial break for {model_details}", "last_result": response, "tasks_run": self.status["tasks_run"] + 1})
        entry = {
            "type": "adv_break", "model": model_details, "result": response,
            "valid": is_valid, "confidence": confidence, "success": success, "ts": time.time()
        }
        self.history.append(entry)
        msg = "Model broken." if success else "Model resilient."
        if success:
            self._notify_operator(f"Adversarial model broken: {model_details}", response)
        return response, is_valid, confidence, success, msg

    # --- Dashboard/History/Status API ---
    def get_status(self):
        return dict(self.status)

    def get_history(self, kind=None, limit=50):
        filtered = [e for e in reversed(self.history) if (kind is None or e.get('type') == kind)]
        return filtered[:limit]

    # --- Operator Notification ---
    def _notify_operator(self, subject, message):
        if self.notification_manager:
            self.notification_manager.notify(subject, message)
            self.status["alerts_sent"] += 1
        self.logger.warning(f"OffenseSquad: Notifying operator - {subject}: {message}")

    # --- Replay for Audit/Testing ---
    def replay_history(self, kind=None):
        self.logger.info("OffenseSquad: Replaying offense history...")
        filtered = [e for e in self.history if (kind is None or e.get('type') == kind)]
        for event in filtered:
            print(f"  [{time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(event['ts']))}] {event}")

    # --- Unified Command Entry Point for Dashboard/GUI/API ---
    def execute(self, command_details):
        """
        Entry for dashboard GUI or API to trigger offense tasks.
        Results and status are always updated for dashboard polling or websocket push.
        """
        task = command_details.get("task", "")
        details = command_details.get("details", "")

        if "perform pentest" in details.lower():
            target_system = details.split("perform pentest on ")[-1].strip()
            response, is_valid, confidence, success, msg = self.perform_penetration_testing(target_system)
            scorecard = self.fusion_engine.fuse_signals({
                "llm_confidence": confidence, "llm_validity": is_valid, "task_complexity": 0.9, "success_probability": 1.0 if success else 0.5
            })
            return msg, is_valid, confidence, scorecard
        elif "analyze ai deception" in details.lower():
            ai_model_output = details.split("analyze ai deception in ")[-1].strip()
            response, is_valid, confidence = self.analyze_ai_deception(ai_model_output)
            scorecard = self.fusion_engine.fuse_signals({
                "llm_confidence": confidence, "llm_validity": is_valid, "task_complexity": 0.8
            })
            return response, is_valid, confidence, scorecard
        elif "break adversarial models" in details.lower():
            model_details = details.split("break adversarial models: ")[-1].strip()
            response, is_valid, confidence, success, msg = self.break_adversarial_models(model_details)
            scorecard = self.fusion_engine.fuse_signals({
                "llm_confidence": confidence, "llm_validity": is_valid, "task_complexity": 0.95, "success_probability": 1.0 if success else 0.5
            })
            return msg, is_valid, confidence, scorecard
        elif "status" in details.lower():
            return self.get_status(), True, 1.0, {}
        elif "history" in details.lower():
            kind = command_details.get("kind")
            limit = command_details.get("limit", 50)
            return self.get_history(kind, limit), True, 1.0, {}
        elif "replay" in details.lower():
            kind = command_details.get("kind")
            self.replay_history(kind)
            return "History replayed.", True, 1.0, {}
        elif "notify" in details.lower():
            self._notify_operator(command_details.get("subject", "Offense Alert"), command_details.get("message", ""))
            return "Operator notified.", True, 1.0, {}
        else:
            return "OffenseSquad: Understood. Performing general offense tasks.", True, 0.8, {
                "success_probability": 0.8, "cost_estimate": 0.02, "risk_assessment": 0.1, "overall_score": 0.7
            }

    def _log_and_audit(self, message, audit_data):
        self.logger.info(message)
        if self.audit_layer:
            self.audit_layer.log(audit_data)
