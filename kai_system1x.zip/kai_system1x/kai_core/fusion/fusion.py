import random
import logging
from typing import Dict, Any, Tuple

class Fusion:
    def __init__(self, event_bus, audit_layer, weights=None):
        self.event_bus = event_bus
        self.audit_layer = audit_layer
        self.weights = weights or {"success": 0.5, "risk": 0.3, "cost": 0.2}
        self.logger = logging.getLogger("Fusion")
        print("Fusion: Initialized as signal fusion engine.")

    def fuse_signals(self, signals: Dict[str, Any]) -> Dict[str, float]:
        """
        Fuses input signals and returns a scorecard.
        """
        try:
            llm_confidence = float(signals.get("llm_confidence", 0.0))
            llm_validity = float(signals.get("llm_validity", 1.0))
            squad_performance = float(signals.get("squad_performance", 1.0))
            task_complexity = float(signals.get("task_complexity", 0.0))
            cost_estimate = float(signals.get("cost_estimate", 0.0))
            risk_assessment = float(signals.get("risk_assessment", 0.0))

            success_probability = llm_confidence * llm_validity * squad_performance
            cost_estimate += (task_complexity * 0.05)
            risk_assessment += (1 - llm_validity) * 0.5

            # Normalize
            success_probability = min(1.0, max(0.0, success_probability))
            cost_estimate = max(0.0, cost_estimate)
            risk_assessment = min(1.0, max(0.0, risk_assessment))

            overall_score = (
                success_probability * self.weights["success"] +
                (1 - risk_assessment) * self.weights["risk"] +
                (1 - cost_estimate) * self.weights["cost"]
            )
            overall_score = min(1.0, max(0.0, overall_score))

            scorecard = {
                "success_probability": round(success_probability, 3),
                "cost_estimate": round(cost_estimate, 3),
                "risk_assessment": round(risk_assessment, 3),
                "overall_score": round(overall_score, 3),
                "fusion_strategy": "weighted_sum_v1"
            }

            self.audit_layer.log({
                "type": "signal_fusion",
                "details": {"input_signals": signals, "scorecard": scorecard},
                "timestamp": self._now_iso()
            })
            self.event_bus.publish("fusion_event", {
                "action": "signals_fused",
                "scorecard": scorecard,
                "timestamp": self._now_iso()
            })
            self.logger.info(f"Fusion: Signals fused. Scorecard: {scorecard}")
            return scorecard

        except Exception as e:
            self.logger.error(f"Fusion error: {e}", exc_info=True)
            self.audit_layer.log({
                "type": "fusion_error",
                "error": str(e),
                "input_signals": signals,
                "timestamp": self._now_iso()
            })
            return {
                "success_probability": 0.0,
                "cost_estimate": 1.0,
                "risk_assessment": 1.0,
                "overall_score": 0.0,
                "fusion_strategy": "error"
            }

    def execute(self, command_details: Dict[str, Any]) -> Tuple[str, bool, float, Dict[str, float]]:
        """
        Executes a fusion-related command.
        """
        task = command_details.get("task")
        details = command_details.get("details", "")

        if isinstance(details, str) and "fuse signals" in details.lower():
            dummy_signals = {
                "llm_confidence": random.uniform(0.5, 1.0),
                "llm_validity": random.choice([True, False]),
                "task_complexity": random.uniform(0.1, 0.9),
                "squad_performance": random.uniform(0.6, 1.0),
                "cost_estimate": random.uniform(0.01, 0.1),
                "risk_assessment": random.uniform(0.0, 0.5)
            }
            scorecard = self.fuse_signals(dummy_signals)
            return f"Fusion: Fused signals. Scorecard: {scorecard}", True, 1.0, scorecard
        else:
            default_scorecard = {
                "success_probability": 0.8, "cost_estimate": 0.02,
                "risk_assessment": 0.1, "overall_score": 0.7,
                "fusion_strategy": "default"
            }
            return "Fusion: Understood. Performing general fusion tasks (simulated).", True, 0.8, default_scorecard

    def _now_iso(self):
        import datetime
        return datetime.datetime.now().isoformat()
