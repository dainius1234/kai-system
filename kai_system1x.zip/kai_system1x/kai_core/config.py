"""
config.py - Configuration management for the Kai System

This module provides configuration management capabilities for the Kai System,
supporting environment variables, configuration files, and command-line arguments.
"""

import os
import json
import argparse
import logging
from typing import Dict, Any

# Configure logging
os.makedirs("kai_logs", exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("kai_logs/config.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("config")

# Default configuration values
DEFAULT_CONFIG = {
    "voice": {
        "enabled": True,
        "tts_engine": "system",
        "stt_engine": "system"
    },
    "dashboard": {
        "enabled": True,
        "port": 8080,
        "host": "0.0.0.0"
    },
    "monitoring": {
        "enabled": True,
        "log_level": "INFO"
    },
    "paths": {
        "logs_dir": "./kai_logs",
        "reports_dir": "./kai_reports",
        "plans_dir": "./kai_plans",
        "data_dir": "./kai_data"
    },
    "system": {
        "debug_mode": False,
        "auto_optimize": True,
        "ethics_enabled": True
    }
}

# Environment variable prefix
ENV_PREFIX = "KAI_"

class ConfigManager:
    """
    Configuration manager for the Kai System
    Handles loading and saving configuration from files, environment variables, and command-line arguments
    """
    def __init__(self, config_file: str = "kai_core/config.json"):
        """
        Initialize the configuration manager

        Args:
            config_file: Path to the configuration file
        """
        self.config_file = config_file
        self.config = json.loads(json.dumps(DEFAULT_CONFIG))  # deep copy

        # Create all required directories
        self._ensure_directories()

        # Load configuration
        self._load_config()

        logger.info("Configuration manager initialized")

    def _ensure_directories(self):
        """Ensure required directories exist"""
        for dir_path in DEFAULT_CONFIG.get("paths", {}).values():
            try:
                os.makedirs(dir_path, exist_ok=True)
            except Exception as e:
                logger.error(f"Could not create directory {dir_path}: {e}")

    def _load_config(self):
        """Load configuration from file, environment variables, and command-line arguments"""
        self._load_from_file()
        self._load_from_env()
        self._load_from_args()
        logger.info("Configuration loaded")

    def _load_from_file(self):
        """Load configuration from file"""
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r') as f:
                    file_config = json.load(f)
                    self._deep_merge_config(file_config)
                    logger.info(f"Configuration loaded from {self.config_file}")
            else:
                logger.info(f"Configuration file {self.config_file} not found, using defaults")
                self.save_config()
        except Exception as e:
            logger.error(f"Error loading configuration from file: {e}", exc_info=True)

    def _load_from_env(self):
        """Load configuration from environment variables"""
        try:
            # Voice configuration
            val = os.environ.get(f"{ENV_PREFIX}VOICE_ENABLED")
            if val is not None:
                self.config["voice"]["enabled"] = val.lower() in ("true", "1", "yes")

            # Dashboard configuration
            val = os.environ.get(f"{ENV_PREFIX}DASHBOARD_ENABLED")
            if val is not None:
                self.config["dashboard"]["enabled"] = val.lower() in ("true", "1", "yes")
            val = os.environ.get(f"{ENV_PREFIX}DASHBOARD_PORT")
            if val is not None:
                try:
                    port = int(val)
                    if 1 <= port <= 65535:
                        self.config["dashboard"]["port"] = port
                    else:
                        logger.warning("DASHBOARD_PORT out of valid range")
                except Exception:
                    logger.warning("Invalid DASHBOARD_PORT env value")

            # Monitoring configuration
            val = os.environ.get(f"{ENV_PREFIX}MONITORING_ENABLED")
            if val is not None:
                self.config["monitoring"]["enabled"] = val.lower() in ("true", "1", "yes")
            val = os.environ.get(f"{ENV_PREFIX}LOG_LEVEL")
            if val is not None:
                self.config["monitoring"]["log_level"] = val

            # System configuration
            val = os.environ.get(f"{ENV_PREFIX}DEBUG_MODE")
            if val is not None:
                self.config["system"]["debug_mode"] = val.lower() in ("true", "1", "yes")
            val = os.environ.get(f"{ENV_PREFIX}ETHICS_ENABLED")
            if val is not None:
                self.config["system"]["ethics_enabled"] = val.lower() in ("true", "1", "yes")

            logger.info("Configuration loaded from environment variables")
        except Exception as e:
            logger.error(f"Error loading configuration from environment variables: {e}", exc_info=True)

    def _load_from_args(self):
        """Load configuration from command-line arguments"""
        try:
            parser = argparse.ArgumentParser(description='Kai System Configuration Arguments')
            # Voice arguments
            parser.add_argument('--enable-voice', dest='voice_enabled', action='store_true', help='Enable voice interface')
            parser.add_argument('--disable-voice', dest='voice_enabled', action='store_false', help='Disable voice interface')
            parser.set_defaults(voice_enabled=None)

            # Dashboard arguments
            parser.add_argument('--enable-dashboard', dest='dashboard_enabled', action='store_true', help='Enable dashboard')
            parser.add_argument('--disable-dashboard', dest='dashboard_enabled', action='store_false', help='Disable dashboard')
            parser.set_defaults(dashboard_enabled=None)
            parser.add_argument('--dashboard-port', type=int, help='Dashboard server port')

            # Monitoring arguments
            parser.add_argument('--enable-monitoring', dest='monitoring_enabled', action='store_true', help='Enable performance monitoring')
            parser.add_argument('--disable-monitoring', dest='monitoring_enabled', action='store_false', help='Disable performance monitoring')
            parser.set_defaults(monitoring_enabled=None)
            parser.add_argument('--log-level', type=str, choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'], help='Logging level')

            # System arguments
            parser.add_argument('--debug', dest='debug_mode', action='store_true', help='Enable debug mode')
            parser.add_argument('--no-debug', dest='debug_mode', action='store_false', help='Disable debug mode')
            parser.set_defaults(debug_mode=None)
            parser.add_argument('--ethics', dest='ethics_enabled', action='store_true', help='Enable ethics checks')
            parser.add_argument('--no-ethics', dest='ethics_enabled', action='store_false', help='Disable ethics checks')
            parser.set_defaults(ethics_enabled=None)

            # Config file argument
            parser.add_argument('--config', type=str, help='Path to configuration file')

            args, _ = parser.parse_known_args()

            # Config file
            if getattr(args, 'config', None):
                self.config_file = args.config
                self._load_from_file()

            # Voice configuration
            if getattr(args, 'voice_enabled', None) is not None:
                self.config["voice"]["enabled"] = args.voice_enabled

            # Dashboard configuration
            if getattr(args, 'dashboard_enabled', None) is not None:
                self.config["dashboard"]["enabled"] = args.dashboard_enabled
            if getattr(args, 'dashboard_port', None) is not None:
                port = args.dashboard_port
                if 1 <= port <= 65535:
                    self.config["dashboard"]["port"] = port
                else:
                    logger.warning("dashboard_port argument out of valid range")

            # Monitoring configuration
            if getattr(args, 'monitoring_enabled', None) is not None:
                self.config["monitoring"]["enabled"] = args.monitoring_enabled
            if getattr(args, 'log_level', None) is not None:
                self.config["monitoring"]["log_level"] = args.log_level

            # System configuration
            if getattr(args, 'debug_mode', None) is not None:
                self.config["system"]["debug_mode"] = args.debug_mode
            if getattr(args, 'ethics_enabled', None) is not None:
                self.config["system"]["ethics_enabled"] = args.ethics_enabled

            logger.info("Configuration loaded from command-line arguments")
        except Exception as e:
            logger.error(f"Error loading configuration from command-line arguments: {e}", exc_info=True)

    def _deep_merge_config(self, new_config: Dict[str, Any], base: Dict[str, Any] = None):
        """
        Recursively merge new_config into base (self.config).
        """
        if base is None:
            base = self.config
        for k, v in new_config.items():
            if (k in base and isinstance(base[k], dict) and isinstance(v, dict)):
                self._deep_merge_config(v, base=base[k])
            else:
                base[k] = v

    def save_config(self):
        """
        Save configuration to file
        """
        try:
            os.makedirs(os.path.dirname(self.config_file), exist_ok=True)
            with open(self.config_file, 'w') as f:
                json.dump(self.config, f, indent=2)
            logger.info(f"Configuration saved to {self.config_file}")
            return True
        except Exception as e:
            logger.error(f"Error saving configuration to file: {e}", exc_info=True)
            return False

    def get_config(self) -> Dict[str, Any]:
        """Get the complete configuration"""
        return self.config

    def get_section(self, section: str) -> Dict[str, Any]:
        """Get a specific configuration section"""
        return self.config.get(section, {})

    def get_value(self, section: str, key: str, default: Any = None) -> Any:
        """Get a specific configuration value"""
        return self.config.get(section, {}).get(key, default)

    def set_value(self, section: str, key: str, value: Any):
        """Set a specific configuration value"""
        if section not in self.config:
            self.config[section] = {}
        self.config[section][key] = value

    def create_env_file(self, file_path: str = ".env") -> bool:
        """
        Create a .env file with the current configuration
        """
        try:
            with open(file_path, 'w') as f:
                # Voice configuration
                f.write(f"{ENV_PREFIX}VOICE_ENABLED={str(self.config['voice']['enabled']).lower()}\n")
                # Dashboard configuration
                f.write(f"{ENV_PREFIX}DASHBOARD_ENABLED={str(self.config['dashboard']['enabled']).lower()}\n")
                f.write(f"{ENV_PREFIX}DASHBOARD_PORT={self.config['dashboard']['port']}\n")
                # Monitoring configuration
                f.write(f"{ENV_PREFIX}MONITORING_ENABLED={str(self.config['monitoring']['enabled']).lower()}\n")
                f.write(f"{ENV_PREFIX}LOG_LEVEL={self.config['monitoring']['log_level']}\n")
                # System configuration
                f.write(f"{ENV_PREFIX}DEBUG_MODE={str(self.config['system']['debug_mode']).lower()}\n")
                f.write(f"{ENV_PREFIX}ETHICS_ENABLED={str(self.config['system']['ethics_enabled']).lower()}\n")
            logger.info(f"Environment variables saved to {file_path}")
            return True
        except Exception as e:
            logger.error(f"Error creating .env file: {e}", exc_info=True)
            return False

if __name__ == "__main__":
    cfg = ConfigManager()
    print(json.dumps(cfg.get_config(), indent=2))
