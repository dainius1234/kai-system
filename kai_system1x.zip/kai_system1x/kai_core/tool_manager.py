"""
ToolManager - Manages discovery, registration, launching, and status of tools in Kai environments.

Handles modular local tools/scripts and open-source apps for any workspace or R&D task.
Scans /env/ for available tools, allows registration, launching, and querying by Kai core and squads.

Author: dainius1234
Copyright: (c) 2025
"""

import os
import subprocess
from datetime import datetime
from typing import Dict, List, Optional

# Define standard Kai environments (from your plan)
KAI_ENVIRONMENTS = [
    "coding",
    "office",
    "engineering",
    "survey",
    "training",
    "accounting",
    "learning",
    "trading",
    "legal",
    "admin",
    "intel",
    "defense",
    "offense",
    "eco",
    "prime",
    "debug",
    "planner_sub",
    "construction_planning",
    "engineering_squad"
]

class ToolManager:
    def __init__(self, env_root: str, event_bus, audit_layer, memory, env_libraries=None):
        """
        env_root: Path to the /env directory (e.g., './env')
        event_bus: EventBus instance for publishing events
        audit_layer: Audit instance for logging
        memory: Memory instance for persistent state (not required for operation)
        env_libraries: (optional) EnvironmentLibraries instance for richer environment metadata integration
        """
        self.env_root = env_root
        self.event_bus = event_bus
        self.audit_layer = audit_layer
        self.memory = memory
        self.env_libraries = env_libraries
        self.tools: Dict[str, List[Dict]] = {}
        self.environments: List[str] = KAI_ENVIRONMENTS.copy()
        self._ensure_env_folders()
        self._discover_tools()

    def _ensure_env_folders(self):
        """Ensure that all standard environments exist as folders under env_root."""
        if not os.path.exists(self.env_root):
            os.makedirs(self.env_root)
        for env in self.environments:
            env_path = os.path.join(self.env_root, env)
            if not os.path.exists(env_path):
                os.makedirs(env_path)

    def _discover_tools(self):
        """Scan all env folders and index available tools/scripts."""
        self.tools = {}
        for env in self.environments:
            env_path = os.path.join(self.env_root, env)
            self.tools[env] = []
            if os.path.exists(env_path):
                for item in sorted(os.listdir(env_path)):
                    item_path = os.path.join(env_path, item)
                    if os.path.isdir(item_path) or item.endswith(('.py', '.sh', '.exe', '.AppImage')):
                        tool_entry = {
                            "name": item,
                            "path": item_path,
                            "type": "dir" if os.path.isdir(item_path) else "file",
                            "launchable": self._is_launchable(item_path),
                            "metadata": self._load_metadata(item_path)
                        }
                        self.tools[env].append(tool_entry)

    def _is_launchable(self, path: str) -> bool:
        """Determine if a file or folder can be launched."""
        if os.path.isdir(path):
            for fname in ("start.sh", "run.sh", "main.py", "app.exe", "AppRun"):
                if os.path.exists(os.path.join(path, fname)):
                    return True
            return False
        else:
            return os.access(path, os.X_OK) or path.endswith(('.py', '.sh', '.exe', '.AppImage'))

    def list_environments(self) -> List[str]:
        """Return available environment names."""
        return self.environments

    def list_tools(self, env: str) -> List[Dict]:
        """List all tools for a given environment."""
        return self.tools.get(env, [])

    def launch_tool(self, env: str, tool_name: str, args: Optional[List[str]] = None) -> Dict:
        """
        Launch a tool/script in a given environment.
        Returns a dict with success, message, and (optionally) process PID.
        """
        tool = self._find_tool(env, tool_name)
        if not tool or not tool.get("launchable"):
            return {"success": False, "message": f"Tool '{tool_name}' in '{env}' is not launchable or not found."}

        path = tool["path"]
        try:
            if os.path.isdir(path):
                main_launcher = None
                for fname in ("start.sh", "run.sh", "main.py", "app.exe", "AppRun"):
                    candidate = os.path.join(path, fname)
                    if os.path.exists(candidate):
                        main_launcher = candidate
                        break
                if not main_launcher:
                    return {"success": False, "message": f"No launchable file in tool directory '{tool_name}'."}
                if main_launcher.endswith(".py"):
                    cmd = ["python", main_launcher]
                elif main_launcher.endswith(".sh"):
                    cmd = ["bash", main_launcher]
                else:
                    cmd = [main_launcher]
                if args:
                    cmd.extend(args)
            else:
                if path.endswith(".py"):
                    cmd = ["python", path]
                elif path.endswith(".sh"):
                    cmd = ["bash", path]
                else:
                    cmd = [path]
                if args:
                    cmd.extend(args)

            proc = subprocess.Popen(cmd, cwd=os.path.dirname(path))
            self._log_action(f"Launched tool: {tool_name} in env: {env} (PID: {proc.pid})")
            return {"success": True, "message": f"Launched '{tool_name}' in '{env}'", "pid": proc.pid}
        except Exception as e:
            self._log_action(f"Failed to launch tool: {tool_name} in env: {env} - {e}", error=True)
            return {"success": False, "message": str(e)}

    def _find_tool(self, env: str, tool_name: str) -> Optional[Dict]:
        """Find a tool dict by name within a given environment."""
        for tool in self.tools.get(env, []):
            if tool["name"] == tool_name:
                return tool
        return None

    def register_tool(self, env: str, name: str, path: str):
        """Register a new tool in the specified environment (does not create files, just indexes)."""
        if env not in self.tools:
            self.tools[env] = []
        tool_entry = {
            "name": name,
            "path": path,
            "type": "dir" if os.path.isdir(path) else "file",
            "launchable": self._is_launchable(path),
            "metadata": self._load_metadata(path)
        }
        self.tools[env].append(tool_entry)
        self._log_action(f"Registered tool: {name} in env: {env}")

    def refresh(self):
        """Re-scan all environments for tools."""
        self._discover_tools()
        self._log_action("Refreshed tools index")

    def _log_action(self, message: str, error: bool = False):
        """Log actions to audit layer and event bus."""
        log_entry = {
            "event": "tool_manager_action",
            "message": message,
            "timestamp": datetime.now().isoformat(),
            "level": "error" if error else "info"
        }
        if self.audit_layer:
            self.audit_layer.log(log_entry)
        if self.event_bus:
            self.event_bus.publish("tool_manager_log", log_entry)

    def get_tool_info(self, env: str, tool_name: str) -> Optional[Dict]:
        """Get detailed info about a tool in an environment, including metadata."""
        return self._find_tool(env, tool_name)

    def _load_metadata(self, path: str) -> Dict:
        """
        Attempt to load tool metadata from a 'tool.yaml' or 'tool.json' file in the tool's directory.
        Returns dict or empty dict.
        """
        import json
        try:
            import yaml
        except ImportError:
            yaml = None  # Only used if available

        meta = {}
        meta_files = []
        if os.path.isdir(path):
            meta_files = [os.path.join(path, "tool.yaml"), os.path.join(path, "tool.json")]
        elif os.path.isfile(path):
            meta_files = [
                path + ".yaml",
                path + ".json"
            ]
        for mf in meta_files:
            if os.path.exists(mf):
                try:
                    if mf.endswith(".yaml") and yaml is not None:
                        with open(mf, "r") as f:
                            meta = yaml.safe_load(f)
                    elif mf.endswith(".json"):
                        with open(mf, "r") as f:
                            meta = json.load(f)
                    break
                except Exception:
                    pass
        # Optionally supplement with env_libraries if available
        if self.env_libraries and hasattr(self.env_libraries, "get_metadata"):
            env_name = os.path.basename(os.path.dirname(path))
            lib_meta = self.env_libraries.get_metadata(env_name)
            if lib_meta:  # Merge into meta, but don't overwrite tool-specific fields
                for k, v in lib_meta.items():
                    if k not in meta:
                        meta[k] = v
        return meta

    # --- Optional: CLI interface for direct management ---
    def cli(self):
        """Simple command-line interface for managing tools (for local admin use)."""
        import sys
        print("Kai ToolManager CLI\n-------------------")
        while True:
            cmd = input("toolmgr> ").strip()
            if cmd in ("exit", "quit"):
                print("Bye.")
                sys.exit(0)
            elif cmd == "list envs":
                for e in self.list_environments():
                    print(f"- {e}")
            elif cmd.startswith("list tools "):
                env = cmd[len("list tools "):]
                for t in self.list_tools(env):
                    print(f"- {t['name']}")
            elif cmd.startswith("launch "):
                parts = cmd.split()
                if len(parts) >= 3:
                    env, tool = parts[1], parts[2]
                    result = self.launch_tool(env, tool)
                    print(result)
                else:
                    print("Usage: launch ENV TOOL")
            elif cmd == "refresh":
                self.refresh()
                print("Refreshed tools.")
            elif cmd == "help":
                print("Commands: list envs | list tools ENV | launch ENV TOOL | refresh | quit")
            else:
                print("Unknown command. Type 'help'.")
