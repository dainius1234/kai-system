# kai_core/monitoring/performance_monitor.py

import time
import threading
import json
from datetime import datetime, timedelta
from collections import defaultdict, deque
from dataclasses import dataclass, asdict
from typing import Dict, List, Optional, Any
import statistics
import os

@dataclass
class PerformanceMetric:
    """Data class for performance metrics"""
    timestamp: datetime
    component: str
    metric_type: str
    value: float
    metadata: Dict[str, Any]
    
    def to_dict(self):
        """Convert to dictionary for JSON serialization"""
        return {
            'timestamp': self.timestamp.isoformat(),
            'component': self.component,
            'metric_type': self.metric_type,
            'value': self.value,
            'metadata': self.metadata
        }

class PerformanceAnalyzer:
    """Analyzes performance trends and provides insights"""
    
    def __init__(self):
        self.trend_window = 50  # Number of data points for trend analysis
        
    def analyze_trends(self, metrics: List[PerformanceMetric]) -> Dict[str, Any]:
        """Analyze performance trends from metrics"""
        if len(metrics) < 2:
            return {"trend": "insufficient_data", "confidence": 0.0}
        
        # Sort by timestamp
        sorted_metrics = sorted(metrics, key=lambda m: m.timestamp)
        values = [m.value for m in sorted_metrics[-self.trend_window:]]
        
        if len(values) < 2:
            return {"trend": "insufficient_data", "confidence": 0.0}
        
        # Calculate trend using linear regression slope
        n = len(values)
        x_values = list(range(n))
        
        # Calculate slope
        x_mean = statistics.mean(x_values)
        y_mean = statistics.mean(values)
        
        numerator = sum((x - x_mean) * (y - y_mean) for x, y in zip(x_values, values))
        denominator = sum((x - x_mean) ** 2 for x in x_values)
        
        if denominator == 0:
            slope = 0
        else:
            slope = numerator / denominator
        
        # Determine trend direction and confidence
        if abs(slope) < 0.001:
            trend = "stable"
            confidence = 0.8
        elif slope > 0:
            trend = "improving"
            confidence = min(abs(slope) * 100, 1.0)
        else:
            trend = "declining"
            confidence = min(abs(slope) * 100, 1.0)
        
        # Calculate additional statistics
        recent_avg = statistics.mean(values[-10:]) if len(values) >= 10 else statistics.mean(values)
        overall_avg = statistics.mean(values)
        std_dev = statistics.stdev(values) if len(values) > 1 else 0
        
        return {
            "trend": trend,
            "confidence": confidence,
            "slope": slope,
            "recent_average": recent_avg,
            "overall_average": overall_avg,
            "standard_deviation": std_dev,
            "data_points": len(values),
            "min_value": min(values),
            "max_value": max(values)
        }
    
    def detect_anomalies(self, metrics: List[PerformanceMetric], threshold_std: float = 2.0) -> List[PerformanceMetric]:
        """Detect anomalous performance metrics"""
        if len(metrics) < 10:
            return []  # Need sufficient data for anomaly detection
        
        values = [m.value for m in metrics]
        mean_val = statistics.mean(values)
        std_val = statistics.stdev(values)
        
        anomalies = []
        for metric in metrics:
            z_score = abs(metric.value - mean_val) / std_val if std_val > 0 else 0
            if z_score > threshold_std:
                anomalies.append(metric)
        
        return anomalies

class FeedbackLoop:
    """Implements feedback loop for system optimization"""
    
    def __init__(self, llm_manager, router, audit_layer, event_bus):
        self.llm_manager = llm_manager
        self.router = router
        self.audit_layer = audit_layer
        self.event_bus = event_bus
        
        # Feedback thresholds
        self.performance_thresholds = {
            'response_time': {'warning': 5.0, 'critical': 10.0},
            'confidence': {'warning': 0.6, 'critical': 0.4},
            'success_rate': {'warning': 0.7, 'critical': 0.5},
            'cluster_health': {'warning': 0.6, 'critical': 0.4}
        }
        
        # Optimization actions
        self.optimization_actions = {
            'cluster_rebalance': self._trigger_cluster_rebalance,
            'route_optimization': self._trigger_route_optimization,
            'model_reload': self._trigger_model_reload,
            'performance_alert': self._trigger_performance_alert
        }
        
    def process_feedback(self, performance_data: Dict[str, Any]) -> List[str]:
        """Process performance feedback and trigger optimization actions"""
        actions_taken = []
        
        # Analyze cluster health
        cluster_health = performance_data.get('cluster_health', {})
        for cluster_id, health_data in cluster_health.items():
            health_ratio = health_data.get('health_ratio', 1.0)
            
            if health_ratio < self.performance_thresholds['cluster_health']['critical']:
                actions_taken.append(f"cluster_rebalance_{cluster_id}")
                self.optimization_actions['cluster_rebalance'](cluster_id)
            elif health_ratio < self.performance_thresholds['cluster_health']['warning']:
                actions_taken.append(f"performance_alert_{cluster_id}")
                self.optimization_actions['performance_alert'](f"Cluster {cluster_id} health warning")
        
        # Analyze response times
        avg_response_time = performance_data.get('average_response_time', 0)
        if avg_response_time > self.performance_thresholds['response_time']['critical']:
            actions_taken.append("route_optimization")
            self.optimization_actions['route_optimization']()
        
        # Analyze confidence levels
        avg_confidence = performance_data.get('average_confidence', 1.0)
        if avg_confidence < self.performance_thresholds['confidence']['critical']:
            actions_taken.append("model_reload")
            self.optimization_actions['model_reload']()
        
        return actions_taken
    
    def _trigger_cluster_rebalance(self, cluster_id: str):
        """Trigger cluster rebalancing"""
        print(f"FeedbackLoop: Triggering cluster rebalance for {cluster_id}")
        self.llm_manager.optimize_clusters()
        self.audit_layer.log({
            "type": "feedback_action",
            "action": "cluster_rebalance",
            "cluster_id": cluster_id,
            "timestamp": datetime.now().isoformat()
        })
    
    def _trigger_route_optimization(self):
        """Trigger route optimization"""
        print("FeedbackLoop: Triggering route optimization")
        self.router.optimize_routing()
        self.audit_layer.log({
            "type": "feedback_action",
            "action": "route_optimization",
            "timestamp": datetime.now().isoformat()
        })
    
    def _trigger_model_reload(self):
        """Trigger model reload for underperforming models"""
        print("FeedbackLoop: Triggering model reload")
        # This would implement logic to reload underperforming models
        self.audit_layer.log({
            "type": "feedback_action",
            "action": "model_reload",
            "timestamp": datetime.now().isoformat()
        })
    
    def _trigger_performance_alert(self, message: str):
        """Trigger performance alert"""
        print(f"FeedbackLoop: Performance alert - {message}")
        self.event_bus.publish("performance_alert", {
            "message": message,
            "timestamp": datetime.now().isoformat()
        })

class PerformanceMonitor:
    """Main performance monitoring system"""
    
    def __init__(self, llm_manager, router, audit_layer, event_bus, 
                 monitoring_interval=30, data_retention_hours=24):
        self.llm_manager = llm_manager
        self.router = router
        self.audit_layer = audit_layer
        self.event_bus = event_bus
        
        # Configuration
        self.monitoring_interval = monitoring_interval
        self.data_retention_hours = data_retention_hours
        
        # Data storage
        self.metrics_storage = defaultdict(lambda: deque(maxlen=1000))
        self.performance_history = deque(maxlen=10000)
        
        # Components
        self.analyzer = PerformanceAnalyzer()
        self.feedback_loop = FeedbackLoop(llm_manager, router, audit_layer, event_bus)
        
        # Threading
        self.monitoring_thread = None
        self.running = False
        self.lock = threading.Lock()
        
        # Performance tracking
        self.last_optimization = datetime.now()
        self.optimization_interval = timedelta(minutes=15)
        
        print("PerformanceMonitor: Initialized with advanced monitoring and feedback capabilities")
    
    def start_monitoring(self):
        """Start the performance monitoring thread"""
        if self.running:
            print("PerformanceMonitor: Already running")
            return
        
        self.running = True
        self.monitoring_thread = threading.Thread(target=self._monitoring_loop, daemon=True)
        self.monitoring_thread.start()
        
        print("PerformanceMonitor: Started monitoring thread")
        self.audit_layer.log({
            "type": "monitoring_started",
            "timestamp": datetime.now().isoformat()
        })
    
    def stop_monitoring(self):
        """Stop the performance monitoring thread"""
        self.running = False
        if self.monitoring_thread:
            self.monitoring_thread.join(timeout=5)
        
        print("PerformanceMonitor: Stopped monitoring")
        self.audit_layer.log({
            "type": "monitoring_stopped",
            "timestamp": datetime.now().isoformat()
        })
    
    def _monitoring_loop(self):
        """Main monitoring loop"""
        while self.running:
            try:
                # Collect metrics
                self._collect_system_metrics()
                
                # Analyze performance
                self._analyze_performance()
                
                # Check if optimization is needed
                if datetime.now() - self.last_optimization > self.optimization_interval:
                    self._run_optimization_cycle()
                    self.last_optimization = datetime.now()
                
                # Clean old data
                self._cleanup_old_data()
                
                # Wait for next cycle
                time.sleep(self.monitoring_interval)
                
            except Exception as e:
                print(f"PerformanceMonitor: Error in monitoring loop: {e}")
                self.audit_layer.log({
                    "type": "monitoring_error",
                    "error": str(e),
                    "timestamp": datetime.now().isoformat()
                })
                time.sleep(self.monitoring_interval)
    
    def _collect_system_metrics(self):
        """Collect system performance metrics"""
        with self.lock:
            timestamp = datetime.now()
            
            # Collect LLM cluster metrics
            cluster_status = self.llm_manager.get_cluster_status()
            for cluster_id, status in cluster_status.items():
                metric = PerformanceMetric(
                    timestamp=timestamp,
                    component=f"cluster_{cluster_id}",
                    metric_type="health_ratio",
                    value=status['health_ratio'],
                    metadata=status
                )
                self.metrics_storage[f"cluster_{cluster_id}_health"].append(metric)
            
            # Collect routing metrics
            routing_stats = self.router.get_routing_statistics()
            
            # Overall system performance
            overall_performance = self._calculate_system_performance()
            metric = PerformanceMetric(
                timestamp=timestamp,
                component="system",
                metric_type="overall_performance",
                value=overall_performance,
                metadata={"routing_stats": routing_stats}
            )
            self.metrics_storage["system_performance"].append(metric)
            self.performance_history.append(metric)
    
    def _calculate_system_performance(self) -> float:
        """Calculate overall system performance score"""
        # This is a simplified calculation
        # In a real implementation, you'd weight different factors
        
        cluster_status = self.llm_manager.get_cluster_status()
        if not cluster_status:
            return 0.5
        
        # Average cluster health
        health_scores = [status['health_ratio'] for status in cluster_status.values()]
        avg_health = sum(health_scores) / len(health_scores) if health_scores else 0.5
        
        # Factor in recent performance history
        recent_metrics = list(self.performance_history)[-10:]
        if recent_metrics:
            recent_avg = sum(m.value for m in recent_metrics) / len(recent_metrics)
            # Weighted average: 70% current health, 30% recent trend
            performance = 0.7 * avg_health + 0.3 * recent_avg
        else:
            performance = avg_health
        
        return min(max(performance, 0.0), 1.0)
    
    def _analyze_performance(self):
        """Analyze current performance and detect issues"""
        with self.lock:
            # Analyze trends for each metric type
            for metric_key, metrics in self.metrics_storage.items():
                if len(metrics) >= 5:  # Need minimum data for analysis
                    trend_analysis = self.analyzer.analyze_trends(list(metrics))
                    
                    # Log significant trends
                    if trend_analysis['confidence'] > 0.7:
                        self.audit_layer.log({
                            "type": "performance_trend",
                            "metric": metric_key,
                            "analysis": trend_analysis,
                            "timestamp": datetime.now().isoformat()
                        })
                    
                    # Detect anomalies
                    anomalies = self.analyzer.detect_anomalies(list(metrics))
                    if anomalies:
                        self.audit_layer.log({
                            "type": "performance_anomalies",
                            "metric": metric_key,
                            "anomaly_count": len(anomalies),
                            "timestamp": datetime.now().isoformat()
                        })
    
    def _run_optimization_cycle(self):
        """Run optimization cycle based on performance data"""
        print("PerformanceMonitor: Running optimization cycle")
        
        # Gather performance data
        performance_data = self._gather_performance_data()
        
        # Process feedback and trigger optimizations
        actions_taken = self.feedback_loop.process_feedback(performance_data)
        
        if actions_taken:
            print(f"PerformanceMonitor: Optimization actions taken: {actions_taken}")
            self.audit_layer.log({
                "type": "optimization_cycle",
                "actions_taken": actions_taken,
                "performance_data": performance_data,
                "timestamp": datetime.now().isoformat()
            })
    
    def _gather_performance_data(self) -> Dict[str, Any]:
        """Gather current performance data for analysis"""
        with self.lock:
            data = {
                "cluster_health": self.llm_manager.get_cluster_status(),
                "routing_statistics": self.router.get_routing_statistics(),
                "system_performance": self._calculate_system_performance()
            }
            
            # Add recent metrics summaries
            if self.performance_history:
                recent_values = [m.value for m in list(self.performance_history)[-20:]]
                data.update({
                    "average_performance": statistics.mean(recent_values),
                    "performance_std": statistics.stdev(recent_values) if len(recent_values) > 1 else 0,
                    "min_performance": min(recent_values),
                    "max_performance": max(recent_values)
                })
            
            return data
    
    def _cleanup_old_data(self):
        """Clean up old performance data"""
        cutoff_time = datetime.now() - timedelta(hours=self.data_retention_hours)
        
        with self.lock:
            # Clean metrics storage
            for metric_key in list(self.metrics_storage.keys()):
                metrics = self.metrics_storage[metric_key]
                # Remove old metrics
                while metrics and metrics[0].timestamp < cutoff_time:
                    metrics.popleft()
                
                # Remove empty metric keys
                if not metrics:
                    del self.metrics_storage[metric_key]
            
            # Clean performance history
            while self.performance_history and self.performance_history[0].timestamp < cutoff_time:
                self.performance_history.popleft()
    
    def get_performance_report(self) -> Dict[str, Any]:
        """Generate comprehensive performance report"""
        with self.lock:
            report = {
                "timestamp": datetime.now().isoformat(),
                "system_performance": self._calculate_system_performance(),
                "cluster_status": self.llm_manager.get_cluster_status(),
                "routing_statistics": self.router.get_routing_statistics(),
                "monitoring_status": {
                    "running": self.running,
                    "data_points": len(self.performance_history),
                    "metrics_tracked": len(self.metrics_storage),
                    "last_optimization": self.last_optimization.isoformat()
                }
            }
            
            # Add trend analysis for key metrics
            report["trend_analysis"] = {}
            for metric_key, metrics in self.metrics_storage.items():
                if len(metrics) >= 5:
                    trend = self.analyzer.analyze_trends(list(metrics))
                    report["trend_analysis"][metric_key] = trend
            
            return report
    
    def export_metrics(self, filepath: str) -> bool:
        """Export metrics to JSON file"""
        try:
            with self.lock:
                export_data = {
                    "export_timestamp": datetime.now().isoformat(),
                    "metrics": {}
                }
                
                # Export all metrics
                for metric_key, metrics in self.metrics_storage.items():
                    export_data["metrics"][metric_key] = [m.to_dict() for m in metrics]
                
                # Export performance history
                export_data["performance_history"] = [m.to_dict() for m in self.performance_history]
            
            # Write to file
            os.makedirs(os.path.dirname(filepath), exist_ok=True)
            with open(filepath, 'w') as f:
                json.dump(export_data, f, indent=2)
            
            print(f"PerformanceMonitor: Metrics exported to {filepath}")
            return True
            
        except Exception as e:
            print(f"PerformanceMonitor: Error exporting metrics: {e}")
            return False
    
    def import_metrics(self, filepath: str) -> bool:
        """Import metrics from JSON file"""
        try:
            with open(filepath, 'r') as f:
                import_data = json.load(f)
            
            with self.lock:
                # Import metrics
                for metric_key, metric_dicts in import_data.get("metrics", {}).items():
                    metrics = []
                    for metric_dict in metric_dicts:
                        metric = PerformanceMetric(
                            timestamp=datetime.fromisoformat(metric_dict['timestamp']),
                            component=metric_dict['component'],
                            metric_type=metric_dict['metric_type'],
                            value=metric_dict['value'],
                            metadata=metric_dict['metadata']
                        )
                        metrics.append(metric)
                    
                    self.metrics_storage[metric_key].extend(metrics)
                
                # Import performance history
                for metric_dict in import_data.get("performance_history", []):
                    metric = PerformanceMetric(
                        timestamp=datetime.fromisoformat(metric_dict['timestamp']),
                        component=metric_dict['component'],
                        metric_type=metric_dict['metric_type'],
                        value=metric_dict['value'],
                        metadata=metric_dict['metadata']
                    )
                    self.performance_history.append(metric)
            
            print(f"PerformanceMonitor: Metrics imported from {filepath}")
            return True
            
        except Exception as e:
            print(f"PerformanceMonitor: Error importing metrics: {e}")
            return False

