from fastapi import FastAPI, HTTPException, Request, Depends, status
from fastapi.responses import JSONResponse
from fastapi.security import OAuth2PasswordBearer
from fastapi.middleware.cors import CORSMiddleware
from fastapi.openapi.utils import get_openapi
import logging
import time

# --- Import all squads and dependencies (ensure these modules exist and are implemented!) ---
from kai_core.squads.admin import AdminSquad
from kai_core.squads.accounting import AccountingSquad
from kai_core.squads.construction_planning import ConstructionPlanningSquad
from kai_core.legal.legal_squad import LegalSquad
from kai_core.offense.offense_squad import OffenseSquad
from kai_core.defense.defense_squad import DefenseSquad
from kai_core.debug.debug_squad import DebugSquad
from kai_core.ethics.ethics_squad import EthicsSquad
from kai_core.supervisor.supervisor import Supervisor

from kai_core.utils.event_bus import EventBus
from kai_core.utils.audit_layer import AuditLayer
from kai_core.utils.memory import Memory
from kai_core.utils.llm_manager import LLMManager
from kai_core.utils.fusion_engine import FusionEngine
from kai_core.utils.junior_agent import JuniorAgent
from kai_core.utils.path_registry import PathRegistry

# --- Logging setup ---
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("KaiAPI")

# --- Security: OAuth2 stub (replace with your real logic for prod) ---
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

def decode_token(token):
    # Replace with your real decode logic (JWT, OAuth2, DB lookup, etc)
    # For a real system, validate the token and user scopes here.
    # Raise HTTPException if not valid.
    return {"sub": "user", "scopes": ["admin", "accounting", "construction", "legal", "offense", "defense", "debug", "ethics", "supervisor"]}

async def get_current_user(token: str = Depends(oauth2_scheme)):
    user = decode_token(token)
    if not user:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid authentication")
    return user

# --- Initialize all dependencies (real implementations!) ---
event_bus = EventBus()
audit_layer = AuditLayer()
memory = Memory()
llm_manager = LLMManager()
fusion_engine = FusionEngine()
junior_agent = JuniorAgent()
path_registry = PathRegistry()

# --- Initialize squads (all must be implemented as working classes) ---
admin_squad = AdminSquad(event_bus, audit_layer, memory, llm_manager, fusion_engine)
accounting_squad = AccountingSquad(event_bus, audit_layer, memory, llm_manager, fusion_engine)
construction_planning_squad = ConstructionPlanningSquad(
    event_bus, audit_layer, memory, llm_manager, junior_agent, path_registry,
    admin_squad=admin_squad,
    accounting_squad=accounting_squad
)
legal_squad = LegalSquad(
    event_bus, audit_layer, memory, llm_manager, fusion_engine,
    planner_squad=construction_planning_squad,
    admin_squad=admin_squad,
    accounting_squad=accounting_squad,
    notification_manager=junior_agent,
)
offense_squad = OffenseSquad(event_bus, audit_layer, memory, llm_manager, fusion_engine, notification_manager=junior_agent)
defense_squad = DefenseSquad(event_bus, audit_layer, memory, llm_manager, fusion_engine, junior_agent=junior_agent)
debug_squad = DebugSquad(event_bus, audit_layer, memory, llm_manager, fusion_engine, junior_agent=junior_agent)
ethics_squad = EthicsSquad(event_bus, audit_layer, memory, llm_manager, fusion_engine)
supervisor = Supervisor(event_bus, audit_layer, junior_agent)

# --- Link squads for actual interoperation (must be implemented in each squad) ---
admin_squad.link_construction_planning(construction_planning_squad)
admin_squad.link_accounting(accounting_squad)
accounting_squad.link_admin(admin_squad)
accounting_squad.link_construction_planning(construction_planning_squad)
# Add further linking as your squads require...

# --- FastAPI app ---
app = FastAPI(
    title="Kai Core Full Squad API",
    description="Production-grade API for all Kai Core squads with advanced features.",
    version="2.0.0",
    contact={"name": "Kai Core Maintainers", "email": "support@kaicore.ai"},
    license_info={"name": "Proprietary"},
    docs_url="/docs",
    redoc_url="/redoc"
)

# --- CORS (allow all for demo, restrict for production) ---
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Set this to your allowed domains in production!
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- Squad registry for DRY endpoint logic ---
SQUAD_MAP = {
    "admin": admin_squad,
    "accounting": accounting_squad,
    "construction": construction_planning_squad,
    "legal": legal_squad,
    "offense": offense_squad,
    "defense": defense_squad,
    "debug": debug_squad,
    "ethics": ethics_squad,
    "supervisor": supervisor
}

# --- Status endpoints for all squads ---
@app.get("/api/{squad}/status", summary="Get squad status", tags=["status"])
async def get_status(squad: str, user=Depends(get_current_user)):
    try:
        if squad not in SQUAD_MAP:
            raise HTTPException(status_code=404, detail="Unknown squad")
        return SQUAD_MAP[squad].get_status()
    except Exception as e:
        logger.error(f"{squad.capitalize()}Squad status error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# --- Universal execute endpoints for all squads ---
@app.post("/api/{squad}/execute", summary="Execute a command on a squad", tags=["execute"])
async def execute_command(squad: str, request: Request, user=Depends(get_current_user)):
    try:
        if squad not in SQUAD_MAP:
            raise HTTPException(status_code=404, detail="Unknown squad")
        data = await request.json()
        result, success, confidence, scorecard = SQUAD_MAP[squad].execute(data)
        return JSONResponse({"result": result, "success": success, "confidence": confidence, "scorecard": scorecard})
    except Exception as e:
        logger.error(f"{squad.capitalize()}Squad execute error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# --- Squad-specific history endpoints (only if implemented on the squad) ---
@app.get("/api/{squad}/history", summary="Get squad history", tags=["history"])
async def get_history(squad: str, limit: int = 50, user=Depends(get_current_user)):
    try:
        if squad not in SQUAD_MAP:
            raise HTTPException(status_code=404, detail="Unknown squad")
        squad_obj = SQUAD_MAP[squad]
        # Try several common history methods
        if hasattr(squad_obj, "get_history"):
            return squad_obj.get_history(limit=limit)
        elif hasattr(squad_obj, "get_incident_history"):
            return squad_obj.get_incident_history(limit=limit)
        elif hasattr(squad_obj, "get_diagnostic_history"):
            return squad_obj.get_diagnostic_history(limit=limit)
        else:
            raise HTTPException(status_code=404, detail="History not supported for this squad")
    except Exception as e:
        logger.error(f"{squad.capitalize()}Squad history error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# --- Health endpoint ---
@app.get("/api/health", summary="Health check endpoint", tags=["health"])
def health_check():
    return {"status": "ok", "timestamp": time.time()}

# --- OpenAPI override with custom tags ---
def custom_openapi():
    openapi_schema = get_openapi(
        title="Kai Core Full Squad API",
        version="2.0.0",
        description="Production-grade API for all Kai Core squads with OAuth2, CORS, squad history, health, and command endpoints.",
        routes=app.routes,
    )
    openapi_schema["tags"] = [
        {"name": "status", "description": "Squad status endpoints"},
        {"name": "execute", "description": "Squad command/execute endpoints"},
        {"name": "history", "description": "Squad history endpoints"},
        {"name": "health", "description": "Service health check"},
    ]
    return openapi_schema

app.openapi = custom_openapi

# --- Example: Serve with uvicorn for production ---
# if __name__ == "__main__":
#     import uvicorn
#     uvicorn.run(app, host="0.0.0.0", port=8000)
