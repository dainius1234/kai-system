"""
n8n_trigger.py - Webhook trigger handler for n8n integration

This module provides the webhook listener and trigger functionality for n8n integration,
allowing the Kai system to receive and process webhook events from n8n workflows.
"""

import json
import logging
import time
from datetime import datetime
from typing import Dict, Any, Optional, Callable, List

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("kai_logs/webhook.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("n8n_webhook")

class N8nTrigger:
    """
    N8n webhook trigger handler for the Kai System
    Processes incoming webhook events from n8n and triggers appropriate actions
    """

    def __init__(self, event_bus, audit_layer, kai_instance=None):
        """
        Initialize the N8n trigger handler

        Args:
            event_bus: The Kai system event bus
            audit_layer: The Kai system audit layer
            kai_instance: Optional reference to the main Kai instance
        """
        self.event_bus = event_bus
        self.audit_layer = audit_layer
        self.kai_instance = kai_instance

        # Registered webhook handlers
        self.webhook_handlers = {}

        # Event history
        self.event_history = []
        self.max_history = 100

        # Register default handlers
        self._register_default_handlers()

        logger.info("N8n webhook trigger handler initialized")

    def _register_default_handlers(self):
        """Register default webhook handlers"""
        self.register_handler("command", self._handle_command_webhook, "Execute a Kai command via webhook")
        self.register_handler("status", self._handle_status_webhook, "Get Kai system status via webhook")
        self.register_handler("trading", self._handle_trading_webhook, "Execute trading operations via webhook")
        self.register_handler("engineering", self._handle_engineering_webhook, "Process engineering data via webhook")
        self.register_handler("memory", self._handle_memory_webhook, "Perform memory operations via webhook")
        self.register_handler("voice", self._handle_voice_webhook, "Trigger voice commands via webhook")
        self.register_handler("squad", self._handle_squad_webhook, "Activate or query squads via webhook")

    def register_handler(self, handler_type: str, handler_func: Callable, description: str):
        """
        Register a new webhook handler

        Args:
            handler_type: Type identifier for the handler
            handler_func: Function to call when this handler type is triggered
            description: Description of the handler functionality
        """
        self.webhook_handlers[handler_type] = {
            "function": handler_func,
            "description": description,
            "registered_at": datetime.now().isoformat()
        }
        logger.info(f"Registered webhook handler: {handler_type} - {description}")

    def process_webhook(self, data: Dict[str, Any], headers: Dict[str, str]) -> Dict[str, Any]:
        """
        Process an incoming webhook request

        Args:
            data: The webhook payload data
            headers: The webhook request headers

        Returns:
            Dict containing the response data
        """
        try:
            event_id = f"webhook_{int(time.time())}_{len(self.event_history) + 1}"
            event_record = {
                "id": event_id,
                "timestamp": datetime.now().isoformat(),
                "headers": {k: v for k, v in headers.items() if k.lower() != 'authorization'},
                "data_keys": list(data.keys()) if data else [],
                "handler_type": data.get("type", "generic") if data else "generic"
            }
            self.event_history.append(event_record)
            if len(self.event_history) > self.max_history:
                self.event_history = self.event_history[-self.max_history:]

            self.audit_layer.log({
                "type": "webhook_received",
                "event_id": event_id,
                "timestamp": event_record["timestamp"],
                "handler_type": event_record["handler_type"]
            })
            self.event_bus.publish('webhook_received', {
                "event_id": event_id,
                "timestamp": event_record["timestamp"],
                "handler_type": event_record["handler_type"]
            })

            handler_type = data.get("type", "generic") if data else "generic"
            if handler_type in self.webhook_handlers:
                logger.info(f"Processing webhook with handler: {handler_type}")
                result = self.webhook_handlers[handler_type]["function"](data, headers, event_id)
                self.audit_layer.log({
                    "type": "webhook_processed",
                    "event_id": event_id,
                    "timestamp": datetime.now().isoformat(),
                    "handler_type": handler_type,
                    "success": result.get("success", False)
                })
                return result
            else:
                logger.warning(f"Unknown webhook handler type: {handler_type}")
                if data and "command" in data:
                    return self._handle_command_webhook(data, headers, event_id)
                return {
                    "success": False,
                    "error": f"Unknown webhook handler type: {handler_type}",
                    "event_id": event_id,
                    "timestamp": datetime.now().isoformat(),
                    "available_handlers": list(self.webhook_handlers.keys())
                }
        except Exception as e:
            logger.error(f"Error processing webhook: {e}", exc_info=True)
            return {
                "success": False,
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            }

    # --- Example handler implementations below ---
    def _handle_command_webhook(self, data, headers, event_id):
        command = data.get("command")
        logger.info(f"Executing command from webhook: {command}")
        # Example: Call the Kai main instance or command parser
        if self.kai_instance and hasattr(self.kai_instance, "parse_command"):
            result = self.kai_instance.parse_command(command)
        else:
            result = {"task": "unknown", "details": command}
        return {
            "success": True,
            "event_id": event_id,
            "timestamp": datetime.now().isoformat(),
            "result": result
        }

    def _handle_status_webhook(self, data, headers, event_id):
        logger.info("Status webhook triggered")
        # Example: Return a simple status
        return {
            "success": True,
            "event_id": event_id,
            "timestamp": datetime.now().isoformat(),
            "status": "Kai system is running"
        }

    def _handle_trading_webhook(self, data, headers, event_id):
        logger.info("Trading webhook triggered")
        # Implement trading logic or integration
        return {
            "success": True,
            "event_id": event_id,
            "timestamp": datetime.now().isoformat(),
            "message": "Trading operation executed"
        }

    def _handle_engineering_webhook(self, data, headers, event_id):
        logger.info("Engineering webhook triggered")
        # Implement engineering data processing
        return {
            "success": True,
            "event_id": event_id,
            "timestamp": datetime.now().isoformat(),
            "message": "Engineering data processed"
        }

    def _handle_memory_webhook(self, data, headers, event_id):
        logger.info("Memory webhook triggered")
        # Implement memory operation logic
        return {
            "success": True,
            "event_id": event_id,
            "timestamp": datetime.now().isoformat(),
            "message": "Memory operation performed"
        }

    def _handle_voice_webhook(self, data, headers, event_id):
        logger.info("Voice webhook triggered")
        # Implement voice command logic
        return {
            "success": True,
            "event_id": event_id,
            "timestamp": datetime.now().isoformat(),
            "message": "Voice command triggered"
        }

    def _handle_squad_webhook(self, data, headers, event_id):
        logger.info("Squad webhook triggered")
        # Implement squad activation/query logic
        return {
            "success": True,
            "event_id": event_id,
            "timestamp": datetime.now().isoformat(),
            "message": "Squad activated or queried"
        }

    def get_webhook_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """
        Get webhook event history

        Args:
            limit: Maximum number of events to return

        Returns:
            List of webhook event records
        """
        return self.event_history[-limit:] if limit > 0 else []

    def get_available_handlers(self) -> Dict[str, str]:
        """
        Get list of available webhook handlers

        Returns:
            Dict mapping handler types to descriptions
        """
        return {
            handler_type: info["description"]
            for handler_type, info in self.webhook_handlers.items()
        }

if __name__ == "__main__":
    # Minimal self-test harness with a mock event bus and audit layer
    class MockEventBus:
        def publish(self, event_type, event):
            print(f"Event published: {event_type}: {event}")

    class MockAuditLayer:
        def log(self, log_entry):
            print(f"Audit log: {log_entry}")

    print("Running N8nTrigger self-test...")
    event_bus = MockEventBus()
    audit_layer = MockAuditLayer()
    n8n = N8nTrigger(event_bus, audit_layer)

    # Example webhook processing
    example_data = {"type": "command", "command": "status"}
    example_headers = {"X-Test": "1"}
    result = n8n.process_webhook(example_data, example_headers)
    print("Webhook Result:", result)
