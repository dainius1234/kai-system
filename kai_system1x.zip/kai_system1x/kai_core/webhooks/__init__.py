"""
Initialize the integrations package for Kai system.
This package provides integration modules, e.g., for webhooks (n8n, etc.).
"""
