"""
VoiceInterface - Event-driven speech interface for the Kai System.

Handles speech-to-text (STT) and text-to-speech (TTS), and communicates with GUIs via an event bus.

Author: dainius1234
Copyright: (c) 2025
"""

import threading
import queue
import time
from datetime import datetime

try:
    import speech_recognition as sr
    import pyttsx3
    VOICE_AVAILABLE = True
except ImportError:
    VOICE_AVAILABLE = False
    print("Voice Interface: speech_recognition and/or pyttsx3 not installed. Voice features disabled.")

class VoiceInterface:
    """
    Voice Interface for the Kai System.
    Publishes and receives events via event_bus for GUI integration.
    """

    def __init__(self, event_bus, audit_layer=None, kai_instance=None):
        """
        Initialize the VoiceInterface.

        :param event_bus: The event bus for system-wide events.
        :param audit_layer: (Optional) Audit/event logging object.
        :param kai_instance: (Optional) Reference to Kai core system.
        """
        self.event_bus = event_bus
        self.audit_layer = audit_layer
        self.kai_instance = kai_instance

        self.is_enabled = False
        self.is_listening = False
        self.voice_queue = queue.Queue()
        self.response_queue = queue.Queue()
        self._shutdown = threading.Event()

        self.recognizer = None
        self.microphone = None
        self.tts_engine = None

        self.wake_words = ["kai", "hey kai", "jarvis", "computer"]
        self.confidence_threshold = 0.7
        self.listening_timeout = 5
        self.phrase_timeout = 1

        # Threading
        self.listen_thread = None
        self.speak_thread = None
        self.processing_thread = None

        # Listen for GUI control events
        self.event_bus.subscribe('voice_control', self.handle_control_event)

        if VOICE_AVAILABLE:
            self.initialize_voice_engines()
        print("Voice Interface: Initialized")

    def initialize_voice_engines(self):
        """Initialize speech recognition and TTS engines."""
        try:
            self.recognizer = sr.Recognizer()
            self.microphone = sr.Microphone()
            with self.microphone as source:
                self.recognizer.adjust_for_ambient_noise(source, duration=1)
            self.tts_engine = pyttsx3.init()
            voices = self.tts_engine.getProperty('voices')
            if voices:
                self.tts_engine.setProperty('voice', voices[0].id)
            self.tts_engine.setProperty('rate', 180)
            self.tts_engine.setProperty('volume', 0.8)
            print("Voice Interface: Voice engines initialized successfully")
            return True
        except Exception as e:
            print(f"Voice Interface: Error initializing voice engines: {e}")
            return False

    def enable_voice(self):
        """Enable the voice interface and start background processing."""
        if not VOICE_AVAILABLE:
            self.log_voice_event("Voice libraries not available", "error")
            return False
        if self.is_enabled:
            return True
        try:
            self.is_enabled = True
            self._shutdown.clear()
            self.listen_thread = threading.Thread(target=self.listen_loop, daemon=True)
            self.speak_thread = threading.Thread(target=self.speak_loop, daemon=True)
            self.processing_thread = threading.Thread(target=self.processing_loop, daemon=True)
            self.listen_thread.start()
            self.speak_thread.start()
            self.processing_thread.start()
            self.log_voice_event("Voice interface enabled", "info")
            self.speak("Voice interface activated. I'm listening for your commands.")
            self.event_bus.publish('voice_enabled', {'timestamp': datetime.now().isoformat(), 'status': 'enabled'})
            return True
        except Exception as e:
            self.log_voice_event(f"Error enabling voice: {e}", "error")
            return False

    def disable_voice(self):
        """Disable the voice interface and stop all threads gracefully."""
        if not self.is_enabled:
            return True
        try:
            self.is_enabled = False
            self.is_listening = False
            self._shutdown.set()
            self.log_voice_event("Voice interface disabled", "info")
            self.event_bus.publish('voice_disabled', {'timestamp': datetime.now().isoformat(), 'status': 'disabled'})
            return True
        except Exception as e:
            self.log_voice_event(f"Error disabling voice: {e}", "error")
            return False

    def listen_loop(self):
        """Listen for audio and queue voice commands."""
        while self.is_enabled and not self._shutdown.is_set():
            try:
                if not self.is_listening:
                    time.sleep(0.1)
                    continue
                with self.microphone as source:
                    audio = self.recognizer.listen(source, timeout=self.listening_timeout, phrase_time_limit=self.phrase_timeout)
                threading.Thread(target=self.process_audio, args=(audio,), daemon=True).start()
            except sr.WaitTimeoutError:
                pass
            except Exception as e:
                self.log_voice_event(f"Error in listen loop: {e}", "error")
                time.sleep(1)

    def process_audio(self, audio):
        """Process recognized audio and queue commands if appropriate."""
        try:
            text = self.recognizer.recognize_google(audio)
            confidence = 1.0
            self.log_voice_event(f"Recognized: '{text}' (confidence: {confidence:.2f})", "info")
            self.event_bus.publish('voice_command', {'text': text, 'confidence': confidence, 'timestamp': datetime.now().isoformat()})
            if confidence >= self.confidence_threshold:
                text_lower = text.lower()
                wake_word_detected = any(w in text_lower for w in self.wake_words)
                if wake_word_detected or self.is_listening:
                    command = text
                    for wake_word in self.wake_words:
                        command = command.lower().replace(wake_word, "").strip()
                    if command:
                        self.voice_queue.put({'command': command, 'confidence': confidence})
                        self.log_voice_event(f"Command queued: '{command}'", "info")
        except sr.UnknownValueError:
            pass
        except sr.RequestError as e:
            self.log_voice_event(f"Speech recognition error: {e}", "error")
        except Exception as e:
            self.log_voice_event(f"Error processing audio: {e}", "error")

    def processing_loop(self):
        """Process queued voice commands and generate responses."""
        while self.is_enabled and not self._shutdown.is_set():
            try:
                command_data = self.voice_queue.get(timeout=1)
                command = command_data['command']
                response = self.route_voice_command(command)
                if response:
                    self.response_queue.put(response)
                self.voice_queue.task_done()
            except queue.Empty:
                pass
            except Exception as e:
                self.log_voice_event(f"Error in processing loop: {e}", "error")

    def route_voice_command(self, command):
        """
        Publish the command for any GUI or module to handle, and optionally process internally.
        Returns a response string for TTS.
        """
        self.event_bus.publish('voice_command_processed', {'command': command, 'timestamp': datetime.now().isoformat()})
        if self.kai_instance:
            result = self.kai_instance.process_command(command)
            return result.get('message', 'Task completed.')
        return f"Command received: {command}"

    def speak_loop(self):
        """Continuously process the response queue and perform TTS."""
        while self.is_enabled and not self._shutdown.is_set():
            try:
                response = self.response_queue.get(timeout=1)
                self.speak(response)
                self.response_queue.task_done()
            except queue.Empty:
                pass
            except Exception as e:
                self.log_voice_event(f"Error in speak loop: {e}", "error")

    def speak(self, text):
        """
        Convert text to speech and publish the event.
        If TTS is unavailable, print instead.
        """
        if not VOICE_AVAILABLE or not self.tts_engine:
            print(f"Voice Interface: Would speak: '{text}'")
            return
        try:
            self.log_voice_event(f"Speaking: '{text}'", "info")
            self.tts_engine.say(text)
            self.tts_engine.runAndWait()
            self.event_bus.publish('voice_response', {'timestamp': datetime.now().isoformat(), 'text': text})
        except Exception as e:
            self.log_voice_event(f"Error speaking: {e}", "error")

    def handle_control_event(self, event):
        """
        Handle GUI or system events to control the voice interface.
        Supported actions: enable, disable, speak, start_listening, stop_listening
        """
        action = event.get('action', '')
        if action == 'enable':
            self.enable_voice()
        elif action == 'disable':
            self.disable_voice()
        elif action == 'speak':
            self.speak(event.get('text', ''))
        elif action == 'start_listening':
            self.is_listening = True
            self.log_voice_event("Started listening by GUI event", "info")
        elif action == 'stop_listening':
            self.is_listening = False
            self.log_voice_event("Stopped listening by GUI event", "info")

    def log_voice_event(self, message, level="info"):
        """Log voice interface events and publish them on the event bus."""
        timestamp = datetime.now().isoformat()
        log_entry = {
            'timestamp': timestamp,
            'module': 'voice_interface',
            'level': level,
            'message': message
        }
        if self.audit_layer:
            self.audit_layer.log_event('voice_event', log_entry)
        print(f"Voice Interface [{level.upper()}]: {message}")
        self.event_bus.publish('voice_log', log_entry)

    def shutdown(self):
        """Shutdown the voice interface and TTS engine."""
        self.disable_voice()
        try:
            if self.tts_engine:
                self.tts_engine.stop()
        except Exception:
            pass
        self.log_voice_event("Voice interface shutdown", "info")

if __name__ == "__main__":
    # Minimal self-test harness with a mock event bus and audit layer
    class MockEventBus:
        def subscribe(self, event_type, handler):
            print(f"Subscribed to {event_type}")
        def publish(self, event_type, event):
            print(f"Event published: {event_type}: {event}")

    class MockAuditLayer:
        def log_event(self, event_type, log_entry):
            print(f"Audit: {event_type}: {log_entry}")

    print("Running VoiceInterface self-test...")
    event_bus = MockEventBus()
    audit_layer = MockAuditLayer()
    vi = VoiceInterface(event_bus, audit_layer)
    if VOICE_AVAILABLE:
        vi.enable_voice()
        time.sleep(2)
        vi.speak("Self-test of the Kai Voice Interface is complete.")
        vi.shutdown()
    else:
        print("Voice features are not available. Test skipped.")
