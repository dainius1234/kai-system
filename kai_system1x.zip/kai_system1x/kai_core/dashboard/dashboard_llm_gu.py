import sys
from PyQt5.QtWidgets import QApplication, QWidget, QLabel, QPushButton, QVBoxLayout, QTextEdit, QHBoxLayout, QLineEdit

class DashboardGUI(QWidget):
    def __init__(self, llm_manager):
        super().__init__()
        self.llm_manager = llm_manager

        # Display labels for mode and settings
        self.mode_label = QLabel("Mode: default")
        self.temp_label = QLabel("Temperature: 0.4")
        self.top_p_label = QLabel("Top_p: 0.4")
        self.guardrail_label = QLabel("")
        self.response_area = QTextEdit()
        self.response_area.setReadOnly(True)

        # User input
        self.prompt_input = QLineEdit()
        self.prompt_input.setPlaceholderText("Ask Kai something...")

        # Mode selection buttons
        self.ohana_btn = QPushButton("Ohana Mode")
        self.relax_btn = QPushButton("Relax Mode")
        self.brainstorm_btn = QPushButton("Brainstorm Mode")
        self.default_btn = QPushButton("Default Mode")

        self.ohana_btn.clicked.connect(lambda: self.set_mode_trigger("ohana mode"))
        self.relax_btn.clicked.connect(lambda: self.set_mode_trigger("relax mode"))
        self.brainstorm_btn.clicked.connect(lambda: self.set_mode_trigger("brainstorm mode"))
        self.default_btn.clicked.connect(lambda: self.set_mode_trigger(""))

        # Send button
        self.send_btn = QPushButton("Send")
        self.send_btn.clicked.connect(self.handle_user_query)

        # Layouts
        mode_layout = QHBoxLayout()
        mode_layout.addWidget(self.ohana_btn)
        mode_layout.addWidget(self.relax_btn)
        mode_layout.addWidget(self.brainstorm_btn)
        mode_layout.addWidget(self.default_btn)

        settings_layout = QHBoxLayout()
        settings_layout.addWidget(self.mode_label)
        settings_layout.addWidget(self.temp_label)
        settings_layout.addWidget(self.top_p_label)

        main_layout = QVBoxLayout()
        main_layout.addLayout(settings_layout)
        main_layout.addWidget(self.guardrail_label)
        main_layout.addLayout(mode_layout)
        main_layout.addWidget(self.response_area)
        main_layout.addWidget(self.prompt_input)
        main_layout.addWidget(self.send_btn)

        self.setLayout(main_layout)
        self.setWindowTitle("Kai Dashboard")

        self.current_mode_trigger = ""  # Stores trigger for LLM prompt/context

    def set_mode_trigger(self, mode_trigger):
        self.current_mode_trigger = mode_trigger
        # Optionally display the selected mode immediately
        if mode_trigger == "":
            self.mode_label.setText("Mode: default")
        else:
            self.mode_label.setText(f"Mode: {mode_trigger.replace(' mode','').capitalize()}")

    def handle_user_query(self):
        user_prompt = self.prompt_input.text()
        if not user_prompt.strip():
            return
        response = self.ask_kai(user_prompt)
        self.response_area.append(f"You: {user_prompt}")
        self.response_area.append(f"Kai: {response}\n")
        self.prompt_input.clear()

    def ask_kai(self, user_prompt, task_type="general", context=None):
        # Insert the mode trigger into the prompt if needed
        prompt = f"{self.current_mode_trigger}\n{user_prompt}" if self.current_mode_trigger else user_prompt
        response, success, confidence, meta = self.llm_manager.get_llm_response(
            prompt=prompt, task_type=task_type, context=context
        )
        # Update status panel with mode/settings
        self.mode_label.setText(f"Mode: {meta.get('mode', 'default')}")
        self.temp_label.setText(f"Temperature: {meta.get('temperature', 0.4)}")
        self.top_p_label.setText(f"Top_p: {meta.get('top_p', 0.4)}")
        guardrail = meta.get('guardrail', '')
        self.guardrail_label.setText(f"Guardrail: {guardrail[:100]}..." if guardrail else "")
        return response

# To launch: 
# from kai.kai_system.kai_core.llm_manager import LLMManager
# llm_manager = LLMManager()
# app = QApplication(sys.argv)
# dashboard = DashboardGUI(llm_manager)
# dashboard.show()
# sys.exit(app.exec_())