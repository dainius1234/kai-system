import sys
import os
import numpy as np
import pandas as pd
from PyQt5 import QtWidgets, QtCore
import pyqtgraph as pg

# --- Connect your actual EventBus here ---
class EventBus:
    def __init__(self):
        self.handlers = {}
    def subscribe(self, topic, handler):
        self.handlers.setdefault(topic, []).append(handler)
    def publish(self, topic, payload):
        for handler in self.handlers.get(topic, []):
            handler(payload)

EVENT_BUS = EventBus()  # Replace with your real EventBus if available

# --- Local Data Backend: No placeholders; requires real data files ---
class LocalDataBackend:
    def __init__(self):
        self.data = {}
    def load_data(self, symbol, path):
        if path.endswith(".csv"):
            self.data[symbol] = pd.read_csv(path, index_col=0, parse_dates=True)
        elif path.endswith(".parquet"):
            self.data[symbol] = pd.read_parquet(path)
        elif path.endswith(".sqlite"):
            import sqlite3
            conn = sqlite3.connect(path)
            self.data[symbol] = pd.read_sql(f"SELECT * FROM {symbol}", conn)
            self.data[symbol].set_index(self.data[symbol].columns[0], inplace=True)
        else:
            raise ValueError("Unsupported file type.")
    def get_ohlcv(self, symbol, limit=500):
        if symbol in self.data:
            return self.data[symbol].tail(limit)
        else:
            raise ValueError(f"No data loaded for {symbol}. Please load data.")

DATA = LocalDataBackend()

def ma(series, w): return pd.Series(series).rolling(w).mean().to_numpy()
def ema(series, w): return pd.Series(series).ewm(span=w).mean().to_numpy()
def rsi(series, period=14):
    diff = pd.Series(series).diff(); gain = diff.clip(lower=0); loss = -diff.clip(upper=0)
    rs = gain.rolling(period).mean() / loss.rolling(period).mean()
    return 100 - (100/(1+rs)).to_numpy()
def macd(series, f=12, s=26, sig=9):
    fast = ema(series, f); slow = ema(series, s)
    macd = fast - slow
    signal = pd.Series(macd).ewm(span=sig).mean().to_numpy()
    return macd, signal, macd - signal
def boll(series, w=20, nstd=2):
    ma_ = ma(series, w)
    std = pd.Series(series).rolling(w).std().to_numpy()
    return ma_ + nstd*std, ma_ - nstd*std
def linreg_pred(x, horizon=20):
    from sklearn.linear_model import LinearRegression
    X = np.arange(len(x)).reshape(-1,1)
    model = LinearRegression().fit(X, x)
    Xf = np.arange(len(x), len(x)+horizon).reshape(-1,1)
    return model.predict(Xf)
def find_peaks(x, order=10):
    from scipy.signal import argrelextrema
    return argrelextrema(np.array(x), np.greater, order=order)[0]

class TradingSquadGUI(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Trading Squad – Kai System Module")
        self.setGeometry(60, 60, 2000, 1200)
        self.symbols = ["AAPL","NVDA","BTCUSD","SPX"]
        self.timeframes = {"1min":250, "5min":500, "1h":1000, "1d":1200}
        self.tabs = QtWidgets.QTabWidget()
        self.setCentralWidget(self.tabs)
        for sym in self.symbols:
            self.tabs.addTab(self.make_symbol_tab(sym), sym)
        self.statusBar().showMessage("Load data for each symbol to begin. No demo data used.")
        self.update_timer = QtCore.QTimer()
        self.update_timer.timeout.connect(self.refresh_all)
        self.update_timer.start(1200)
        EVENT_BUS.subscribe("trade_signal", self.on_trade_signal)

    def make_symbol_tab(self, symbol):
        tab = QtWidgets.QWidget()
        layout = QtWidgets.QHBoxLayout(tab)
        left = QtWidgets.QVBoxLayout()
        chart_control = QtWidgets.QHBoxLayout()
        tf_box = QtWidgets.QComboBox()
        for tf in self.timeframes: tf_box.addItem(tf)
        tf_box.setCurrentText("1d")
        tf_box.currentTextChanged.connect(lambda _: self.plot_chart(symbol, tf_box))
        chart_control.addWidget(QtWidgets.QLabel("Timeframe:")); chart_control.addWidget(tf_box)
        load_btn = QtWidgets.QPushButton("Load Data")
        load_btn.clicked.connect(lambda: self.load_local_data(symbol, tf_box))
        chart_control.addWidget(load_btn)
        left.addLayout(chart_control)
        chart_panel = pg.GraphicsLayoutWidget()
        plot = chart_panel.addPlot(title=f"{symbol} (Indicators, ML, Patterns, Offline)")
        left.addWidget(chart_panel, 7)
        tab.tf_box = tf_box
        tab.plot = plot
        tab.chart_panel = chart_panel
        tab.symbol = symbol
        layout.addLayout(left, 3)
        right = QtWidgets.QVBoxLayout()
        pnl_lbl = QtWidgets.QLabel("PnL: $0.00")
        portfolio_lbl = QtWidgets.QLabel("Portfolio: ...")
        signal_lbl = QtWidgets.QLabel("Signals: ...")
        pred_lbl = QtWidgets.QLabel("ML/Pattern: ...")
        right.addWidget(pnl_lbl); right.addWidget(portfolio_lbl)
        right.addWidget(signal_lbl); right.addWidget(pred_lbl)
        right.addWidget(QtWidgets.QLabel("Event Log"))
        event_log = QtWidgets.QTextEdit("System OK. Load data for analysis."); event_log.setReadOnly(True)
        right.addWidget(event_log, 2)
        tab.pnl_lbl = pnl_lbl
        tab.portfolio_lbl = portfolio_lbl
        tab.signal_lbl = signal_lbl
        tab.pred_lbl = pred_lbl
        tab.event_log = event_log
        layout.addLayout(right, 2)
        tab.setLayout(layout)
        return tab

    def plot_chart(self, symbol, tf_box):
        tab = self.tabs.currentWidget()
        tf = tf_box.currentText()
        n = self.timeframes.get(tf, 250)
        try:
            df = DATA.get_ohlcv(symbol, n)
        except Exception as e:
            tab.plot.clear()
            tab.signal_lbl.setText("No data loaded!")
            tab.pred_lbl.setText("")
            return
        close = df.Close.to_numpy(); open_ = df.Open.to_numpy()
        high = df.High.to_numpy(); low = df.Low.to_numpy()
        volume = df.Volume.to_numpy()
        tab.plot.clear()
        for i in range(len(df)):
            color = (0,255,0) if close[i]>=open_[i] else (255,68,68)
            tab.plot.plot([i,i], [low[i],high[i]], pen=pg.mkPen(color,width=1))
            tab.plot.plot([i-0.3,i+0.3], [open_[i],open_[i]], pen=pg.mkPen(color,width=2))
            tab.plot.plot([i-0.3,i+0.3], [close[i],close[i]], pen=pg.mkPen(color,width=2))
        tab.plot.plot(np.arange(len(df)), ma(close,20), pen=pg.mkPen('y', width=2))
        tab.plot.plot(np.arange(len(df)), ema(close,50), pen=pg.mkPen('g', width=2))
        upper, lower = boll(close)
        tab.plot.plot(np.arange(len(df)), upper, pen=pg.mkPen('c', width=1, style=QtCore.Qt.DashLine))
        tab.plot.plot(np.arange(len(df)), lower, pen=pg.mkPen('c', width=1, style=QtCore.Qt.DashLine))
        macd_line, macd_sig, macd_hist = macd(close)
        tab.plot.plot(np.arange(len(df)), macd_line, pen=pg.mkPen('r', width=1))
        tab.plot.plot(np.arange(len(df)), macd_sig, pen=pg.mkPen('w', width=1))
        rsi_line = rsi(close)
        rsi_view = tab.chart_panel.addPlot(row=1, col=0, title="RSI")
        rsi_view.plot(np.arange(len(df)), rsi_line, pen=pg.mkPen('b', width=1))
        rsi_view.showGrid(y=True)
        rsi_view.setYRange(0,100)
        pred = linreg_pred(close, horizon=20)
        pred_x = np.arange(len(df), len(df)+len(pred)); tab.plot.plot(pred_x, pred, pen=pg.mkPen('m', width=2, style=QtCore.Qt.DotLine))
        peaks = find_peaks(close, order=10)
        tab.plot.plot(peaks, close[peaks], pen=None, symbol='o', symbolBrush='w', symbolPen='r')
        tab.signal_lbl.setText("Signals: MA20/EMA50/Bollinger/MACD/RSI/ML")
        tab.pred_lbl.setText(f"ML Prediction: {pred[-1]:.2f} | Peaks: {len(peaks)}")

    def refresh_all(self):
        for i in range(self.tabs.count()):
            tab = self.tabs.widget(i)
            tab.pnl_lbl.setText("PnL: $0.00 (demo)")
            tab.portfolio_lbl.setText("Portfolio: ...")
            # No stubs; real values can be updated here from your backend

    def load_local_data(self, symbol, tf_box):
        fname, _ = QtWidgets.QFileDialog.getOpenFileName(self, f"Load Data for {symbol}", "", "CSV/Parquet/SQLite (*.csv *.parquet *.sqlite)")
        if fname:
            try:
                DATA.load_data(symbol, fname)
                QtWidgets.QMessageBox.information(self, "Data Loaded", f"Loaded {fname} for {symbol}")
                self.plot_chart(symbol, tf_box)
            except Exception as ex:
                QtWidgets.QMessageBox.warning(self, "Data Load Failed", str(ex))

    def on_trade_signal(self, payload):
        msg = f"Trade signal received: {payload}"
        for i in range(self.tabs.count()):
            tab = self.tabs.widget(i)
            tab.event_log.append(msg)

def main():
    app = QtWidgets.QApplication(sys.argv)
    pg.setConfigOption('background', '#181b21')
    pg.setConfigOption('foreground', 'w')
    gui = TradingSquadGUI()
    gui.show()
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()