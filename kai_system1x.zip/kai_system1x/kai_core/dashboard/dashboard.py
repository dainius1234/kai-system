import os
import threading
import shutil
from datetime import datetime

from .dashboard_gui import KaiDashboardGUI

class KaiDashboard:
    """
    KaiDashboard provides a central dashboard for monitoring and interacting with all squads,
    subscribing to EventBus events, updating metrics, and providing a GUI frontend.
    """

    EVENT_TYPES = ["log", "error", "heartbeat", "status", "metric", "custom"]

    def __init__(
        self, kai_instance, event_bus, audit_layer, memory, llm_manager, fusion_engine,
        trading_squad, planner_squad, legal_squad, admin_squad,
        accounting_squad, intel_squad, defense_squad, offense_squad,
        eco_squad, prime_squad, debug_squad, ethics_squad, planner_subsquad,
        junior_agent, supervisor, task_queue, survey_qa_module,
        construction_planning_squad, engineering_squad
    ):
        self.event_bus = event_bus
        self.audit_layer = audit_layer
        self.memory = memory
        self.llm_manager = llm_manager
        self.fusion_engine = fusion_engine
        self.kai_instance = kai_instance

        # Register all squad instances for UI and event tracking
        self.squad_instances = {
            "trading": trading_squad,
            "planner": planner_squad,
            "legal": legal_squad,
            "admin": admin_squad,
            "accounting": accounting_squad,
            "intel": intel_squad,
            "defense": defense_squad,
            "offense": offense_squad,
            "eco": eco_squad,
            "prime": prime_squad,
            "debug": debug_squad,
            "ethics": ethics_squad,
            "planner_sub": planner_subsquad,
            "junior": junior_agent,
            "supervisor": supervisor,
            "task_queue": task_queue,
            "survey_qa": survey_qa_module,
            "construction_planning": construction_planning_squad,
            "engineering": engineering_squad,
        }

        self.metrics = {
            "command_count": 0,
            "success_count": 0,
            "error_count": 0,
            "last_command_time": None,
            "squad_activity": {name: 0 for name in self.squad_instances.keys()},
            "overall_score": 0.0
        }

        self.event_history = []  # Event history (in-memory)
        self.last_heartbeat = {name: None for name in self.squad_instances.keys()}

        print("Kai Dashboard: Initialized for local, multi-squad, multi-window operation.")

        # -- Subscribe to standardized event types (log, error, heartbeat, status, metric, custom) --
        for event_type in self.EVENT_TYPES:
            self.event_bus.subscribe(event_type, self.handle_standard_event)

        # Dashboard lifecycle events
        self.event_bus.subscribe("dashboard_gui_started", self.handle_dashboard_event)
        # Optionally, subscribe to all events for debugging
        # self.event_bus.subscribe("*", self.handle_any_event)

        # Initialize GUI
        self.gui = KaiDashboardGUI(self)

    # --- Unified Handler for Standardized Events ---
    def handle_standard_event(self, event_type, details):
        """
        Handles standardized events. Expects details to include 'squad' key.
        """
        squad = details.get("squad", "unknown")
        msg = details.get("message", details)
        timestamp = details.get("timestamp", datetime.now().isoformat())
        event_record = {
            "event_type": event_type,
            "squad": squad,
            "message": msg,
            "timestamp": timestamp
        }
        self.event_history.append(event_record)
        # Limit history size for memory safety
        if len(self.event_history) > 10000:
            self.event_history = self.event_history[-5000:]

        # Metrics & heartbeat handling
        if squad in self.metrics["squad_activity"]:
            self.metrics["squad_activity"][squad] += 1
        if event_type == "error":
            self.metrics["error_count"] += 1
        if event_type == "heartbeat":
            self.last_heartbeat[squad] = timestamp

        # GUI live update
        if hasattr(self.gui, "display_event"):
            self.gui.display_event(event_type, squad, msg, timestamp)
        # Error popups/toasts
        if event_type == "error" and hasattr(self.gui, "display_error_popup"):
            self.gui.display_error_popup(f"[{squad.upper()}][ERROR] {msg}")

    # --- Dashboard Lifecycle Event Handling ---
    def handle_dashboard_event(self, event_type, details):
        print(f"[DASHBOARD][{event_type}] {details}")
        if hasattr(self.gui, "display_dashboard_event"):
            self.gui.display_dashboard_event(event_type, details)

    def handle_any_event(self, event_type, details):
        print(f"[DASHBOARD][ALL EVENTS] {event_type}: {details}")
        if hasattr(self.gui, "display_any_event"):
            self.gui.display_any_event(event_type, details)

    # --- Metrics and Data ---
    def update_metrics(self, scorecard):
        self.metrics["command_count"] += 1
        if scorecard.get("success_probability", 0.0) > 0.5:
            self.metrics["success_count"] += 1
        else:
            self.metrics["error_count"] += 1
        self.metrics["last_command_time"] = datetime.now().isoformat()
        self.metrics["overall_score"] = scorecard.get("overall_score", 0.0)
        squad_name = scorecard.get("squad_name", "unknown")
        if squad_name in self.metrics["squad_activity"]:
            self.metrics["squad_activity"][squad_name] += 1
        if self.audit_layer:
            self.audit_layer.log({
                "type": "dashboard_metric_update",
                "metrics": self.metrics,
                "timestamp": datetime.now().isoformat()
            })

    def get_dashboard_data(self):
        """Returns current dashboard data for display."""
        # Detect squad health based on last heartbeat
        now = datetime.now()
        squad_status = {}
        for squad, last in self.last_heartbeat.items():
            if last is None:
                status = "unknown"
            else:
                try:
                    last_dt = datetime.fromisoformat(last)
                    delta = (now - last_dt).total_seconds()
                    if delta < 90:
                        status = "active"
                    elif delta < 300:
                        status = "delayed"
                    else:
                        status = "offline"
                except Exception:
                    status = "unknown"
            squad_status[squad] = status

        return {
            "system_status": "operational",
            "metrics": self.metrics,
            "squad_status": squad_status,
            "event_history": self.event_history[-500:],  # recent history for GUI
            "last_updated": now.isoformat()
        }

    # --- GUI Control ---
    def start_gui(self):
        """Starts the local GUI with multi-window functionality."""
        print("Kai Dashboard: Starting local GUI with multi-window functionality.")
        # Run the GUI in a separate thread to avoid blocking
        threading.Thread(target=self.gui.start_gui, daemon=True).start()
        self.event_bus.publish("dashboard_gui_started", {"timestamp": datetime.now().isoformat()})

    def open_new_window(self, task_type):
        """Opens a new window for a specific task type."""
        print(f"Kai Dashboard: Opening new window for task: {task_type}")
        if hasattr(self.gui, 'root') and self.gui.root:
            self.gui._open_specialized_window(task_type)
        if self.audit_layer:
            self.audit_layer.log({
                "type": "dashboard_new_window",
                "task_type": task_type,
                "timestamp": datetime.now().isoformat()
            })

    def process_dashboard_command(self, command_text):
        """Processes a command received from the dashboard UI."""
        print(f"Kai Dashboard: Processing command from UI: {command_text}")
        if hasattr(self.kai_instance, "process_command"):
            return self.kai_instance.process_command(command_text)
        return {"response": "Kai instance has no process_command method."}

    def stop_gui(self):
        """Stops the GUI."""
        if hasattr(self, 'gui') and self.gui:
            self.gui.stop_gui()
            print("Kai Dashboard: GUI stopped.")

    # --- File Upload Support ---
    def store_uploaded_file(self, file_path, squad=None):
        """
        Moves or copies an uploaded file into the kai_uploads/ directory.
        If squad is specified, file is stored in a squad-specific subdirectory.
        """
        base_dir = os.path.abspath("kai_uploads")
        if not os.path.exists(base_dir):
            os.makedirs(base_dir, exist_ok=True)
        target_dir = os.path.join(base_dir, squad or "general")
        os.makedirs(target_dir, exist_ok=True)
        dest_path = os.path.join(target_dir, os.path.basename(file_path))
        # Avoid overwrite
        name, ext = os.path.splitext(dest_path)
        counter = 1
        while os.path.exists(dest_path):
            dest_path = f"{name}_{counter}{ext}"
            counter += 1
        shutil.copy2(file_path, dest_path)
        # Optionally log this event
        self.event_history.append({
            "event_type": "upload",
            "squad": squad or "general",
            "message": f"File uploaded: {os.path.basename(dest_path)}",
            "timestamp": datetime.now().isoformat()
        })
        return dest_path

    def list_uploaded_files(self, squad=None):
        """
        Returns a list of uploaded files for a squad (or all if squad=None).
        """
        base_dir = os.path.abspath("kai_uploads")
        target_dir = os.path.join(base_dir, squad or "general")
        if not os.path.exists(target_dir):
            return []
        return os.listdir(target_dir)

    # --- System Control Commands (menu actions) ---
    def pause_all_squads(self):
        # Example: set a flag or call pause on each squad if they support it
        for squad in self.squad_instances.values():
            if hasattr(squad, "pause"):
                squad.pause()
        self.event_history.append({
            "event_type": "status",
            "squad": "system",
            "message": "All squads paused via dashboard.",
            "timestamp": datetime.now().isoformat()
        })

    def resume_all_squads(self):
        for squad in self.squad_instances.values():
            if hasattr(squad, "resume"):
                squad.resume()
        self.event_history.append({
            "event_type": "status",
            "squad": "system",
            "message": "All squads resumed via dashboard.",
            "timestamp": datetime.now().isoformat()
        })

    def restart(self):
        # Placeholder: implement logic for system restart if needed
        self.event_history.append({
            "event_type": "status",
            "squad": "system",
            "message": "System restart requested.",
            "timestamp": datetime.now().isoformat()
        })
        # You may want to signal this to your main process

    def shutdown(self):
        # Placeholder: implement logic for system shutdown if needed
        self.event_history.append({
            "event_type": "status",
            "squad": "system",
            "message": "System shutdown requested.",
            "timestamp": datetime.now().isoformat()
        })
        # You may want to signal this to your main process

    def clear_event_history(self):
        self.event_history.clear()
        self.event_history.append({
            "event_type": "status",
            "squad": "system",
            "message": "Event history cleared.",
            "timestamp": datetime.now().isoformat()
        })
