import os
import sys
import shutil
from tkinterdnd2 import DND_FILES, TkinterDnD
import tkinter as tk
from tkinter import ttk, messagebox, filedialog, simpledialog
from datetime import datetime

UBUNTU_BG = "#f7f7f7"
UBUNTU_FG = "#2c2c2c"
UBUNTU_ACCENT = "#e95420"
UBUNTU_SIDEBAR = "#333333"
UBUNTU_TAB_BG = "#eeeeee"
UBUNTU_ACTIVE_TAB = "#ffffff"
UBUNTU_FONT = "Ubuntu"

class KaiDashboardGUI:
    def __init__(self, dashboard_instance):
        self.dashboard = dashboard_instance
        self.root = None
        self.tabs = {}  # key: tab_id, value: (frame, squad_or_task)
        self.upload_dir = os.path.abspath("kai_uploads")
        os.makedirs(self.upload_dir, exist_ok=True)

    def start_gui(self):
        self.root = TkinterDnD.Tk()
        self.root.title("Kai System Dashboard")
        self.root.geometry("1500x900")
        self._set_ubuntu_style()
        self._create_layout()
        self._create_sidebar()
        self._create_tabs_area()
        self._add_new_tab("Kai Chat", is_main=True)
        self.root.mainloop()

    def _set_ubuntu_style(self):
        style = ttk.Style(self.root)
        style.theme_use('clam')
        style.configure('.', font=(UBUNTU_FONT, 12), background=UBUNTU_BG, foreground=UBUNTU_FG)
        style.configure('TNotebook.Tab', padding=(12, 8), background=UBUNTU_TAB_BG)
        style.configure('TNotebook.Tab', focuscolor=UBUNTU_ACCENT)
        style.map("TNotebook.Tab", background=[("selected", UBUNTU_ACTIVE_TAB)])
        self.root.configure(bg=UBUNTU_BG)

    def _create_layout(self):
        self.root.grid_columnconfigure(1, weight=1)
        self.root.grid_rowconfigure(0, weight=1)

    def _create_sidebar(self):
        sidebar = tk.Frame(self.root, bg=UBUNTU_SIDEBAR, width=170)
        sidebar.grid(row=0, column=0, sticky="ns")
        sidebar.grid_propagate(False)
        self.sidebar = sidebar

        logo = tk.Label(sidebar, text="KAI", font=(UBUNTU_FONT, 22, "bold"), fg="#fff", bg=UBUNTU_SIDEBAR)
        logo.pack(pady=(16, 32))

        tk.Button(sidebar, text="New Chat", bg=UBUNTU_ACCENT, fg="#fff", font=(UBUNTU_FONT, 13, "bold"),
                  command=lambda: self._add_new_tab("Kai Chat")).pack(fill="x", pady=2, padx=10)
        tk.Button(sidebar, text="Open Squad", bg=UBUNTU_TAB_BG, command=self._open_squad_tab,
                  font=(UBUNTU_FONT, 12)).pack(fill="x", pady=2, padx=10)

        tk.Label(sidebar, text="Favorites", bg=UBUNTU_SIDEBAR, fg="#eee", font=(UBUNTU_FONT, 11)).pack(pady=(20, 2))
        self.fav_squads_frame = tk.Frame(sidebar, bg=UBUNTU_SIDEBAR)
        self.fav_squads_frame.pack(fill="x")
        for squad in sorted(self.dashboard.squad_instances.keys())[:4]:
            tk.Button(self.fav_squads_frame, text=squad.title(), bg=UBUNTU_TAB_BG,
                      command=lambda s=squad: self._add_new_tab(s.title())).pack(fill="x", pady=2, padx=10)

        tk.Button(sidebar, text="Uploads", bg=UBUNTU_TAB_BG, command=self._open_uploads_tab,
                  font=(UBUNTU_FONT, 12)).pack(fill="x", pady=(60,2), padx=10)
        tk.Button(sidebar, text="Settings", bg=UBUNTU_TAB_BG, command=self._open_settings_tab,
                  font=(UBUNTU_FONT, 12)).pack(fill="x", pady=2, padx=10)
        tk.Button(sidebar, text="Shutdown", bg=UBUNTU_ACCENT, fg="#fff",
                  font=(UBUNTU_FONT, 12), command=self._shutdown).pack(fill="x", pady=(60,4), padx=10)

    def _create_tabs_area(self):
        notebook = ttk.Notebook(self.root)
        notebook.grid(row=0, column=1, sticky="nsew")
        self.notebook = notebook
        self.notebook.enable_traversal()

    def _add_new_tab(self, title, is_main=False):
        frame = ttk.Frame(self.notebook)
        self.notebook.add(frame, text=title)
        self.notebook.select(frame)
        self.tabs[title] = frame
        if title.lower() == "kai chat":
            self._create_chat_tab(frame)
        elif title.lower() == "uploads":
            self._create_uploads_tab(frame)
        elif title.lower() == "settings":
            self._create_settings_tab(frame)
        else:
            self._create_squad_tab(frame, title)

    def _create_chat_tab(self, frame):
        chat_frame = tk.Frame(frame, bg=UBUNTU_BG)
        chat_frame.pack(fill="both", expand=True, padx=10, pady=10)
        chat_display = tk.Text(chat_frame, state="disabled", height=20, wrap="word", bg="#fff", font=(UBUNTU_FONT, 13))
        chat_display.pack(fill="both", expand=True)
        entry = tk.Entry(chat_frame, font=(UBUNTU_FONT, 13))
        entry.pack(fill="x", pady=(8, 0))
        entry.bind("<Return>", lambda e: self._send_chat(entry, chat_display, "kai"))
        send_btn = tk.Button(chat_frame, text="Send", bg=UBUNTU_ACCENT, fg="#fff",
                             font=(UBUNTU_FONT, 12, "bold"),
                             command=lambda: self._send_chat(entry, chat_display, "kai"))
        send_btn.pack(side="right", pady=4)

    def _send_chat(self, entry, display, target):
        msg = entry.get().strip()
        if not msg:
            return
        entry.delete(0, tk.END)
        display.config(state="normal")
        display.insert("end", f"You: {msg}\n", "user")
        # Simulate response (replace with actual system call)
        response = self.dashboard.process_dashboard_command(msg)
        display.insert("end", f"Kai: {response.get('response', '...')}\n", "kai")
        display.config(state="disabled")
        display.see("end")

    def _create_squad_tab(self, frame, squad):
        header = tk.Label(frame, text=f"{squad.title()} Squad", font=(UBUNTU_FONT, 16, "bold"), bg=UBUNTU_BG)
        header.pack(anchor="w", padx=10, pady=(10,0))
        chat_display = tk.Text(frame, state="disabled", height=16, wrap="word", bg="#fff", font=(UBUNTU_FONT, 12))
        chat_display.pack(fill="both", expand=True, padx=10)
        entry = tk.Entry(frame, font=(UBUNTU_FONT, 12))
        entry.pack(fill="x", padx=10, pady=(8,0))
        entry.bind("<Return>", lambda e: self._send_chat(entry, chat_display, squad))
        drop_area = tk.Label(frame, text="\nDrop files here for this squad\n", bg="#f2f1ed", relief="ridge",
                             borderwidth=2, font=(UBUNTU_FONT, 11), width=60, height=4)
        drop_area.pack(pady=8, padx=10, fill="x")
        drop_area.drop_target_register(DND_FILES)
        drop_area.dnd_bind('<<Drop>>', lambda e, s=squad: self._on_file_drop(e, s))
        file_list = tk.Listbox(frame, height=5)
        file_list.pack(fill="x", padx=10, pady=(4, 10))
        self._refresh_uploaded_files_list(file_list, squad)

    def _on_file_drop(self, event, squad=None):
        files = self.root.tk.splitlist(event.data)
        squad_dir = os.path.join(self.upload_dir, squad or "general")
        os.makedirs(squad_dir, exist_ok=True)
        for file_path in files:
            if os.path.isfile(file_path):
                dest_path = os.path.join(squad_dir, os.path.basename(file_path))
                shutil.copy2(file_path, dest_path)
        cur_frame = self.notebook.nametowidget(self.notebook.select())
        for widget in cur_frame.winfo_children():
            if isinstance(widget, tk.Listbox):
                self._refresh_uploaded_files_list(widget, squad)
        messagebox.showinfo("Upload Complete", f"Files uploaded for {squad or 'Kai'}.")

    def _refresh_uploaded_files_list(self, listbox, squad=None):
        listbox.delete(0, tk.END)
        squad_dir = os.path.join(self.upload_dir, squad or "general")
        if os.path.isdir(squad_dir):
            for fname in sorted(os.listdir(squad_dir)):
                listbox.insert(tk.END, fname)

    def _open_squad_tab(self):
        squad = simpledialog.askstring("Open Squad", "Enter squad name:")
        if squad:
            self._add_new_tab(squad.title())

    def _open_uploads_tab(self):
        if "Uploads" not in self.tabs:
            self._add_new_tab("Uploads")
        else:
            idx = list(self.tabs.keys()).index("Uploads")
            self.notebook.select(idx)

    def _create_uploads_tab(self, frame):
        tk.Label(frame, text="All Uploaded Files", font=(UBUNTU_FONT, 15, "bold"), bg=UBUNTU_BG).pack(anchor="w", padx=12, pady=(12,0))
        file_list = tk.Listbox(frame, height=15)
        file_list.pack(fill="both", expand=True, padx=12, pady=8)
        self._refresh_uploaded_files_list(file_list)
        tk.Button(frame, text="Open File", command=lambda: self._open_selected_file(file_list)).pack(pady=4)
        tk.Button(frame, text="Delete File", command=lambda: self._delete_selected_file(file_list)).pack()

    def _open_selected_file(self, listbox):
        selection = listbox.curselection()
        if not selection:
            messagebox.showinfo("Open File", "Select a file to open.")
            return
        fname = listbox.get(selection[0])
        path = os.path.join(self.upload_dir, fname)
        try:
            os.startfile(path)
        except Exception:
            messagebox.showerror("Error", "Could not open file.")

    def _delete_selected_file(self, listbox):
        selection = listbox.curselection()
        if not selection:
            messagebox.showinfo("Delete File", "Select a file to delete.")
            return
        fname = listbox.get(selection[0])
        path = os.path.join(self.upload_dir, fname)
        try:
            os.remove(path)
            self._refresh_uploaded_files_list(listbox)
            messagebox.showinfo("Deleted", f"Deleted {fname}.")
        except Exception as e:
            messagebox.showerror("Error", f"Could not delete file: {e}")

    def _open_settings_tab(self):
        if "Settings" not in self.tabs:
            self._add_new_tab("Settings")
        else:
            idx = list(self.tabs.keys()).index("Settings")
            self.notebook.select(idx)

    def _create_settings_tab(self, frame):
        tk.Label(frame, text="Settings", font=(UBUNTU_FONT, 15, "bold"), bg=UBUNTU_BG).pack(anchor="w", padx=12, pady=(12,0))
        tk.Label(frame, text="(Settings coming soon)", bg=UBUNTU_BG, fg="#888").pack(padx=12, pady=10)

    def _shutdown(self):
        if messagebox.askokcancel("Shutdown", "Are you sure you want to shutdown?"):
            self.root.destroy()
