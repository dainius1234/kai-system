import csv
import os
import json
import threading
from datetime import datetime
from collections import deque
import logging

from kai_core.memory.path_registry import PathRegistry

# --- Task Status Constants ---
TASK_PENDING = "pending"
TASK_RUNNING = "running"
TASK_PAUSED = "paused"
TASK_COMPLETED = "completed"
TASK_CANCELLED = "cancelled"
TASK_APPROVED = "approved"
TASK_REJECTED = "rejected"

class ToleranceProfileManager:
    def __init__(self, profile_dir="tolerance_profiles"):
        self.profile_dir = profile_dir
        os.makedirs(self.profile_dir, exist_ok=True)
        self.profiles = self.load_profiles()
    def load_profiles(self):
        profiles = {}
        for fname in os.listdir(self.profile_dir):
            if fname.endswith(".json"):
                with open(os.path.join(self.profile_dir, fname), "r") as f:
                    data = json.load(f)
                    profiles[data["name"]] = data["tolerances"]
        return profiles
    def save_profile(self, name, tolerances):
        profile_path = os.path.join(self.profile_dir, f"{name}.json")
        with open(profile_path, "w") as f:
            json.dump({"name": name, "tolerances": tolerances}, f)
        self.profiles[name] = tolerances
    def get_profile(self, name):
        return self.profiles.get(name)

class SurveyQATask:
    def __init__(self, design_path, asbuilt_path, deviation_limits, project_name, notes=None):
        self.design_path = design_path
        self.asbuilt_path = asbuilt_path
        self.deviation_limits = deviation_limits
        self.project_name = project_name
        self.notes = notes or {}
        self.status = TASK_PENDING
        self.progress = 0
        self.result = None
        self.thread = None
        self.cancel_flag = False
        self.paused_event = threading.Event()
        self.paused_event.set()  # Not paused by default
        self.comments = {}
        self.approval = TASK_PENDING
        self.audit_trail = []
        self.created_at = datetime.now().isoformat()
        self.completed_at = None
        self.report_path = None

class SurveyQAModule:
    """
    Feature-rich Survey QA module with live progress, pause/resume, batch, profiles, approvals, HTML reports, and dashboard integration.
    """
    def __init__(self, audit_layer, event_bus, junior_agent, memory, path_registry: PathRegistry, logger=None):
        self.audit_layer = audit_layer
        self.event_bus = event_bus
        self.junior_agent = junior_agent
        self.memory = memory
        self.path_registry = path_registry
        self.logger = logger or logging.getLogger("SurveyQAModule")
        self.paused = False
        self.shutdown_flag = False
        self.task_queue = deque()
        self.active_tasks = {}
        self.tolerance_profiles = ToleranceProfileManager()
        self.batch_thread = threading.Thread(target=self._process_task_queue, daemon=True)
        self.batch_thread.start()

    # --- Dashboard/Control Methods ---
    def pause(self):
        self.paused = True
        for task in self.active_tasks.values():
            task.paused_event.clear()
        self._publish_status("Survey QA Module paused.", level="info")

    def resume(self):
        self.paused = False
        for task in self.active_tasks.values():
            task.paused_event.set()
        self._publish_status("Survey QA Module resumed.", level="info")

    def shutdown(self):
        self.shutdown_flag = True
        for task in self.active_tasks.values():
            task.cancel_flag = True
        self._publish_status("Survey QA Module shutdown requested.", level="info")

    def _check_paused(self):
        if self.shutdown_flag:
            return True, "Survey QA Module is shut down."
        if self.paused:
            return True, "Survey QA Module is paused."
        return False, ""

    # --- EventBus Publishing ---
    def _publish_status(self, msg, level="info"):
        event = {"squad": "survey_qa", "message": msg, "level": level}
        if self.event_bus:
            self.event_bus.publish('status', event)
        self.logger.info(msg)

    def _publish_progress(self, task_id, percent):
        event = {"squad": "survey_qa", "task_id": task_id, "progress": percent}
        if self.event_bus:
            self.event_bus.publish('survey_qa_progress', event)
        self.logger.info(f"Task {task_id}: {percent}% complete")

    def _publish_error(self, msg):
        if self.event_bus:
            self.event_bus.publish('survey_qa_error', msg)
        self.logger.error(msg)

    # --- Tolerance Profiles ---
    def save_tolerance_profile(self, name, tolerances):
        self.tolerance_profiles.save_profile(name, tolerances)
        self._publish_status(f"Tolerance profile '{name}' saved.")
    def load_tolerance_profile(self, name):
        profile = self.tolerance_profiles.get_profile(name)
        if profile:
            self._publish_status(f"Tolerance profile '{name}' loaded.")
        else:
            self._publish_error(f"Tolerance profile '{name}' not found.")
        return profile

    # --- Batch/Task Queue ---
    def queue_task(self, design_path, asbuilt_path, deviation_limits, project_name, notes=None):
        task = SurveyQATask(design_path, asbuilt_path, deviation_limits, project_name, notes)
        self.task_queue.append(task)
        self._publish_status(f"Task for project '{project_name}' queued.")
        return task

    def _process_task_queue(self):
        while True:
            if self.shutdown_flag:
                break
            if self.paused:
                threading.Event().wait(1)
                continue
            if self.task_queue:
                task = self.task_queue.popleft()
                task.status = TASK_RUNNING
                self.active_tasks[task.project_name] = task
                task.thread = threading.Thread(target=self._run_task, args=(task,))
                task.thread.start()
                task.thread.join()
                task.completed_at = datetime.now().isoformat()
                del self.active_tasks[task.project_name]
            else:
                threading.Event().wait(1)

    def _run_task(self, task: SurveyQATask):
        try:
            self._publish_status(f"Task '{task.project_name}' started.")
            # --- Data Validation ---
            valid, validation_msg = self._validate_files(task.design_path, task.asbuilt_path)
            if not valid:
                self._publish_error(f"Task '{task.project_name}': {validation_msg}")
                task.status = TASK_CANCELLED
                return

            # --- Smart Data Validation ---
            design_points, asbuilt_points, smart_msg = self._load_and_validate_csvs(task.design_path, task.asbuilt_path)
            if smart_msg:
                self._publish_status(f"Task '{task.project_name}': {smart_msg}")
            all_ids = sorted(list(set(design_points.keys()) | set(asbuilt_points.keys())))
            n = len(all_ids)
            results = []
            for i, pid in enumerate(all_ids):
                if task.cancel_flag:
                    task.status = TASK_CANCELLED
                    self._publish_status(f"Task '{task.project_name}' cancelled.")
                    return
                while not task.paused_event.is_set():
                    threading.Event().wait(0.5)
                entry = self._process_point(pid, design_points, asbuilt_points, task.deviation_limits, task)
                results.append(entry)
                if i % max(1, n//20) == 0:
                    percent = int((i+1)*100/n)
                    self._publish_progress(task.project_name, percent)
            task.result = results
            task.status = TASK_COMPLETED
            self._publish_status(f"Task '{task.project_name}' completed.")
        except Exception as e:
            self._publish_error(f"Task '{task.project_name}' failed: {str(e)}")
            task.status = TASK_CANCELLED

    # --- File Validation and Smart Validation ---
    def _validate_files(self, design_path, asbuilt_path):
        for path, name in [(design_path, "Design"), (asbuilt_path, "As-Built")]:
            if not os.path.exists(path):
                return False, f"{name} file not found: {path}"
            if os.path.getsize(path) == 0:
                return False, f"{name} file is empty: {path}"
        return True, "Files validated."

    def _load_and_validate_csvs(self, design_path, asbuilt_path):
        # Smart validation: detect duplicates, missing values, auto-swap columns
        def load(path):
            with open(path, newline="") as f:
                reader = csv.DictReader(f)
                headers = [h.strip().lower() for h in reader.fieldnames]
                swap_needed = False
                if "northing" not in headers and "easting" in headers and "n" in headers and "e" in headers:
                    swap_needed = True
                seen = set()
                points = {}
                for row in reader:
                    pid = row.get("ID") or row.get("id") or row.get("point id")
                    if not pid or pid in seen:
                        continue
                    seen.add(pid)
                    if swap_needed:
                        row["Northing"], row["Easting"] = row["Easting"], row["Northing"]
                    points[pid] = row
                return points, swap_needed
        design_points, swap1 = load(design_path)
        asbuilt_points, swap2 = load(asbuilt_path)
        smart_msg = ""
        if swap1 or swap2:
            smart_msg = "Auto-swapped Easting/Northing columns for one or more files."
        if len(design_points) != len(set(design_points)):
            smart_msg += " Duplicate IDs detected in design file."
        if len(asbuilt_points) != len(set(asbuilt_points)):
            smart_msg += " Duplicate IDs detected in as-built file."
        return design_points, asbuilt_points, smart_msg

    # --- Point Processing (with comments/notes) ---
    def _process_point(self, pid, design_points, asbuilt_points, deviation_limits, task: SurveyQATask):
        entry = {"ID": pid, "Status": "", "Design": "", "AsBuilt": "", "dN": "N/A", "dE": "N/A", "dZ": "N/A",
                 "Comment": task.comments.get(pid, ""), "Note": task.notes.get(pid, "")}
        if pid not in design_points:
            entry["Status"] = "Missing in Design"
            return entry
        if pid not in asbuilt_points:
            entry["Status"] = "Missing in As-Built"
            return entry
        d = design_points[pid]
        a = asbuilt_points[pid]
        try:
            dn = float(a["Northing"]) - float(d["Northing"])
            de = float(a["Easting"]) - float(d["Easting"])
            dz = float(a["Elevation"]) - float(d["Elevation"])
            entry["Design"] = f"{d['Northing']},{d['Easting']},{d['Elevation']}"
            entry["AsBuilt"] = f"{a['Northing']},{a['Easting']},{a['Elevation']}"
            entry["dN"] = f"{dn:.3f}"
            entry["dE"] = f"{de:.3f}"
            entry["dZ"] = f"{dz:.3f}"
            tol = deviation_limits
            status = "OK"
            if abs(dn) > tol.get("northing", 1.0) or abs(de) > tol.get("easting", 1.0) or abs(dz) > tol.get("elevation", 1.0):
                status = "Out of Tolerance"
            entry["Status"] = status
        except Exception:
            entry["Status"] = "Invalid Data"
        return entry

    # --- HTML Report Generation (basic) ---
    def generate_html_report(self, task: SurveyQATask):
        html = "<html><head><title>QA Report</title></head><body>"
        html += f"<h2>QA Report for Project: {task.project_name}</h2>"
        html += f"<b>Status:</b> {task.status}<br><b>Created:</b> {task.created_at}<br><b>Completed:</b> {task.completed_at or 'N/A'}<br>"
        html += "<table border=1><tr>" + "".join(f"<th>{k}</th>" for k in task.result[0].keys()) + "</tr>"
        for row in task.result:
            html += "<tr>" + "".join(f"<td>{row[k]}</td>" for k in row.keys()) + "</tr>"
        html += "</table></body></html>"
        out_path = os.path.join(self.path_registry.get_path("qa_report_output_dir"), f"{task.project_name}_qa.html")
        with open(out_path, "w") as f:
            f.write(html)
        self._publish_status(f"HTML report generated: {out_path}")
        return out_path

    # --- Approval Workflow ---
    def approve_task(self, project_name, approver):
        task = self.active_tasks.get(project_name)
        if not task:
            self._publish_error(f"Task '{project_name}' not found for approval.")
            return False
        task.approval = TASK_APPROVED
        task.audit_trail.append({"action": "approved", "by": approver, "time": datetime.now().isoformat()})
        self._publish_status(f"Task '{project_name}' approved by {approver}.")
        return True

    def reject_task(self, project_name, approver, reason):
        task = self.active_tasks.get(project_name)
        if not task:
            self._publish_error(f"Task '{project_name}' not found for rejection.")
            return False
        task.approval = TASK_REJECTED
        task.audit_trail.append({"action": "rejected", "by": approver, "time": datetime.now().isoformat(), "reason": reason})
        self._publish_status(f"Task '{project_name}' rejected by {approver}: {reason}")
        return True

    # --- Per-point Comments/Notes ---
    def add_comment(self, project_name, point_id, comment):
        task = self.active_tasks.get(project_name)
        if not task:
            self._publish_error(f"Task '{project_name}' not found for comment.")
            return False
        task.comments[point_id] = comment
        self._publish_status(f"Comment added to point {point_id} in '{project_name}'.")
        return True

    # --- Dashboard Chat/Command Entry Point ---
    def process_command(self, command):
        cmd = (command or "").strip().lower()
        paused, msg = self._check_paused()
        if paused:
            return {"response": msg}
        if cmd in ("pause", "resume", "shutdown"):
            getattr(self, cmd)()
            return {"response": f"Survey QA Module: {cmd} command processed."}
        if cmd.startswith("approve"):
            parts = cmd.split()
            if len(parts) >= 3:
                _, project, user = parts[:3]
                return {"response": f"Approval: {self.approve_task(project, user)}"}
            return {"response": "Usage: approve <project_name> <user>"}
        if cmd.startswith("reject"):
            parts = cmd.split()
            if len(parts) >= 4:
                _, project, user, reason = parts[:4]
                return {"response": f"Rejection: {self.reject_task(project, user, reason)}"}
            return {"response": "Usage: reject <project_name> <user> <reason>"}
        if cmd.startswith("comment"):
            parts = cmd.split()
            if len(parts) >= 4:
                _, project, pid, comment = parts[:4]
                return {"response": f"Comment: {self.add_comment(project, pid, comment)}"}
            return {"response": "Usage: comment <project_name> <point_id> <comment>"}
        if cmd.startswith("save profile"):
            _, _, name, *tol_items = cmd.split()
            tol = dict(item.split("=") for item in tol_items)
            for k in tol:
                tol[k] = float(tol[k])
            self.save_tolerance_profile(name, tol)
            return {"response": f"Profile '{name}' saved."}
        if cmd.startswith("load profile"):
            _, _, name = cmd.split()
            tol = self.load_tolerance_profile(name)
            return {"response": f"Profile loaded: {tol}"}
        return {"response": f"Survey QA Module received: '{command}'"}

    # --- File Upload Handler (for drag-and-drop integration) ---
    def handle_uploaded_file(self, file_path):
        msg = f"File uploaded to Survey QA Module: {file_path}"
        self._publish_status(msg)
        return True, msg
