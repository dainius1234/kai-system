"""
kai.py - Core orchestrator for the Kai System.

Handles LLM, squads, event bus, dashboard, voice, and all core orchestration.
Now with Tool Manager, Environment Libraries, and LearningSquad support.

Author: dainius1234
Copyright: (c) 2025
"""

import os
import sys
import threading
import time
from datetime import datetime

# Core system modules
from .llm_manager import LLMManager
from .parser.parser import Parser
from .router.router_enhanced import Router
from .junior.junior import Junior
from .eventbus.eventbus import EventBus
from .supervisor.supervisor import Supervisor
from .queue.queue import TaskQueue
from .fusion.fusion import Fusion
from .audit.audit import Audit
from .memory.memory import Memory
from .memory.path_registry import PathRegistry

from .survey_qa.survey_qa import SurveyQAModule
from .voice_interface import VoiceInterface
from .monitoring.performance_monitor import PerformanceMonitor

# Squads
from .squads.trading import TradingSquad
from .squads.planner import PlannerSquad
from .squads.legal import LegalSquad
from .squads.admin import AdminSquad
from .squads.accounting import AccountingSquad, PersonalConfig, BrotherAccountingSystem
from .squads.intel import IntelSquad
from .squads.defense import DefenseSquad
from .squads.offense import OffenseSquad
from .squads.eco import EcoSquad
from .squads.prime import PrimeSquad
from .squads.debug import DebugSquad
from .squads.ethics import EthicsSquad
from .squads.planner_sub import PlannerSubSquad
from .squads.construction_planning import ConstructionPlanningSquad
from .squads.engineering_squad import EngineeringSquad
from .squads.learning import LearningSquad   # <-- NEW: Import the LearningSquad

from .dashboard.dashboard import KaiDashboard

# New: ToolManager and EnvironmentLibraries
from .tool_manager import ToolManager
from .environment_libraries import EnvironmentLibraries

class Kai:
    """
    Main orchestrator for the Kai System.
    """

    def __init__(self, enable_voice=True, enable_monitoring=True):
        """
        Initialize the Kai System and all core modules.
        """
        print("Kai System: Initializing with enhanced clustering and orchestration...")

        # Configuration
        self.enable_voice = enable_voice
        self.enable_monitoring = enable_monitoring

        # Core Modules
        self.event_bus = EventBus()
        self.audit_layer = Audit()
        self.memory = Memory()
        self.path_registry = PathRegistry(self.memory)
        self._register_default_paths()

        # EthicsSquad must be initialized first for LLMManager dependencies
        self.ethics_squad = EthicsSquad(self.event_bus, self.audit_layer, self.memory, None)

        self.llm_manager = LLMManager(
            audit_layer=self.audit_layer,
            event_bus=self.event_bus,
            ethics_squad=self.ethics_squad
        )
        self.ethics_squad.llm_manager = self.llm_manager

        # Accounting system
        self.personal_config = PersonalConfig()
        self.brother_accounting_system = BrotherAccountingSystem(self.personal_config)

        self.fusion_engine = Fusion(self.event_bus, self.audit_layer)
        self.junior_agent = Junior(self.event_bus, self.audit_layer, self.memory)
        self.supervisor = Supervisor(self.event_bus, self.audit_layer, self.junior_agent)
        self.task_queue = TaskQueue(self.event_bus, self.audit_layer)
        self.parser = Parser(
            self.event_bus, self.audit_layer, self.llm_manager, self.fusion_engine, self.ethics_squad
        )

        # Voice Interface
        self.voice_interface = None
        if self.enable_voice:
            try:
                self.voice_interface = VoiceInterface(self.event_bus, self.audit_layer, self)
                print("Kai System: Voice interface initialized")
            except Exception as e:
                print(f"Kai System: Voice interface initialization failed: {e}")
                self.voice_interface = None

        # Survey & QA
        self.survey_qa_module = SurveyQAModule(
            self.audit_layer, self.event_bus, self.junior_agent, self.memory, self.path_registry
        )

        # Squads
        self.trading_squad = TradingSquad(self.event_bus, self.audit_layer, self.memory, self.llm_manager, self.fusion_engine)
        self.planner_squad = PlannerSquad(self.event_bus, self.audit_layer, self.memory, self.llm_manager, self.fusion_engine)
        self.legal_squad = LegalSquad(self.event_bus, self.audit_layer, self.memory, self.llm_manager, self.fusion_engine)
        self.admin_squad = AdminSquad(self.event_bus, self.audit_layer, self.memory, self.llm_manager, self.fusion_engine)
        self.accounting_squad = AccountingSquad(self.brother_accounting_system, self.audit_layer, self.event_bus)
        self.intel_squad = IntelSquad(self.event_bus, self.audit_layer, self.memory, self.llm_manager, self.fusion_engine)
        self.defense_squad = DefenseSquad(self.event_bus, self.audit_layer, self.memory, self.llm_manager, self.fusion_engine)
        self.offense_squad = OffenseSquad(self.event_bus, self.audit_layer, self.memory, self.llm_manager, self.fusion_engine)
        self.eco_squad = EcoSquad(self.event_bus, self.audit_layer, self.memory, self.llm_manager, self.fusion_engine)
        self.prime_squad = PrimeSquad(self.event_bus, self.audit_layer, self.memory, self.llm_manager, self.fusion_engine, self.eco_squad)
        self.debug_squad = DebugSquad(self.event_bus, self.audit_layer, self.memory, self.llm_manager, self.junior_agent)
        self.planner_subsquad = PlannerSubSquad(self.event_bus, self.audit_layer, self.memory, self.llm_manager, self.fusion_engine)
        self.construction_planning_squad = ConstructionPlanningSquad(
            self.event_bus, self.audit_layer, self.memory, self.llm_manager, self.junior_agent, self.path_registry
        )
        self.engineering_squad = EngineeringSquad(
            self.event_bus, self.audit_layer, self.memory, self.llm_manager, self.junior_agent, self.path_registry
        )
        self.learning_squad = LearningSquad(
            self.event_bus, self.audit_layer, self.memory, self.llm_manager, self.fusion_engine
        )   # <-- NEW: LearningSquad

        # Dashboard
        self.dashboard = KaiDashboard(
            kai_instance=self,
            event_bus=self.event_bus,
            audit_layer=self.audit_layer,
            memory=self.memory,
            llm_manager=self.llm_manager,
            fusion_engine=self.fusion_engine,
            trading_squad=self.trading_squad,
            planner_squad=self.planner_squad,
            legal_squad=self.legal_squad,
            admin_squad=self.admin_squad,
            accounting_squad=self.accounting_squad,
            intel_squad=self.intel_squad,
            defense_squad=self.defense_squad,
            offense_squad=self.offense_squad,
            eco_squad=self.eco_squad,
            prime_squad=self.prime_squad,
            debug_squad=self.debug_squad,
            ethics_squad=self.ethics_squad,
            planner_subsquad=self.planner_subsquad,
            junior_agent=self.junior_agent,
            supervisor=self.supervisor,
            task_queue=self.task_queue,
            survey_qa_module=self.survey_qa_module,
            construction_planning_squad=self.construction_planning_squad,
            engineering_squad=self.engineering_squad,
            learning_squad=self.learning_squad        # <-- Add to dashboard
        )

        # Router
        self.router = Router(
            event_bus=self.event_bus,
            audit_layer=self.audit_layer,
            llm_manager=self.llm_manager,
            fusion_engine=self.fusion_engine,
            trading_squad=self.trading_squad,
            planner_squad=self.planner_squad,
            legal_squad=self.legal_squad,
            admin_squad=self.admin_squad,
            accounting_squad=self.accounting_squad,
            intel_squad=self.intel_squad,
            defense_squad=self.defense_squad,
            offense_squad=self.offense_squad,
            eco_squad=self.eco_squad,
            prime_squad=self.prime_squad,
            debug_squad=self.debug_squad,
            ethics_squad=self.ethics_squad,
            planner_subsquad=self.planner_subsquad,
            junior_agent=self.junior_agent,
            supervisor=self.supervisor,
            task_queue=self.task_queue,
            memory=self.memory,
            survey_qa_module=self.survey_qa_module,
            construction_planning_squad=self.construction_planning_squad,
            engineering_squad=self.engineering_squad,
            learning_squad=self.learning_squad        # <-- Add to router
        )

        # Performance Monitor
        self.performance_monitor = None
        if self.enable_monitoring:
            try:
                self.performance_monitor = PerformanceMonitor(
                    self.llm_manager, self.router, self.audit_layer, self.event_bus
                )
                print("Kai System: Performance monitoring initialized")
            except Exception as e:
                print(f"Kai System: Performance monitoring initialization failed: {e}")
                self.performance_monitor = None

        # New modules: Tool Manager and Environment Libraries
        self.env_root = os.path.abspath("./env")
        try:
            self.tool_manager = ToolManager(self.env_root, self.event_bus, self.audit_layer, self.memory)
            print("Kai System: ToolManager initialized")
        except Exception as e:
            print(f"Kai System: ToolManager initialization failed: {e}")
            self.tool_manager = None

        try:
            self.env_libraries = EnvironmentLibraries(self.env_root, self.event_bus, self.audit_layer, self.memory)
            print("Kai System: EnvironmentLibraries initialized")
        except Exception as e:
            print(f"Kai System: EnvironmentLibraries initialization failed: {e}")
            self.env_libraries = None

        print("Kai System: Initialization complete with enhanced clustering and orchestration.")

    def _register_default_paths(self):
        """Register default output/data paths in the system."""
        self.path_registry.register_path("qa_report_output_dir", "./kai_reports/qa", "Output directory for QA reports")
        self.path_registry.register_path("construction_plan_output_dir", "./kai_plans", "Output directory for construction plans")
        self.path_registry.save_paths()

    def start_services(self):
        """Start optional services (voice, monitoring, dashboard)."""
        print("Kai System: Starting services...")

        if self.performance_monitor:
            try:
                self.performance_monitor.start_monitoring()
                print("Kai System: Performance monitoring started")
            except Exception as e:
                print(f"Kai System: Failed to start performance monitoring: {e}")

        if self.voice_interface:
            try:
                self.voice_interface.enable_voice()
                print("Kai System: Voice interface started")
            except Exception as e:
                print(f"Kai System: Failed to start voice interface: {e}")

        if self.dashboard:
            try:
                self.dashboard.start_gui()
                print("Kai System: Dashboard started")
            except Exception as e:
                print(f"Kai System: Failed to start dashboard: {e}")

    def stop_services(self):
        """Stop optional services (voice, monitoring, dashboard)."""
        print("Kai System: Stopping services...")

        if self.performance_monitor:
            try:
                self.performance_monitor.stop_monitoring()
                print("Kai System: Performance monitoring stopped")
            except Exception as e:
                print(f"Kai System: Failed to stop performance monitoring: {e}")

        if self.voice_interface:
            try:
                self.voice_interface.disable_voice()
                print("Kai System: Voice interface stopped")
            except Exception as e:
                print(f"Kai System: Failed to stop voice interface: {e}")

        if self.dashboard:
            try:
                self.dashboard.stop_gui()
                print("Kai System: Dashboard stopped")
            except Exception as e:
                print(f"Kai System: Failed to stop dashboard: {e}")

    def process_command(self, command_text):
        """Process a command (used by voice interface, API, etc)."""
        try:
            result = self.run_command(command_text)
            return {
                'success': result[1],
                'response': result[0],
                'confidence': result[2],
                'scorecard': result[3],
                'timestamp': datetime.now().isoformat()
            }
        except Exception as e:
            return {
                'success': False,
                'response': f"Error processing command: {e}",
                'confidence': 0.0,
                'scorecard': {},
                'timestamp': datetime.now().isoformat()
            }

    def run_command(self, command_text):
        """Parse and route a command through the system."""
        print(f"\nKai System: Received command: '{command_text}'")
        parsed_command = self.parser.parse_command(command_text)
        if parsed_command:
            print(f"Kai System: Parsed command: {parsed_command}")
            response, success, confidence, scorecard = self.router.route_command(parsed_command)
            print(f"Kai System: Command execution result: {response}")
            print(f"Kai System: Success: {success}, Confidence: {confidence}")
            print(f"Kai System: Scorecard: {scorecard}")
            return response, success, confidence, scorecard
        else:
            print("Kai System: Command parsing failed.")
            return "Command parsing failed.", False, 0.0, {
                "success_probability": 0.0,
                "cost_estimate": 0.0,
                "risk_assessment": 1.0,
                "overall_score": 0.0
            }

    def get_system_status(self):
        """Get comprehensive system status including clustering and performance metrics."""
        status = {
            "timestamp": datetime.now().isoformat(),
            "system_health": "operational",
            "services": {
                "voice_interface": self.voice_interface is not None and hasattr(self.voice_interface, 'voice_enabled') and self.voice_interface.voice_enabled,
                "performance_monitoring": self.performance_monitor is not None and getattr(self.performance_monitor, "running", False),
                "tool_manager": self.tool_manager is not None,
                "env_libraries": self.env_libraries is not None,
                "learning_squad": self.learning_squad is not None
            },
            "clustering": {
                "cluster_status": self.llm_manager.get_cluster_status(),
                "routing_statistics": self.router.get_routing_statistics()
            },
            "paths": self.path_registry.list_paths(),
            "environments": self.env_libraries.list_environments() if self.env_libraries else {},
            "tools": self.tool_manager.tools if self.tool_manager else {},
        }
        if self.performance_monitor:
            status["performance"] = self.performance_monitor.get_performance_report()
        return status

    def optimize_system(self):
        """Trigger system-wide optimization."""
        print("Kai System: Running system optimization...")
        self.llm_manager.optimize_clusters()
        self.router.optimize_routing()
        if self.performance_monitor:
            pass  # Performance monitor runs its own optimization cycle
        self.audit_layer.log({
            "type": "system_optimization",
            "timestamp": datetime.now().isoformat()
        })
        print("Kai System: System optimization complete")

    # ------- NEW: Tool Manager API -------
    def list_environments(self):
        """List available environments (from Tool Manager)."""
        if not self.tool_manager:
            return []
        return self.tool_manager.list_environments()

    def list_tools(self, env):
        """List tools in a given environment."""
        if not self.tool_manager:
            return []
        return self.tool_manager.list_tools(env)

    def launch_tool(self, env, tool_name, args=None):
        """Launch a tool/script from a specified environment."""
        if not self.tool_manager:
            return False
        return self.tool_manager.launch_tool(env, tool_name, args)

    def register_tool(self, env, name, path):
        """Register a new tool in the specified environment."""
        if not self.tool_manager:
            return False
        self.tool_manager.register_tool(env, name, path)
        return True

    def refresh_tools(self):
        """Re-scan all environments for tools."""
        if self.tool_manager:
            self.tool_manager.refresh()

    def get_environment_metadata(self, env):
        """Get metadata for an environment."""
        if not self.env_libraries:
            return {}
        return self.env_libraries.get_metadata(env)

    def refresh_environments(self):
        """Re-index all environments."""
        if self.env_libraries:
            self.env_libraries.refresh()

if __name__ == "__main__":
    print("Running kai.py directly. For full system test, run test_kai_system.py.")
    # Example for direct execution:
    # kai = Kai()
    # kai.run_command("analyze market trends")
