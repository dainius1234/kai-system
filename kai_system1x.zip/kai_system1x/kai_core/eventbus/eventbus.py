import threading
from typing import Callable, Dict, List, Any, Optional, Set
import logging

class EventBus:
    """
    Production-ready, thread-safe in-process EventBus for pub/sub communication.
    Supports:
    - Per-event-type and global ('*') subscribers.
    - Duplicate prevention.
    - Synchronous callbacks.
    - Optional logging for critical events.
    """

    def __init__(self, logger: Optional[logging.Logger] = None):
        self._subscribers: Dict[str, List[Callable[[str, Any], None]]] = {}
        self._lock = threading.RLock()
        self.logger = logger or logging.getLogger("EventBus")
        self._log_events: Set[str] = set()
        self.logger.debug("EventBus initialized.")

    def subscribe(self, event_type: str, callback: Callable[[str, Any], None]) -> None:
        """
        Subscribe a callback to an event type.
        Use '*' to subscribe to all events (wildcard/global).
        """
        with self._lock:
            if event_type not in self._subscribers:
                self._subscribers[event_type] = []
            if callback not in self._subscribers[event_type]:
                self._subscribers[event_type].append(callback)
                self.logger.debug(f"Subscribed {callback} to '{event_type}' events.")

    def unsubscribe(self, event_type: str, callback: Callable[[str, Any], None]) -> None:
        """
        Unsubscribe a callback from an event type.
        """
        with self._lock:
            if event_type in self._subscribers and callback in self._subscribers[event_type]:
                self._subscribers[event_type].remove(callback)
                self.logger.debug(f"Unsubscribed {callback} from '{event_type}' events.")

    def publish(self, event_type: str, details: Any = None) -> None:
        """
        Publish an event to all subscribers (per-type and global).
        Exceptions in subscribers are caught and logged.
        """
        with self._lock:
            # Copy to avoid mutation during iteration
            subscribers = list(self._subscribers.get(event_type, []))
            global_subscribers = list(self._subscribers.get("*", []))
        self.logger.info(f"Publishing event: {event_type}, Details: {details}")
        for subscriber in subscribers + global_subscribers:
            try:
                subscriber(event_type, details)
            except Exception as e:
                self.logger.error(f"Error calling subscriber for {event_type}: {e}", exc_info=True)

    def subscribe_log(self, event_type: str) -> None:
        """
        Enable logging for a specific event type.
        When published, these events will be logged at INFO level.
        """
        with self._lock:
            self._log_events.add(event_type)

    def _log_event(self, event_type: str, details: Any):
        if event_type in self._log_events or "*" in self._log_events:
            self.logger.info(f"[EventBus LOG] {event_type}: {details}")

    def clear_subscribers(self) -> None:
        """
        Remove all subscribers. Use with caution.
        """
        with self._lock:
            self._subscribers.clear()
            self.logger.info("Cleared all EventBus subscribers.")

if __name__ == "__main__":
    import sys

    # Setup logging to stdout for demo
    logging.basicConfig(
        level=logging.DEBUG,
        format="%(asctime)s [%(levelname)s] %(message)s",
        handlers=[logging.StreamHandler(sys.stdout)]
    )
    logger = logging.getLogger("EventBusDemo")

    def test_callback(event_type, details):
        print(f"Test received: {event_type} with {details}")

    def all_events_callback(event_type, details):
        print(f"ALL EVENTS: {event_type} -> {details}")

    bus = EventBus(logger=logger)
    bus.subscribe("test", test_callback)
    bus.subscribe("*", all_events_callback)
    bus.publish("test", {"demo": True})
    bus.unsubscribe("test", test_callback)
    bus.publish("test", {"demo": False})  # Only global will receive
    bus.clear_subscribers()
    bus.publish("test", {"demo": "after-clear"})  # No output expected
