"""
kai_core/parser/parser.py - Advanced, production-grade command parser for the Kai System.

- Uses layered, extensible intent extraction (rule-based, fuzzy, LLM-ready).
- Emits audit and event logs for every parse.
- Optional: confidence scoring, entity stub, ethics check, LLM fallback.
- Extensible for future multi-intent, LLM/NLU, and multilingual support.
"""

from datetime import datetime
import difflib

class Parser:
    """
    Parser: Advanced Command Parser for the Kai System.
    - Intent and entity detection via hybrid rule/fuzzy matching.
    - Ethics squad integration.
    - Emits parse events and audits.
    - Ready for LLM/NLU or multi-intent extensions.
    """

    # Keyword mapping for each task
    TASK_KEYWORDS = {
        "code_generation": [
            "generate python script", "write code", "code for", "script for"
        ],
        "legal_advice": [
            "legal advice", "contract law", "legal question", "jurisdiction", "compliance"
        ],
        "general_query": [
            "what is", "tell me about", "explain", "define"
        ],
        "creative_writing": [
            "write a story", "poem about", "creative text", "generate a narrative"
        ],
        "trading_operation": [
            "execute trade", "buy stock", "sell stock", "arbitrage", "trading strategy"
        ],
        "planner_task": [
            "plan mission", "goal tracking", "priority realignment", "timeline optimization", "briefings"
        ],
        "user_management": [
            "manage user", "create user", "delete user", "user account", "permissions"
        ],
        "financial_analysis": [
            "financial report", "analyze finances", "budget analysis", "tax report"
        ],
        "intelligence_gathering": [
            "gather intelligence", "osint", "reconnaissance", "target collection"
        ],
        "threat_detection": [
            "detect threat", "cybersecurity scan", "vulnerability assessment",
            "anomaly detection", "intrusion"
        ],
        "penetration_testing": [
            "run pen test", "adversarial model testing", "simulate attack", "red team ops"
        ],
        "environmental_monitoring": [
            "monitor environment", "eco data", "pollution levels"
        ],
        "decision_making": [
            "make decision", "strategic choice", "evaluate options"
        ],
        "debug_analysis": [
            "debug code", "find error", "fix bug", "analyze script error"
        ],
        "ethical_review": [
            "ethical review", "moral compliance", "validate ethics"
        ],
        "system_maintenance": [
            "monitor modules", "self-repair", "manage backups", "roll patches", "quarantine logic"
        ],
        "event_management": [
            "dispatch event", "subscribe to event", "publish event"
        ],
        "process_supervision": [
            "watch process", "restart process", "isolate process"
        ],
        "task_queue_management": [
            "add task to queue", "get next task", "manage task priorities"
        ],
        "signal_fusion": [
            "fuse signals", "evaluate outcomes", "assign decision scores"
        ],
        "audit_logging": [
            "log action", "get audit log", "perform ethics audit"
        ],
        "memory_management": [
            "store state", "retrieve state", "save context snapshot", "share data"
        ],
        "dashboard_control": [
            "display metrics", "display alert", "update status", "display squad activity"
        ],
        "planner_sub_task": [
            "forecast vision", "adjust strategy", "track constraints", "brief kai on path shifts"
        ],
    }

    # For fuzzy/partial matching fallback
    _ALL_KEYWORDS = [(k, kw) for k, v in TASK_KEYWORDS.items() for kw in v]

    def __init__(self, event_bus, audit_layer, llm_manager, fusion_engine, ethics_squad=None, enable_llm_fallback=False):
        self.event_bus = event_bus
        self.audit_layer = audit_layer
        self.llm_manager = llm_manager
        self.fusion_engine = fusion_engine
        self.ethics_squad = ethics_squad
        self.enable_llm_fallback = enable_llm_fallback
        print("Parser: Command parser initialized.")

    def parse_command(self, command):
        print(f"Parser: Parsing command: {command}")

        command_lower = command.lower().strip()
        task_type, keyword_matched, confidence = self._intent_match(command_lower)

        parsed_command = {
            "task": task_type,
            "details": command,
            "confidence": confidence
        }
        if keyword_matched:
            parsed_command["matched_keyword"] = keyword_matched

        # Entity extraction stub (for future use)
        parsed_command["entities"] = self._extract_entities(command_lower, task_type)

        # Ethics check if enabled
        ethical_violation = False
        if self.ethics_squad:
            ethical_clearance, ethics_info = self.ethics_squad.validate_output(command, parsed_command)
            if not ethical_clearance:
                parsed_command["ethical_violation"] = True
                ethical_violation = True
                print("Parser: Command failed ethical clearance.")
        else:
            ethics_info = None

        # LLM/NLU fallback (if enabled and low confidence)
        if self.enable_llm_fallback and confidence < 0.65 and self.llm_manager:
            print("Parser: Falling back to LLM for intent parsing...")
            try:
                nlu_result = self.llm_manager.infer_intent(command)
                if nlu_result and nlu_result.get("task"):
                    parsed_command["llm_nlu_fallback"] = nlu_result
                    parsed_command["task"] = nlu_result["task"]
                    parsed_command["confidence"] = nlu_result.get("confidence", 0.75)
            except Exception as ex:
                print(f"Parser: LLM fallback failed: {ex}")

        # Audit/event logging
        self._publish_parse_event(parsed_command, ethics_info)

        print(f"Parser: Parsed command: {parsed_command}")
        return parsed_command

    def _intent_match(self, command_lower):
        # 1. Exact substring match (high confidence)
        for t_type, keywords in self.TASK_KEYWORDS.items():
            for keyword in keywords:
                if keyword in command_lower:
                    return t_type, keyword, 1.0

        # 2. Fuzzy/partial match (medium/low confidence)
        best_score, best_type, best_keyword = 0, "general_query", None
        for t_type, keyword in self._ALL_KEYWORDS:
            # Use difflib for fuzzy ratio (simulate partial/fuzzy matching)
            ratio = difflib.SequenceMatcher(None, keyword, command_lower).ratio()
            if ratio > best_score:
                best_score, best_type, best_keyword = ratio, t_type, keyword
        if best_score > 0.7:
            return best_type, best_keyword, best_score

        # 3. Default to general_query (low confidence)
        return "general_query", None, 0.5

    def _extract_entities(self, command_lower, task_type):
        # Simple stub: extract module names for certain tasks.
        # In production, use regex or spaCy/entity model.
        entities = {}
        if task_type in ("system_maintenance", "user_management"):
            for module in ["admin", "core", "accounting", "debug", "construction"]:
                if module in command_lower:
                    entities["module"] = module
                    break
        # Example: extract numbers for trading/finance
        if task_type in ("trading_operation", "financial_analysis"):
            import re
            numbers = re.findall(r"\b\d+\b", command_lower)
            if numbers:
                entities["numbers"] = numbers
        return entities

    def _publish_parse_event(self, parsed_command, ethics_info):
        # Publish parse event for audit/metrics
        evt = {
            "action": "parsed_command",
            "parsed_command": parsed_command,
            "timestamp": datetime.utcnow().isoformat()
        }
        if ethics_info:
            evt["ethics_info"] = ethics_info
        if self.event_bus:
            try:
                self.event_bus.publish("parser_event", evt)
            except Exception as ex:
                print(f"Parser: EventBus publish failed: {ex}")
        if self.audit_layer:
            try:
                self.audit_layer.log({
                    "type": "parser",
                    "event": "parsed_command",
                    "details": parsed_command,
                    "timestamp": evt["timestamp"]
                })
            except Exception as ex:
                print(f"Parser: Audit log failed: {ex}")
