import json
import os
import time
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

class BrainLocation:
    """
    Represents a local GGUF model location. Extendable for remote/tool/API.
    """
    def __init__(self, name, model_path, params=None):
        self.name = name
        self.model_path = Path(model_path)
        self.params = params or {}

    def __call__(self, prompt, max_tokens=512, temperature=0.4, top_p=0.4, stop=None, echo=False):
        """
        Replace this with your actual model inference (llama.cpp, ctransformers, etc).
        """
        # --- PLACEHOLDER for actual inference ---
        result = f"[{self.name}] {prompt}"
        return {"choices": [{"text": result}]}

class BrainTeam:
    """
    A team of BrainLocation instances. Supports parallel or sequential execution.
    """
    def __init__(self, brains, mode="parallel"):
        self.brains = brains  # list of BrainLocation
        self.mode = mode      # "parallel" or "pipeline"

    def run(self, prompt, **kwargs):
        results = []
        if self.mode == "parallel":
            with ThreadPoolExecutor(max_workers=len(self.brains)) as executor:
                futures = {executor.submit(b, prompt, **kwargs): b.name for b in self.brains}
                for f in as_completed(futures):
                    try:
                        result = f.result()["choices"][0]["text"]
                        results.append((futures[f], result))
                    except Exception as e:
                        results.append((futures[f], f"[ERROR] {e}"))
        elif self.mode == "pipeline":
            input_prompt = prompt
            for b in self.brains:
                output = b(input_prompt, **kwargs)["choices"][0]["text"]
                results.append((b.name, output))
                input_prompt = output
        return results

class AuditTrail:
    """
    Collects all steps, events, and decisions for explainability.
    """
    def __init__(self):
        self.events = []

    def log(self, event_type, data):
        self.events.append({"type": event_type, "data": data, "timestamp": time.time()})

    def to_dict(self):
        return list(self.events)

class LLMManager:
    def __init__(self, config_path="brain.json"):
        self.config_path = config_path
        self.reload_config()
        self.sessions = {}
        self.scores = {}
        self.brain_locations = self._init_brain_locations()
        self.mode_to_brain = self._map_modes_to_brain()
        self.teams = self._init_brain_teams()
        # You can expand with tool plugins here

    def reload_config(self):
        if os.path.exists(self.config_path):
            with open(self.config_path, "r") as f:
                self.config = json.load(f)
        else:
            raise FileNotFoundError("brain.json not found!")

    def _init_brain_locations(self):
        brains = {}
        for name, data in self.config.get("brain_locations", {}).items():
            brains[name] = BrainLocation(
                name=name,
                model_path=data["path"],
                params=data.get("params", {})
            )
        return brains

    def _map_modes_to_brain(self):
        """
        Map each mode to a brain location as specified in config.
        """
        mode_map = {}
        for mode, mode_data in self.config.get("modes", {}).items():
            location = mode_data.get("brain_location")
            if location and location in self.brain_locations:
                mode_map[mode] = self.brain_locations[location]
            else:
                mode_map[mode] = next(iter(self.brain_locations.values()))
        return mode_map

    def _init_brain_teams(self):
        """
        Example: Create ensembles. You can make this dynamic from config.
        """
        teams = {
            "safety_ensemble": BrainTeam([
                self.brain_locations.get("llama3"),
                self.brain_locations.get("llama2"),
                self.brain_locations.get("hermes")
            ], mode="parallel"),
            "creative_ensemble": BrainTeam([
                self.brain_locations.get("mixtral"),
                self.brain_locations.get("mistral")
            ], mode="parallel"),
            "command_team": BrainTeam([
                self.brain_locations.get("commandr"),
                self.brain_locations.get("hermes")
            ], mode="pipeline")
        }
        return teams

    def _detect_mode(self, prompt, context=None):
        """
        Detect mode based on triggers in prompt/context.
        """
        modes = self.config.get("modes", {})
        prompt_lower = prompt.lower()
        for mode_name, mode_data in modes.items():
            trigger = mode_data.get("trigger", "")
            if trigger and trigger.lower() in prompt_lower:
                return mode_name
            if context:
                for v in context.values():
                    if isinstance(v, str) and trigger and trigger.lower() in v.lower():
                        return mode_name
        return "default"

    def _get_llm_settings(self, mode):
        modes = self.config.get("modes", {})
        mode_data = modes.get(mode, {})
        return (
            mode_data.get("temperature", 0.4),
            mode_data.get("top_p", 0.4),
            mode_data.get("guardrail", ""),
            mode
        )

    def _prepare_prompt(self, guardrail, prompt):
        if guardrail:
            return f"{guardrail}\n{prompt}"
        return prompt

    def _run_punishment(self, response_text, session_id=None):
        punish_cfg = self.config.get("punishment", {})
        if not punish_cfg.get("enabled", False):
            return True, 0, ""
        banned_phrases = [
            "hallucination", "as an ai language model", "i cannot", "i don't know",
            "insufficient information", "i'm not sure", "i'm unable"
        ]
        lower_text = response_text.lower()
        for phrase in banned_phrases:
            if phrase in lower_text:
                penalty = punish_cfg.get("score_penalty", 10)
                score_min = punish_cfg.get("score_minimum", 0)
                score_max = punish_cfg.get("score_maximum", 100)
                if session_id:
                    prev_score = self.scores.get(session_id, score_max)
                    new_score = max(score_min, prev_score - penalty)
                    self.scores[session_id] = new_score
                return False, penalty, punish_cfg.get("fail_message", "")
        # Reward logic: reward clean/creative/accurate outputs
        reward = punish_cfg.get("score_penalty", 10) // 2
        score_max = punish_cfg.get("score_maximum", 100)
        if session_id:
            prev_score = self.scores.get(session_id, score_max)
            new_score = min(score_max, prev_score + reward)
            self.scores[session_id] = new_score
        return True, reward, ""

    def _run_double_check(self, prompt, response, brain, temperature, top_p, stop, audit):
        double_check_cfg = self.config.get("double_check", {})
        if not double_check_cfg.get("enabled", False):
            return response, True, "", []
        consistency_prompt = f"{double_check_cfg.get('consistency_prompt', '')}\n{response}"
        attempts = 0
        max_attempts = double_check_cfg.get("max_attempts", 2)
        double_checks = []
        while attempts < max_attempts:
            output = brain(
                consistency_prompt,
                max_tokens=512,
                temperature=temperature,
                top_p=top_p,
                stop=stop,
                echo=False
            )
            check_text = output["choices"][0]["text"].strip()
            double_checks.append(check_text)
            audit.log("double_check", {"attempt": attempts+1, "output": check_text})
            if "mistake" in check_text.lower() or "hallucinat" in check_text.lower() or "correct" in check_text.lower():
                response = check_text
                attempts += 1
            else:
                break
        return response, attempts < max_attempts, check_text, double_checks

    def get_llm_response(
        self,
        prompt,
        task_type="general",
        context=None,
        user=None,
        session_id=None,
        use_team=False,
        team_name=None
    ):
        self.reload_config()
        audit = AuditTrail()
        if session_id:
            session = self.sessions.setdefault(session_id, [])
            context = context or {}
            context['history'] = session[-10:]
            if session_id not in self.scores:
                self.scores[session_id] = self.config.get("punishment", {}).get("score_maximum", 100)

        mode = self._detect_mode(prompt, context)
        audit.log("mode_detected", {"mode": mode})

        # Choose brain or team
        if use_team and team_name and team_name in self.teams:
            team = self.teams[team_name]
            audit.log("team_selected", {"team": team_name, "brains": [b.name for b in team.brains]})
            # Run all brains in team
            team_results = team.run(prompt)
            outputs = [out for _, out in team_results]
            output = outputs[0]  # Could implement voting here
            audit.log("team_outputs", {"results": team_results})
            # For double-check, use first brain
            brain = team.brains[0]
            temperature, top_p, guardrail, mode = self._get_llm_settings(mode)
            prepared_prompt = self._prepare_prompt(guardrail, prompt)
        else:
            brain = self.mode_to_brain.get(mode, next(iter(self.brain_locations.values())))
            audit.log("brain_selected", {"brain": brain.name})
            temperature, top_p, guardrail, mode = self._get_llm_settings(mode)
            prepared_prompt = self._prepare_prompt(guardrail, prompt)
            out_obj = brain(
                prepared_prompt,
                max_tokens=512,
                temperature=temperature,
                top_p=top_p,
                stop=["\n\n"],
                echo=False
            )
            output = out_obj["choices"][0]["text"].strip()
            audit.log("brain_output", {"output": output})

        ok, score_delta, punish_msg = self._run_punishment(output, session_id=session_id)

        # Optionally double-check
        output, did_check, check_text, double_checks = self._run_double_check(
            prompt, output, brain, temperature, top_p, ["\n\n"], audit
        )

        if session_id:
            self.sessions[session_id].append({
                "prompt": prompt,
                "output": output,
                "timestamp": time.time()
            })

        return {
            "output": output,
            "ok": ok,
            "score_delta": score_delta,
            "punish_msg": punish_msg,
            "audit": audit.to_dict(),
            "double_checks": double_checks
        }
