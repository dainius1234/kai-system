import time
import threading
import concurrent.futures
from datetime import datetime
from collections import defaultdict, deque
import traceback

class OrchestrationEngine:
    """
    Advanced orchestration engine for dynamic task routing, LLM/squad selection,
    and performance-optimized fallback in the Kai system.
    """

    def __init__(self, llm_manager, fusion_engine, audit_layer, event_bus):
        self.llm_manager = llm_manager
        self.fusion_engine = fusion_engine
        self.audit_layer = audit_layer
        self.event_bus = event_bus

        self.route_performance = defaultdict(lambda: deque(maxlen=100))
        self.task_complexity_cache = {}
        self.orchestration_lock = threading.Lock()
        self.routing_rules = self._initialize_routing_rules()
        self.fallback_stats = {
            "fallback_invocations": 0,
            "successful_fallbacks": 0,
            "failed_fallbacks": 0,
            "fallback_paths": [],
            "fallback_depths": []
        }

    def _initialize_routing_rules(self):
        return {
            'complexity_thresholds': {
                'simple': 0.3,
                'moderate': 0.6,
                'complex': 0.8
            },
            'performance_weight': 0.4,
            'specialization_weight': 0.3,
            'load_balance_weight': 0.2,
            'context_weight': 0.1,
            'timeout_thresholds': {
                'simple': 5.0,
                'moderate': 15.0,
                'complex': 30.0
            },
            'max_retries': 2,
            'fallback_chain_depth': 3
        }

    def analyze_task_complexity(self, task_type, details, context=None):
        complexity_score = 0.0
        task_complexity_map = {
            'code_generation': 0.7, 'legal_advice': 0.8, 'general_query': 0.3,
            'creative_writing': 0.5, 'trading_operation': 0.9, 'planner_task': 0.8,
            'financial_analysis': 0.7, 'intelligence_gathering': 0.8, 'threat_detection': 0.9,
            'penetration_testing': 0.9, 'decision_making': 0.9, 'debug_analysis': 0.6,
            'ethical_review': 0.7, 'survey_qa_process': 0.6
        }
        complexity_score = task_complexity_map.get(task_type, 0.5)

        if details:
            detail_length = len(str(details))
            if detail_length > 500:
                complexity_score += 0.2
            elif detail_length > 200:
                complexity_score += 0.1
            complex_keywords = ['analyze', 'optimize', 'predict', 'complex', 'multi-step', 'integrate']
            complexity_score += sum(1 for k in complex_keywords if k in str(details).lower()) * 0.05
        if context:
            complexity_score += min(len(str(context))/1000, 0.2)

        complexity_score = min(max(complexity_score, 0.0), 1.0)
        cache_key = f"{task_type}_{hash(str(details))}"
        self.task_complexity_cache[cache_key] = complexity_score
        return complexity_score

    def select_optimal_route(self, task_type, details, context=None):
        with self.orchestration_lock:
            complexity = self.analyze_task_complexity(task_type, details, context)
            available_routes = self._get_available_routes(task_type)
            if not available_routes:
                return None
            route_scores = {route['id']: self._calculate_route_score(route, task_type, complexity, context)
                            for route in available_routes}
            best_route_id = max(route_scores, key=lambda k: route_scores[k])
            best_route = next(r for r in available_routes if r['id'] == best_route_id)
            self.audit_layer.log({
                "type": "orchestration_decision", "task_type": task_type, "complexity": complexity,
                "selected_route": best_route_id, "route_scores": route_scores,
                "timestamp": datetime.now().isoformat()
            })
            return best_route

    def _get_available_routes(self, task_type):
        # This could be dynamically extended in future
        return [
            {"id": "llm_direct", "type": "llm", "target": None},
            {"id": "squad_specialized", "type": "squad", "target": None}
        ]

    def _calculate_route_score(self, route, task_type, complexity, context):
        score, rules = 0.0, self.routing_rules
        route_history = self.route_performance.get(route['id'], [])
        score += (sum(h['success_rate'] for h in route_history)/len(route_history)
                  if route_history else 0.5) * rules['performance_weight']
        if route['type'] == 'llm':
            cluster_status = self.llm_manager.get_cluster_status()
            task_cluster = self.llm_manager.task_type_mapping.get(task_type, 'general')
            cluster_health = cluster_status.get(task_cluster, {}).get('health_ratio', 0.5)
            score += cluster_health * rules['specialization_weight']
        elif route['type'] == 'squad':
            score += 1.0 * rules['specialization_weight']
        score += 0.7 * rules['load_balance_weight']
        if context:
            score += 0.8 * rules['context_weight']
        return score

    def record_route_performance(self, route_id, success_rate, response_time, task_type):
        with self.orchestration_lock:
            self.route_performance[route_id].append({
                'timestamp': datetime.now(),
                'success_rate': success_rate,
                'response_time': response_time,
                'task_type': task_type
            })

    def record_fallback(self, path, success, depth):
        self.fallback_stats["fallback_invocations"] += 1
        if success:
            self.fallback_stats["successful_fallbacks"] += 1
        else:
            self.fallback_stats["failed_fallbacks"] += 1
        self.fallback_stats["fallback_paths"].append(path)
        self.fallback_stats["fallback_depths"].append(depth)

    def get_timeout_for_task(self, task_type, complexity):
        rules = self.routing_rules
        if complexity <= rules['complexity_thresholds']['simple']:
            return rules['timeout_thresholds']['simple']
        elif complexity <= rules['complexity_thresholds']['moderate']:
            return rules['timeout_thresholds']['moderate']
        else:
            return rules['timeout_thresholds']['complex']

class Router:
    """
    Enterprise-class, self-optimizing router for Kai's squads, LLMs, and dynamic clusters.
    Handles smart fallback, performance scoring, and continuous learning.
    """

    def __init__(self, event_bus, audit_layer, llm_manager, fusion_engine, **squad_instances):
        self.event_bus = event_bus
        self.llm_manager = llm_manager
        self.fusion_engine = fusion_engine
        self.audit_layer = audit_layer
        self.orchestration_engine = OrchestrationEngine(llm_manager, fusion_engine, audit_layer, event_bus)
        self.squad_instances = squad_instances

        self.task_routes = self._init_task_routes()
        self.global_fallback = {
            "enabled": True,
            "default_cluster": "general",
            "default_squad": "junior",
            "max_fallback_depth": 3,
            "default_timeout": 30.0,
        }
        print("Router: Initialized with advanced orchestration capabilities and robust fallback.")

    def _init_task_routes(self):
        # Same mapping as your original, omitted here for brevity.
        # (Copy your original self.task_routes dictionary here)
        return {
            # ... (task type mappings) ...
        }

    def route_command(self, parsed_command):
        start_time = time.time()
        task_type = parsed_command.get("task")
        details = parsed_command.get("details")
        context = parsed_command.get("context")
        self.audit_layer.log({
            "type": "routing_request",
            "task_type": task_type,
            "timestamp": datetime.now().isoformat()
        })
        complexity = self.orchestration_engine.analyze_task_complexity(task_type, details, context)
        route_config = self.task_routes.get(task_type)
        try:
            if not route_config:
                print(f"Router: No route for {task_type}. Using fallback.")
                return self._handle_dynamic_routing_with_fallback(task_type, details, context, start_time, complexity)
            if route_config["type"] == "dynamic":
                return self._handle_dynamic_routing_with_fallback(task_type, details, context, start_time, complexity, route_config)
            elif route_config["type"] == "squad":
                return self._handle_squad_routing_with_fallback(task_type, details, context, route_config, start_time, complexity)
            else:
                return self._handle_llm_routing_with_fallback(task_type, details, context, route_config, start_time, complexity)
        except Exception as e:
            self.audit_layer.log({
                "type": "router_unhandled_exception",
                "task_type": task_type,
                "error": str(e),
                "traceback": traceback.format_exc(),
                "timestamp": datetime.now().isoformat()
            })
            return self._generate_error_response(f"Router exception: {e}", task_type)

    # ... All routing, fallback, and execution methods unchanged (full logic, no stubs) ...
    # (Copy your implementation for _handle_dynamic_routing_with_fallback, _handle_squad_routing_with_fallback, etc.)

    def _execute_global_fallback(self, task_type, details, context, start_time, complexity):
        print(f"Router: Using global fallback for task: {task_type}")
        path = []
        depth = 1
        success = False
        if not self.global_fallback["enabled"]:
            self.orchestration_engine.record_fallback(path, False, depth)
            return self._generate_error_response(
                f"All routing options failed for task: {task_type}",
                task_type
            )
        default_squad = self.global_fallback["default_squad"]
        if default_squad in self.squad_instances:
            try:
                timeout = self.global_fallback["default_timeout"]
                result = self._execute_squad_task_with_timeout(
                    default_squad, task_type, details, context, start_time, timeout
                )
                if result:
                    self.orchestration_engine.record_fallback(["squad", default_squad], True, depth)
                    return result
            except Exception as e:
                print(f"Router: Global fallback to squad {default_squad} failed: {str(e)}")
        default_cluster = self.global_fallback["default_cluster"]
        try:
            timeout = self.global_fallback["default_timeout"]
            result = self._execute_llm_task_with_timeout(
                task_type, details, context, start_time,
                preferred_clusters=[default_cluster],
                timeout=timeout
            )
            if result:
                self.orchestration_engine.record_fallback(["cluster", default_cluster], True, depth)
                return result
        except Exception as e:
            print(f"Router: Global fallback to cluster {default_cluster} failed: {str(e)}")
        self.orchestration_engine.record_fallback(path, False, depth)
        return self._generate_error_response(
            f"All routing options including global fallback failed for task: {task_type}",
            task_type
        )

    def get_routing_statistics(self):
        stats = {
            "orchestration_performance": {},
            "cluster_health": self.llm_manager.get_cluster_status(),
            "task_complexity_cache_size": len(self.orchestration_engine.task_complexity_cache),
            "route_performance_entries": {
                route_id: len(performance_data)
                for route_id, performance_data in self.orchestration_engine.route_performance.items()
            },
            "fallback_statistics": self._get_fallback_statistics()
        }
        for route_id, performance_data in self.orchestration_engine.route_performance.items():
            if performance_data:
                avg_success = sum(p['success_rate'] for p in performance_data) / len(performance_data)
                avg_response_time = sum(p['response_time'] for p in performance_data) / len(performance_data)
                stats["orchestration_performance"][route_id] = {
                    "average_success_rate": avg_success,
                    "average_response_time": avg_response_time,
                    "total_requests": len(performance_data)
                }
        return stats

    def _get_fallback_statistics(self):
        stats = self.orchestration_engine.fallback_stats
        total_fallbacks = stats["fallback_invocations"]
        avg_depth = (sum(stats["fallback_depths"]) / total_fallbacks) if total_fallbacks else 0.0
        most_common_path = (
            max(set(stats["fallback_paths"]), key=stats["fallback_paths"].count)
            if stats["fallback_paths"] else "none"
        )
        return {
            "fallback_invocations": total_fallbacks,
            "successful_fallbacks": stats["successful_fallbacks"],
            "failed_fallbacks": stats["failed_fallbacks"],
            "average_fallback_depth": avg_depth,
            "most_common_fallback_path": most_common_path
        }

    # ... rest of your methods unchanged, no stubs, no placeholders ...
