# kai_core/router/router.py

import time
from datetime import datetime
from collections import defaultdict, deque
import threading

class OrchestrationEngine:
    """Advanced orchestration engine for dynamic task routing and LLM selection"""
    
    def __init__(self, llm_manager, fusion_engine, audit_layer, event_bus):
        self.llm_manager = llm_manager
        self.fusion_engine = fusion_engine
        self.audit_layer = audit_layer
        self.event_bus = event_bus
        
        # Performance tracking
        self.route_performance = defaultdict(lambda: deque(maxlen=100))
        self.task_complexity_cache = {}
        self.orchestration_lock = threading.Lock()
        
        # Dynamic routing rules
        self.routing_rules = self._initialize_routing_rules()
        
    def _initialize_routing_rules(self):
        """Initialize dynamic routing rules based on task characteristics"""
        return {
            'complexity_thresholds': {
                'simple': 0.3,
                'moderate': 0.6,
                'complex': 0.8
            },
            'performance_weight': 0.4,
            'specialization_weight': 0.3,
            'load_balance_weight': 0.2,
            'context_weight': 0.1
        }
    
    def analyze_task_complexity(self, task_type, details, context=None):
        """Analyze task complexity to inform routing decisions"""
        complexity_score = 0.0
        
        # Base complexity by task type
        task_complexity_map = {
            'code_generation': 0.7,
            'legal_advice': 0.8,
            'general_query': 0.3,
            'creative_writing': 0.5,
            'trading_operation': 0.9,
            'planner_task': 0.8,
            'financial_analysis': 0.7,
            'intelligence_gathering': 0.8,
            'threat_detection': 0.9,
            'penetration_testing': 0.9,
            'decision_making': 0.9,
            'debug_analysis': 0.6,
            'ethical_review': 0.7,
            'survey_qa_process': 0.6
        }
        
        complexity_score = task_complexity_map.get(task_type, 0.5)
        
        # Adjust based on details length and complexity
        if details:
            detail_length = len(str(details))
            if detail_length > 500:
                complexity_score += 0.2
            elif detail_length > 200:
                complexity_score += 0.1
                
            # Check for complex keywords
            complex_keywords = ['analyze', 'optimize', 'predict', 'complex', 'multi-step', 'integrate']
            keyword_count = sum(1 for keyword in complex_keywords if keyword in str(details).lower())
            complexity_score += keyword_count * 0.05
        
        # Context complexity
        if context:
            context_complexity = len(str(context)) / 1000  # Normalize
            complexity_score += min(context_complexity, 0.2)
        
        # Ensure score is within bounds
        complexity_score = min(max(complexity_score, 0.0), 1.0)
        
        # Cache the result
        cache_key = f"{task_type}_{hash(str(details))}"
        self.task_complexity_cache[cache_key] = complexity_score
        
        return complexity_score
    
    def select_optimal_route(self, task_type, details, context=None):
        """Select optimal route using advanced orchestration logic"""
        with self.orchestration_lock:
            # Analyze task complexity
            complexity = self.analyze_task_complexity(task_type, details, context)
            
            # Get available routes
            available_routes = self._get_available_routes(task_type)
            
            if not available_routes:
                return None
            
            # Score each route
            route_scores = {}
            for route in available_routes:
                score = self._calculate_route_score(route, task_type, complexity, context)
                route_scores[route['id']] = score
            
            # Select best route
            best_route_id = max(route_scores.keys(), key=lambda k: route_scores[k])
            best_route = next(r for r in available_routes if r['id'] == best_route_id)
            
            # Log orchestration decision
            self.audit_layer.log({
                "type": "orchestration_decision",
                "task_type": task_type,
                "complexity": complexity,
                "selected_route": best_route_id,
                "route_scores": route_scores,
                "timestamp": datetime.now().isoformat()
            })
            
            return best_route
    
    def _get_available_routes(self, task_type):
        """Get available routes for a task type"""
        # This would be expanded to include dynamic route discovery
        base_routes = [
            {"id": "llm_direct", "type": "llm", "target": None},  # Will be determined by LLMManager
            {"id": "squad_specialized", "type": "squad", "target": None}  # Will be determined by task mapping
        ]
        return base_routes
    
    def _calculate_route_score(self, route, task_type, complexity, context):
        """Calculate score for a route based on multiple factors"""
        score = 0.0
        rules = self.routing_rules
        
        # Performance weight
        route_history = self.route_performance.get(route['id'], [])
        if route_history:
            avg_performance = sum(h['success_rate'] for h in route_history) / len(route_history)
            score += avg_performance * rules['performance_weight']
        else:
            score += 0.5 * rules['performance_weight']  # Neutral score for new routes
        
        # Specialization weight
        if route['type'] == 'llm':
            # LLM routes get specialization bonus based on clustering
            cluster_status = self.llm_manager.get_cluster_status()
            task_cluster = self.llm_manager.task_type_mapping.get(task_type, 'general')
            if task_cluster in cluster_status:
                cluster_health = cluster_status[task_cluster]['health_ratio']
                score += cluster_health * rules['specialization_weight']
        elif route['type'] == 'squad':
            # Squad routes get full specialization bonus for matching tasks
            score += 1.0 * rules['specialization_weight']
        
        # Load balance weight (simplified)
        # In a real implementation, this would consider current system load
        score += 0.7 * rules['load_balance_weight']
        
        # Context weight
        if context:
            # Bonus for routes that can handle context
            score += 0.8 * rules['context_weight']
        
        return score
    
    def record_route_performance(self, route_id, success_rate, response_time, task_type):
        """Record performance metrics for route optimization"""
        with self.orchestration_lock:
            self.route_performance[route_id].append({
                'timestamp': datetime.now(),
                'success_rate': success_rate,
                'response_time': response_time,
                'task_type': task_type
            })

class Router:
    def __init__(self, event_bus, audit_layer, llm_manager, fusion_engine,
                 trading_squad, planner_squad, legal_squad, admin_squad,
                 accounting_squad, intel_squad, defense_squad, offense_squad,
                 eco_squad, prime_squad, debug_squad, ethics_squad, planner_subsquad,
                 junior_agent, supervisor, task_queue, memory, dashboard, survey_qa_module, construction_planning_squad):
        self.event_bus = event_bus
        self.audit_layer = audit_layer
        self.llm_manager = llm_manager
        self.fusion_engine = fusion_engine

        # Initialize orchestration engine
        self.orchestration_engine = OrchestrationEngine(
            llm_manager, fusion_engine, audit_layer, event_bus
        )

        self.squad_instances = {
            "trading": trading_squad,
            "planner": planner_squad,
            "legal": legal_squad,
            "admin": admin_squad,
            "accounting": accounting_squad,
            "intel": intel_squad,
            "defense": defense_squad,
            "offense": offense_squad,
            "eco": eco_squad,
            "prime": prime_squad,
            "debug": debug_squad,
            "ethics": ethics_squad,
            "planner_sub": planner_subsquad,
            "junior": junior_agent,
            "supervisor": supervisor,
            "task_queue": task_queue,
            "memory": memory,
            "dashboard": dashboard,
            "survey_qa": survey_qa_module,
            "construction_planning": construction_planning_squad,
        }

        # Enhanced task routes with dynamic routing capabilities
        self.task_routes = {
            "code_generation": {
                "type": "dynamic", 
                "preferred_clusters": ["technical", "expert"],
                "fallback_squads": [],
                "description": "Best for generating and understanding code."
            },
            "legal_advice": {
                "type": "dynamic", 
                "preferred_clusters": ["expert", "technical"],
                "fallback_squads": ["legal"],
                "description": "Specialized in legal and factual reasoning."
            },
            "general_query": {
                "type": "dynamic", 
                "preferred_clusters": ["general", "creative"],
                "fallback_squads": [],
                "description": "Good for broad knowledge and conversational tasks."
            },
            "creative_writing": {
                "type": "dynamic", 
                "preferred_clusters": ["creative", "general"],
                "fallback_squads": [],
                "description": "Suitable for creative text generation."
            },
            "trading_operation": {
                "type": "squad", 
                "target": "trading", 
                "description": "Handles financial trading and arbitrage."
            },
            "planner_task": {
                "type": "squad", 
                "target": "planner", 
                "description": "Assists in defining and tracking strategic goals."
            },
            "user_management": {
                "type": "squad", 
                "target": "admin", 
                "description": "Manages user accounts and system access."
            },
            "financial_analysis": {
                "type": "dynamic", 
                "preferred_clusters": ["expert", "technical"],
                "fallback_squads": ["accounting"],
                "description": "Generates financial reports and analysis."
            },
            "intelligence_gathering": {
                "type": "squad", 
                "target": "intel", 
                "description": "Conducts reconnaissance and OSINT."
            },
            "threat_detection": {
                "type": "squad", 
                "target": "defense", 
                "description": "Monitors and responds to cybersecurity threats."
            },
            "penetration_testing": {
                "type": "squad", 
                "target": "offense", 
                "description": "Performs adversarial model testing."
            },
            "environmental_monitoring": {
                "type": "squad", 
                "target": "eco", 
                "description": "Monitors environmental data."
            },
            "decision_making": {
                "type": "squad", 
                "target": "prime", 
                "description": "Facilitates high-level decision making."
            },
            "debug_analysis": {
                "type": "dynamic", 
                "preferred_clusters": ["technical", "expert"],
                "fallback_squads": ["debug"],
                "description": "Detects and analyzes code errors."
            },
            "ethical_review": {
                "type": "dynamic", 
                "preferred_clusters": ["safety", "general"],
                "fallback_squads": ["ethics"],
                "description": "Validates ethical compliance of actions."
            },
            "system_maintenance": {
                "type": "squad", 
                "target": "junior", 
                "description": "Handles DevOps and self-healing tasks."
            },
            "process_supervision": {
                "type": "squad", 
                "target": "supervisor", 
                "description": "Monitors and restarts key processes."
            },
            "task_queue_management": {
                "type": "squad", 
                "target": "task_queue", 
                "description": "Manages task priorities and scheduling."
            },
            "signal_fusion": {
                "type": "squad", 
                "target": "fusion", 
                "description": "Merges data and assigns decision scores."
            },
            "audit_logging": {
                "type": "squad", 
                "target": "audit", 
                "description": "Tracks actions and performs ethical auditing."
            },
            "memory_management": {
                "type": "squad", 
                "target": "memory", 
                "description": "Stores and retrieves system context."
            },
            "dashboard_control": {
                "type": "squad", 
                "target": "dashboard", 
                "description": "Provides live status and control interface."
            },
            "planner_sub_task": {
                "type": "squad", 
                "target": "planner_sub", 
                "description": "Forecasts long-term vision and adjusts strategy."
            },
            "survey_qa_process": {
                "type": "squad", 
                "target": "survey_qa", 
                "description": "Automates engineering survey data processing and QA/QC."
            },
            "construction_planning_task": {
                "type": "squad", 
                "target": "construction_planning", 
                "description": "Manages construction project planning, scheduling, and resource allocation."
            },
        }
        
        self.default_cluster = "general"
        print("Router: Initialized with advanced orchestration capabilities.")

    def route_command(self, parsed_command):
        """Enhanced command routing with dynamic orchestration"""
        start_time = time.time()
        task_type = parsed_command.get("task")
        details = parsed_command.get("details")
        context = parsed_command.get("context")

        route_config = self.task_routes.get(task_type)
        
        if not route_config:
            print(f"Router: No specific route for task type: {task_type}. Using dynamic routing.")
            return self._handle_dynamic_routing(task_type, details, context, start_time)

        if route_config["type"] == "dynamic":
            return self._handle_dynamic_routing(task_type, details, context, start_time, route_config)
        elif route_config["type"] == "squad":
            return self._handle_squad_routing(task_type, details, route_config, start_time)
        else:
            # Legacy LLM routing
            return self._handle_llm_routing(task_type, details, route_config, start_time)

    def _handle_dynamic_routing(self, task_type, details, context, start_time, route_config=None):
        """Handle dynamic routing using orchestration engine"""
        print(f"Router: Using dynamic orchestration for task: {task_type}")
        
        # Use orchestration engine to select optimal route
        optimal_route = self.orchestration_engine.select_optimal_route(task_type, details, context)
        
        if optimal_route and optimal_route['type'] == 'llm':
            # Use LLM clustering for optimal model selection
            optimal_model = self.llm_manager.get_optimal_model(task_type, context)
            
            if optimal_model:
                print(f"Router: Dynamic routing selected LLM: {optimal_model}")
                response, is_valid, confidence = self.llm_manager.get_llm_response(
                    model_name=optimal_model, 
                    prompt=details, 
                    task_type=task_type, 
                    context=context
                )
                
                # Calculate performance metrics
                response_time = time.time() - start_time
                success_rate = confidence if is_valid else 0.0
                
                # Record performance for future optimization
                self.orchestration_engine.record_route_performance(
                    optimal_route['id'], success_rate, response_time, task_type
                )
                
                scorecard = self.fusion_engine.fuse_signals({
                    "llm_confidence": confidence, 
                    "llm_validity": is_valid, 
                    "task_type": task_type,
                    "response_time": response_time,
                    "orchestration_used": True
                })
                
                return response, is_valid, confidence, scorecard
        
        # Fallback to squad routing if configured
        if route_config and route_config.get("fallback_squads"):
            for squad_name in route_config["fallback_squads"]:
                if squad_name in self.squad_instances:
                    print(f"Router: Falling back to squad: {squad_name}")
                    return self._execute_squad_task(squad_name, task_type, details, start_time)
        
        # Ultimate fallback - use general cluster
        print(f"Router: Using fallback general cluster for task: {task_type}")
        optimal_model = self.llm_manager.get_optimal_model("general", context)
        
        if optimal_model:
            response, is_valid, confidence = self.llm_manager.get_llm_response(
                model_name=optimal_model, 
                prompt=details, 
                task_type="general", 
                context=context
            )
            
            scorecard = self.fusion_engine.fuse_signals({
                "llm_confidence": confidence, 
                "llm_validity": is_valid, 
                "task_type": task_type,
                "fallback_used": True
            })
            
            return response, is_valid, confidence, scorecard
        
        return "Error: No suitable routing option found.", False, 0.0, {
            "success_probability": 0.0, 
            "cost_estimate": 0.0, 
            "risk_assessment": 1.0, 
            "overall_score": 0.0
        }

    def _handle_squad_routing(self, task_type, details, route_config, start_time):
        """Handle squad-specific routing"""
        squad_name = route_config["target"]
        description = route_config["description"]
        
        print(f"Router: Routing task '{task_type}' to Squad: {squad_name} ({description})")
        return self._execute_squad_task(squad_name, task_type, details, start_time)

    def _handle_llm_routing(self, task_type, details, route_config, start_time):
        """Handle legacy LLM routing"""
        llm_name = route_config["target"]
        description = route_config["description"]
        
        print(f"Router: Routing task '{task_type}' to LLM: {llm_name} ({description})")
        
        if self.llm_manager:
            response, is_valid, confidence = self.llm_manager.get_llm_response(
                llm_name, details, task_type=task_type
            )
            scorecard = self.fusion_engine.fuse_signals({
                "llm_confidence": confidence, 
                "llm_validity": is_valid, 
                "task_type": task_type
            })
            return response, is_valid, confidence, scorecard
        else:
            print("Router: LLMManager not initialized in Router.")
            return "Error: LLM manager not available.", False, 0.0, {
                "success_probability": 0.0, 
                "cost_estimate": 0.0, 
                "risk_assessment": 1.0, 
                "overall_score": 0.0
            }

    def _execute_squad_task(self, squad_name, task_type, details, start_time):
        """Execute task using specified squad"""
        squad_instance = self.squad_instances.get(squad_name)
        
        if not squad_instance:
            print(f"Router: Squad '{squad_name}' not found in instances.")
            return f"Error: Squad '{squad_name}' not found.", False, 0.0, {
                "success_probability": 0.0, 
                "cost_estimate": 0.0, 
                "risk_assessment": 1.0, 
                "overall_score": 0.0
            }

        # Handle special squad routing logic
        if squad_name == "survey_qa":
            return self._handle_survey_qa_routing(squad_instance, details, task_type, start_time)
        else:
            # Generic squad execution
            parsed_command = {"task": task_type, "details": details}
            response, is_valid, confidence, scorecard = squad_instance.execute(parsed_command)
            return response, is_valid, confidence, scorecard

    def _handle_survey_qa_routing(self, squad_instance, details, task_type, start_time):
        """Handle Survey QA specific routing logic"""
        sub_task = details.get("sub_task") if isinstance(details, dict) else None
        
        if sub_task == "ingest_csv":
            csv_path = details.get("csv_path")
            success, data = squad_instance.ingest_leica_csv(csv_path)
            response = f"Survey QA Ingestion: {'Success' if success else 'Failed'}"
            is_valid = success
            confidence = 1.0 if success else 0.0
            scorecard = self.fusion_engine.fuse_signals({
                "success": success, 
                "task_type": task_type, 
                "sub_task": sub_task
            })
            return response, is_valid, confidence, scorecard
            
        elif sub_task == "compare_design_asbuilt":
            design_csv_path = details.get("design_csv_path")
            asbuilt_csv_path = details.get("asbuilt_csv_path")
            success, results, overall_pass = squad_instance.compare_design_asbuilt(
                design_csv_path, asbuilt_csv_path
            )
            response = f"Survey QA Comparison: {'Success' if success else 'Failed'}. Overall Pass: {overall_pass}"
            is_valid = success
            confidence = 1.0 if success else 0.0
            scorecard = self.fusion_engine.fuse_signals({
                "success": success, 
                "overall_pass": overall_pass, 
                "task_type": task_type, 
                "sub_task": sub_task
            })
            return response, is_valid, confidence, scorecard
            
        elif sub_task == "generate_qa_report":
            job_name = details.get("job_name")
            deviation_results = details.get("deviation_results", [])
            success, report_path = squad_instance.generate_qa_report(job_name, deviation_results)
            response = f"Survey QA Report Generation: {'Success' if success else 'Failed'}. Report: {report_path}"
            is_valid = success
            confidence = 1.0 if success else 0.0
            scorecard = self.fusion_engine.fuse_signals({
                "success": success, 
                "report_path": report_path, 
                "task_type": task_type, 
                "sub_task": sub_task
            })
            return response, is_valid, confidence, scorecard
            
        elif sub_task == "render_view":
            view_type = details.get("view_type")
            data = details.get("data", {})
            rendered_path = squad_instance.render_view(view_type, data)
            response = f"Survey QA Render View: {rendered_path}"
            is_valid = True
            confidence = 1.0
            scorecard = self.fusion_engine.fuse_signals({
                "success": True, 
                "rendered_path": rendered_path, 
                "task_type": task_type, 
                "sub_task": sub_task
            })
            return response, is_valid, confidence, scorecard
        else:
            print(f"Router: Unknown Survey QA sub-task: {sub_task}")
            return f"Error: Unknown Survey QA sub-task: {sub_task}", False, 0.0, {
                "success_probability": 0.0, 
                "cost_estimate": 0.0, 
                "risk_assessment": 1.0, 
                "overall_score": 0.0
            }

    def get_routing_statistics(self):
        """Get routing performance statistics"""
        stats = {
            "orchestration_performance": {},
            "cluster_health": self.llm_manager.get_cluster_status(),
            "task_complexity_cache_size": len(self.orchestration_engine.task_complexity_cache),
            "route_performance_entries": {
                route_id: len(performance_data) 
                for route_id, performance_data in self.orchestration_engine.route_performance.items()
            }
        }
        
        # Calculate orchestration performance metrics
        for route_id, performance_data in self.orchestration_engine.route_performance.items():
            if performance_data:
                avg_success = sum(p['success_rate'] for p in performance_data) / len(performance_data)
                avg_response_time = sum(p['response_time'] for p in performance_data) / len(performance_data)
                stats["orchestration_performance"][route_id] = {
                    "average_success_rate": avg_success,
                    "average_response_time": avg_response_time,
                    "total_requests": len(performance_data)
                }
        
        return stats

    def optimize_routing(self):
        """Trigger routing optimization"""
        print("Router: Running routing optimization...")
        
        # Optimize LLM clusters
        self.llm_manager.optimize_clusters()
        
        # Update routing rules based on performance
        self._update_routing_rules()
        
        self.audit_layer.log({
            "type": "routing_optimization", 
            "timestamp": datetime.now().isoformat()
        })
        self.event_bus.publish("routing_optimization", {
            "timestamp": datetime.now().isoformat()
        })

    def _update_routing_rules(self):
        """Update routing rules based on performance history"""
        # This is a placeholder for more sophisticated rule updating logic
        # In a real implementation, you might:
        # 1. Analyze performance patterns
        # 2. Adjust weight distributions
        # 3. Update complexity thresholds
        # 4. Modify cluster assignments
        
        print("Router: Updating routing rules based on performance history")
        
        # Simple example: adjust performance weight based on overall system performance
        overall_performance = self._calculate_overall_performance()
        if overall_performance < 0.7:
            # Increase performance weight if system is underperforming
            self.orchestration_engine.routing_rules['performance_weight'] = min(
                self.orchestration_engine.routing_rules['performance_weight'] + 0.1, 
                0.6
            )
        elif overall_performance > 0.9:
            # Decrease performance weight if system is performing well, allow more exploration
            self.orchestration_engine.routing_rules['performance_weight'] = max(
                self.orchestration_engine.routing_rules['performance_weight'] - 0.05, 
                0.2
            )

    def _calculate_overall_performance(self):
        """Calculate overall system performance"""
        all_performance_data = []
        for performance_data in self.orchestration_engine.route_performance.values():
            all_performance_data.extend([p['success_rate'] for p in performance_data])
        
        if all_performance_data:
            return sum(all_performance_data) / len(all_performance_data)
        else:
            return 0.5  # Neutral performance if no data

