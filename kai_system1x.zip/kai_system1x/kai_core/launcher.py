

#!/usr/bin/env python3
"""
Advanced Kai System CLI Launcher

- Production-grade with config validation (pydantic, optional)
- Hot-reload config with SIGHUP
- PID file protection (single instance)
- Log rotation & optional JSON logs
- Healthcheck HTTP endpoint
- Smoke test mode (--test)
- Graceful shutdown & restart
"""

import os
import sys
import time
import signal
import logging
import argparse
import json
from datetime import datetime
from logging.handlers import RotatingFileHandler

# Optional config validation
try:
    from pydantic import BaseModel, ValidationError
except ImportError:
    BaseModel = object
    ValidationError = Exception

PID_FILE = "/tmp/kai_system.pid"
kai_instance = None
config_manager = None
running = True

def ensure_pidfile():
    if os.path.exists(PID_FILE):
        with open(PID_FILE) as f:
            old_pid = int(f.read().strip())
        # Check if process exists
        if os.path.exists(f"/proc/{old_pid}"):
            print(f"Another Kai System instance is running (PID: {old_pid})")
            sys.exit(1)
        else:
            os.remove(PID_FILE)
    with open(PID_FILE, "w") as f:
        f.write(str(os.getpid()))

def remove_pidfile():
    if os.path.exists(PID_FILE):
        os.remove(PID_FILE)

def setup_logging(log_level="INFO", json_logs=False):
    os.makedirs("kai_logs", exist_ok=True)
    file_handler = RotatingFileHandler("kai_logs/launcher.log", maxBytes=5 * 1024 * 1024, backupCount=5)
    if json_logs:
        formatter = logging.Formatter('{"ts": "%(asctime)s", "name": "%(name)s", "level": "%(levelname)s", "msg": "%(message)s"}')
    else:
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    file_handler.setFormatter(formatter)
    logging.basicConfig(
        level=log_level,
        handlers=[file_handler, logging.StreamHandler()]
    )

def signal_handler(sig, frame):
    global running
    print("\nKai System: Shutting down gracefully...")
    running = False
    if kai_instance:
        kai_instance.stop_services()
    remove_pidfile()
    sys.exit(0)

def hup_handler(sig, frame):
    print("Kai System: Reloading configuration (SIGHUP received)...")
    try:
        if config_manager:
            config_manager._load_config()
        if kai_instance and hasattr(kai_instance, "reload"):
            kai_instance.reload()
        print("Config reloaded.")
    except Exception as e:
        print(f"Failed to reload config: {e}")

def setup_signal_handlers():
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    signal.signal(signal.SIGHUP, hup_handler)

def parse_arguments():
    parser = argparse.ArgumentParser(description='Kai System Launcher')
    parser.add_argument('--config', type=str, help='Path to configuration file')
    parser.add_argument('--env-file', type=str, help='Path to .env file')
    parser.add_argument('--json-logs', action='store_true', help='Enable JSON formatted logs')
    parser.add_argument('--test', action='store_true', help='Run smoke test and exit')
    parser.add_argument('--health-port', type=int, default=8081, help='Healthcheck HTTP port')
    parser.add_argument('--headless', action='store_true', help='Run in headless mode (no GUI)')
    parser.add_argument('--daemon', action='store_true', help='Run as a daemon process')
    parser.add_argument('--enable-api', dest='api_enabled', action='store_true', help='Enable API server')
    parser.add_argument('--disable-api', dest='api_enabled', action='store_false', help='Disable API server')
    parser.set_defaults(api_enabled=None)
    parser.add_argument('--api-port', type=int, help='API server port')
    parser.add_argument('--api-host', type=str, help='API server host')
    parser.add_argument('--enable-auth', dest='api_enable_auth', action='store_true', help='Enable API authentication')
    parser.add_argument('--disable-auth', dest='api_enable_auth', action='store_false', help='Disable API authentication')
    parser.set_defaults(api_enable_auth=None)
    parser.add_argument('--api-key', type=str, help='API authentication key')
    parser.add_argument('--enable-cors', dest='api_cors_enabled', action='store_true', help='Enable API CORS')
    parser.add_argument('--disable-cors', dest='api_cors_enabled', action='store_false', help='Disable API CORS')
    parser.set_defaults(api_cors_enabled=None)
    parser.add_argument('--enable-voice', dest='voice_enabled', action='store_true', help='Enable voice interface')
    parser.add_argument('--disable-voice', dest='voice_enabled', action='store_false', help='Disable voice interface')
    parser.set_defaults(voice_enabled=None)
    parser.add_argument('--enable-dashboard', dest='dashboard_enabled', action='store_true', help='Enable dashboard')
    parser.add_argument('--disable-dashboard', dest='dashboard_enabled', action='store_false', help='Disable dashboard')
    parser.set_defaults(dashboard_enabled=None)
    parser.add_argument('--dashboard-port', type=int, help='Dashboard server port')
    parser.add_argument('--dashboard-host', type=str, help='Dashboard server host')
    parser.add_argument('--open-dashboard', action='store_true', help='Open dashboard in web browser after starting')
    parser.add_argument('--enable-monitoring', dest='monitoring_enabled', action='store_true', help='Enable performance monitoring')
    parser.add_argument('--disable-monitoring', dest='monitoring_enabled', action='store_false', help='Disable performance monitoring')
    parser.set_defaults(monitoring_enabled=None)
    parser.add_argument('--log-level', type=str, choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'], help='Logging level')
    parser.add_argument('--debug', dest='debug_mode', action='store_true', help='Enable debug mode')
    parser.add_argument('--no-debug', dest='debug_mode', action='store_false', help='Disable debug mode')
    parser.set_defaults(debug_mode=None)
    parser.add_argument('--ethics', dest='ethics_enabled', action='store_true', help='Enable ethics checks')
    parser.add_argument('--no-ethics', dest='ethics_enabled', action='store_false', help='Disable ethics checks')
    parser.set_defaults(ethics_enabled=None)
    parser.add_argument('--command', type=str, help='Execute a command and exit')
    parser.add_argument('--version', action='store_true', help='Show version information')
    return parser.parse_args()

def run_healthcheck_server(port):
    try:
        from flask import Flask, jsonify
    except ImportError:
        print("Flask is not installed. Healthcheck endpoint not available.")
        return
    app = Flask("kai_healthcheck")
    @app.route("/health")
    def health():
        return jsonify({"status": "ok", "time": datetime.utcnow().isoformat()})
    import threading
    threading.Thread(target=app.run, kwargs={"port": port, "host": "0.0.0.0"}, daemon=True).start()

def ensure_directories():
    dirs = [
        "kai_logs",
        "kai_reports",
        "kai_plans",
        "kai_data"
    ]
    for d in dirs:
        os.makedirs(d, exist_ok=True)

def load_config(args):
    global config_manager

    # Dynamically add kai_core to path if needed
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
    from kai_core.kai_logging import get_logger
    from kai_core.config import ConfigManager

    config_file = args.config if args.config else "kai_core/config.json"
    config_manager = ConfigManager(config_file)

    # Load .env if present
    if args.env_file and os.path.exists(args.env_file):
        with open(args.env_file, 'r') as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#'):
                    key, value = line.split('=', 1)
                    os.environ[key] = value
        config_manager._load_from_env()

    config = config_manager.get_config()

    # CLI overrides for all config sections (same as previous logic)
    if 'api' not in config:
        config['api'] = {}
    if args.api_enabled is not None:
        config['api']['enabled'] = args.api_enabled
    if args.api_port is not None:
        config['api']['port'] = args.api_port
    if args.api_host is not None:
        config['api']['host'] = args.api_host
    if args.api_enable_auth is not None:
        config['api']['enable_auth'] = args.api_enable_auth
    if args.api_key is not None:
        config['api']['api_key'] = args.api_key
    if args.api_cors_enabled is not None:
        config['api']['cors_enabled'] = args.api_cors_enabled

    if 'voice' not in config:
        config['voice'] = {}
    if args.voice_enabled is not None:
        config['voice']['enabled'] = args.voice_enabled

    if 'dashboard' not in config:
        config['dashboard'] = {}
    if args.dashboard_enabled is not None:
        config['dashboard']['enabled'] = args.dashboard_enabled
    if args.dashboard_port is not None:
        config['dashboard']['port'] = args.dashboard_port
    if args.dashboard_host is not None:
        config['dashboard']['host'] = args.dashboard_host

    if 'monitoring' not in config:
        config['monitoring'] = {}
    if args.monitoring_enabled is not None:
        config['monitoring']['enabled'] = args.monitoring_enabled
    if args.log_level is not None:
        config['monitoring']['log_level'] = args.log_level

    if 'system' not in config:
        config['system'] = {}
    if args.debug_mode is not None:
        config['system']['debug_mode'] = args.debug_mode
    if args.ethics_enabled is not None:
        config['system']['ethics_enabled'] = args.ethics_enabled

    # (Optional) Pydantic config validation
    class KaiConfigModel(BaseModel):
        # Add fields as needed for strict validation
        api: dict
        voice: dict
        dashboard: dict
        monitoring: dict
        system: dict

    try:
        KaiConfigModel(**config)
    except ValidationError as ve:
        print(f"Configuration error:\n{ve}")
        sys.exit(1)

    return config

def initialize_kai(config, args):
    global kai_instance
    from kai_core.kai import Kai
    kai_instance = Kai(
        enable_voice=config['voice'].get('enabled', True),
        enable_monitoring=config['monitoring'].get('enabled', True),
        enable_dashboard=config['dashboard'].get('enabled', True),
        dashboard_port=config['dashboard'].get('port', 8080),
        dashboard_host=config['dashboard'].get('host', "0.0.0.0"),
        enable_api=config['api'].get('enabled', True),
        api_port=config['api'].get('port', 5000),
        api_host=config['api'].get('host', "0.0.0.0"),
        api_enable_auth=config['api'].get('enable_auth', False),
        api_key=config['api'].get('api_key', ""),
        api_cors_enabled=config['api'].get('cors_enabled', True),
        debug_mode=config['system'].get('debug_mode', False)
    )
    return kai_instance

def start_services(kai, config, args):
    kai.start_services()
    dashboard_enabled = config['dashboard'].get('enabled', True)
    if dashboard_enabled and not args.headless:
        if hasattr(kai, 'dashboard') and hasattr(kai.dashboard, 'frontend') and kai.dashboard.frontend:
            kai.dashboard.frontend.start_server()
            if getattr(args, 'open_dashboard', False):
                kai.dashboard.frontend.open_dashboard()
        else:
            logging.warning("Dashboard frontend not available or not properly initialized")
    api_enabled = config['api'].get('enabled', True)
    if api_enabled and hasattr(kai, 'api_server') and kai.api_server:
        kai.api_server.start_server()

def run_command_mode(kai, args):
    if args.command:
        print(f"Executing command: {args.command}")
        result = kai.process_command(args.command)
        print(f"Result: {result}")
        return True
    return False

def run_interactive_mode(kai):
    print("\nKai System: Interactive mode")
    print("Enter commands or 'exit' to quit")
    print("-------------------------------")
    while running:
        try:
            command = input("\nKai> ")
            if command.lower() in ('exit', 'quit'):
                break
            elif command.strip():
                result = kai.process_command(command)
                if isinstance(result, dict):
                    print(f"Result: {result.get('response')}")
                    print(f"Success: {result.get('success')}, Confidence: {result.get('confidence')}")
                else:
                    print(f"Result: {result}")
        except KeyboardInterrupt:
            break
        except Exception as e:
            print(f"Error: {e}")
    return True

def run_daemon_mode():
    print("\nKai System: Running in daemon mode")
    print("Press Ctrl+C to stop")
    while running:
        try:
            time.sleep(1)
        except KeyboardInterrupt:
            break
    return True

def show_version():
    print("Kai System v1.0.0")
    print("Enhanced with Dynamic LLM Clustering and Orchestration")
    print("Copyright (c) 2025")
    return True

def run_smoke_test(kai):
    print("Kai System: Running smoke test...")
    try:
        status = kai.get_system_status()
        print("System status:", status)
        if status.get("system_health") == "operational":
            print("Smoke test passed.")
            return 0
        else:
            print("Smoke test failed: system_health != operational")
            return 1
    except Exception as e:
        print(f"Smoke test failed: {e}")
        return 2

def main():
    ensure_pidfile()
    ensure_directories()
    args = parse_arguments()
    setup_logging(log_level=args.log_level or "INFO", json_logs=getattr(args, "json_logs", False))
    setup_signal_handlers()
    run_healthcheck_server(getattr(args, "health_port", 8081))

    if args.version:
        remove_pidfile()
        return show_version()

    config = load_config(args)
    kai = initialize_kai(config, args)
    start_services(kai, config, args)

    if args.test:
        result = run_smoke_test(kai)
        remove_pidfile()
        sys.exit(result)
    elif args.command:
        run_command_mode(kai, args)
    elif args.daemon:
        run_daemon_mode()
    else:
        run_interactive_mode(kai)

    remove_pidfile()

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nKai System: Interrupted by user")
    except Exception as e:
        logging.error(f"Error in main: {e}", exc_info=True)
        print(f"Error: {e}")
    finally:
        if kai_instance:
            kai_instance.stop_services()
        remove_pidfile()
        print("\nKai System: Shutdown complete")
