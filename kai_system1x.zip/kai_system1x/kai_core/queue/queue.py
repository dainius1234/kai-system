"""
kai_core/queue/queue.py - Advanced, production-ready task queue and scheduler for Kai System.

- Thread-safe, multi-priority (high/medium/low) task queue.
- FIFO within each priority. Audited and event-published for all operations.
- Ready for extension: task deduplication, timeouts, rate limits, scheduled/run-at, etc.
"""

import heapq
import time
import threading

class TaskQueue:
    def __init__(self, event_bus, audit_layer):
        self.event_bus = event_bus
        self.audit_layer = audit_layer
        self.high_priority_queue = []  # (timestamp, task_id, task_details)
        self.medium_priority_queue = []
        self.low_priority_queue = []
        self.task_id_counter = 0
        self.lock = threading.RLock()
        print("TaskQueue: Initialized as command queue and scheduler.")

    def add_task(self, task_details, priority="medium"):
        with self.lock:
            self.task_id_counter += 1
            task_id = self.task_id_counter
            timestamp = time.time()
            task_entry = (timestamp, task_id, task_details)

            if priority == "high":
                heapq.heappush(self.high_priority_queue, task_entry)
            elif priority == "medium":
                heapq.heappush(self.medium_priority_queue, task_entry)
            elif priority == "low":
                heapq.heappush(self.low_priority_queue, task_entry)
            else:
                print(f"TaskQueue: Invalid priority {priority}. Defaulting to medium.")
                heapq.heappush(self.medium_priority_queue, task_entry)

            self.audit_layer.log({
                "type": "task_added_to_queue",
                "details": {"task_id": task_id, "priority": priority, "task_details": task_details}
            })
            self.event_bus.publish("queue_event", {
                "action": "task_added",
                "task_id": task_id,
                "priority": priority
            })
            print(f"TaskQueue: Added task {task_id} with {priority} priority.")
            return task_id

    def get_next_task(self):
        with self.lock:
            if self.high_priority_queue:
                priority = "high"
                _, task_id, task_details = heapq.heappop(self.high_priority_queue)
            elif self.medium_priority_queue:
                priority = "medium"
                _, task_id, task_details = heapq.heappop(self.medium_priority_queue)
            elif self.low_priority_queue:
                priority = "low"
                _, task_id, task_details = heapq.heappop(self.low_priority_queue)
            else:
                print("TaskQueue: No tasks in queue.")
                return None, None

            self.audit_layer.log({
                "type": "task_retrieved_from_queue",
                "details": {"task_id": task_id, "priority": priority, "task_details": task_details}
            })
            self.event_bus.publish("queue_event", {
                "action": "task_retrieved",
                "task_id": task_id,
                "priority": priority
            })
            print(f"TaskQueue: Retrieved task {task_id} from {priority} priority queue.")
            return task_id, task_details

    def get_queue_status(self):
        with self.lock:
            status = {
                "high_priority_count": len(self.high_priority_queue),
                "medium_priority_count": len(self.medium_priority_queue),
                "low_priority_count": len(self.low_priority_queue),
                "total_tasks": (
                    len(self.high_priority_queue) +
                    len(self.medium_priority_queue) +
                    len(self.low_priority_queue)
                )
            }
            print(f"TaskQueue: Current status: {status}")
            return status

    def execute(self, command_details):
        """
        Executes a queue-related command (add/get/status). Respects priorities.
        """
        details = command_details.get("details", "")
        details_lower = details.lower() if isinstance(details, str) else ""
        task = command_details.get("task")

        # Parse explicit priority if present (e.g., "add task ... with high priority")
        priority = "medium"
        if "high priority" in details_lower:
            priority = "high"
        elif "low priority" in details_lower:
            priority = "low"
        elif "medium priority" in details_lower:
            priority = "medium"

        if "add task" in details_lower:
            # Extract task description after "add task"
            import re
            match = re.search(r"add task\s*(.*?)(?:\s*with\s*(high|medium|low)\s*priority)?$", details_lower)
            task_to_add = match.group(1).strip() if match and match.group(1) else details
            task_id = self.add_task(task_to_add, priority)
            return (
                f"TaskQueue: Added task: {task_to_add} (ID: {task_id}, priority: {priority})",
                True, 1.0,
                {"success_probability": 1.0, "cost_estimate": 0.01, "risk_assessment": 0.0, "overall_score": 1.0}
            )
        elif "get next task" in details_lower:
            task_id, task_details = self.get_next_task()
            if task_id:
                return (
                    f"TaskQueue: Next task: {task_details} (ID: {task_id})",
                    True, 1.0,
                    {"success_probability": 1.0, "cost_estimate": 0.01, "risk_assessment": 0.0, "overall_score": 1.0}
                )
            else:
                return (
                    "TaskQueue: No tasks available.",
                    False, 0.5,
                    {"success_probability": 0.5, "cost_estimate": 0.01, "risk_assessment": 0.1, "overall_score": 0.4}
                )
        elif "status" in details_lower:
            status = self.get_queue_status()
            return (
                f"TaskQueue: Status: {status}",
                True, 1.0,
                {"success_probability": 1.0, "cost_estimate": 0.01, "risk_assessment": 0.0, "overall_score": 1.0}
            )
        else:
            return (
                "TaskQueue: Understood. Performing general queue tasks (simulated).",
                True, 0.8,
                {"success_probability": 0.8, "cost_estimate": 0.02, "risk_assessment": 0.1, "overall_score": 0.7}
            )
