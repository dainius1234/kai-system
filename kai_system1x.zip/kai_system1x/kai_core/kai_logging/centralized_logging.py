"""
kai_logging.py - Centralized logging system for the Kai System

This module provides a centralized logging system for the Kai System,
ensuring all logs are properly captured, formatted, and accessible.
"""

import os
import sys
import logging
import logging.handlers
import json
import threading
from datetime import datetime
from typing import Dict, Any, List, Optional, Union

# Default log directory
DEFAULT_LOG_DIR = "kai_logs"

# Log levels
LOG_LEVELS = {
    "DEBUG": logging.DEBUG,
    "INFO": logging.INFO,
    "WARNING": logging.WARNING,
    "ERROR": logging.ERROR,
    "CRITICAL": logging.CRITICAL
}

class KaiLogger:
    """
    Centralized logger for the Kai System.
    Provides unified logging across all modules with consistent formatting.
    """

    def __init__(self, log_dir: str = DEFAULT_LOG_DIR, log_level: str = "INFO"):
        self.log_dir = log_dir
        self.log_level = LOG_LEVELS.get(log_level.upper(), logging.INFO)
        os.makedirs(self.log_dir, exist_ok=True)
        self.loggers = {}
        self.system_logger = self._create_logger("system", self.log_level)
        self._initialize_module_loggers()

        # Live log buffer (for dashboard and API access)
        self.live_log_buffer = []
        self.max_buffer_size = 1000
        self.buffer_lock = threading.Lock()

        self.system_logger.info("Centralized logging system initialized")

    def _initialize_module_loggers(self):
        """Initialize loggers for all Kai System modules."""
        # Core modules
        core_modules = [
            "api", "webhook", "dashboard", "voice", "router", "llm", "memory",
            "config", "launcher"
        ]
        squad_modules = [
            "squad.trading", "squad.planner", "squad.legal", "squad.admin",
            "squad.accounting", "squad.intel", "squad.defense", "squad.offense",
            "squad.eco", "squad.prime", "squad.debug", "squad.ethics", "squad.construction"
        ]
        specialized_modules = ["survey_qa", "performance", "audit"]
        for name in core_modules + squad_modules + specialized_modules:
            self._create_logger(name, self.log_level)

    def _create_logger(self, name: str, level: int) -> logging.Logger:
        logger = logging.getLogger(f"kai.{name}")
        logger.setLevel(level)
        logger.propagate = False

        # File handler (module-specific log file)
        log_file = os.path.join(self.log_dir, f"{name}.log")
        file_handler = logging.handlers.RotatingFileHandler(
            log_file,
            maxBytes=10485760,  # 10MB
            backupCount=5
        )
        file_handler.setLevel(level)

        # Console handler
        console_handler = logging.StreamHandler()
        console_handler.setLevel(level)

        # Create formatters
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        file_handler.setFormatter(formatter)
        console_handler.setFormatter(formatter)

        # Add handlers
        if not any(isinstance(h, logging.handlers.RotatingFileHandler) for h in logger.handlers):
            logger.addHandler(file_handler)
        if not any(isinstance(h, logging.StreamHandler) for h in logger.handlers):
            logger.addHandler(console_handler)

        # Add custom handler for live log buffer
        if not any(isinstance(h, self._BufferHandler) for h in logger.handlers):
            buffer_handler = self._create_buffer_handler()
            logger.addHandler(buffer_handler)

        self.loggers[name] = logger
        return logger

    class _BufferHandler(logging.Handler):
        def __init__(self, parent):
            super().__init__()
            self.parent = parent

        def emit(self, record):
            try:
                log_entry = {
                    "timestamp": datetime.fromtimestamp(record.created).isoformat(),
                    "level": record.levelname,
                    "logger": record.name,
                    "message": record.getMessage(),
                    "module": record.module,
                    "line": record.lineno
                }
                with self.parent.buffer_lock:
                    self.parent.live_log_buffer.append(log_entry)
                    if len(self.parent.live_log_buffer) > self.parent.max_buffer_size:
                        self.parent.live_log_buffer = self.parent.live_log_buffer[-self.parent.max_buffer_size:]
            except Exception:
                pass

    def _create_buffer_handler(self):
        return self._BufferHandler(self)

    def get_logger(self, name: str) -> logging.Logger:
        if name in self.loggers:
            return self.loggers[name]
        else:
            return self._create_logger(name, self.log_level)

    def set_level(self, level: Union[str, int], logger_name: Optional[str] = None):
        if isinstance(level, str):
            level = LOG_LEVELS.get(level.upper(), logging.INFO)
        if logger_name:
            if logger_name in self.loggers:
                self.loggers[logger_name].setLevel(level)
                for handler in self.loggers[logger_name].handlers:
                    handler.setLevel(level)
        else:
            self.log_level = level
            for logger in self.loggers.values():
                logger.setLevel(level)
                for handler in logger.handlers:
                    handler.setLevel(level)

    def get_live_logs(self, limit: int = 100, level: Optional[str] = None, module: Optional[str] = None) -> List[Dict[str, Any]]:
        with self.buffer_lock:
            logs = self.live_log_buffer.copy()
        if level:
            logs = [log for log in logs if log["level"] == level.upper()]
        if module:
            logs = [log for log in logs if module.lower() in log["logger"].lower()]
        return logs[-limit:] if limit > 0 else logs

    def export_logs(self, output_file: str, start_time: Optional[datetime] = None,
                    end_time: Optional[datetime] = None, level: Optional[str] = None,
                    module: Optional[str] = None) -> bool:
        try:
            logs = []
            log_files = []
            if module:
                log_file = os.path.join(self.log_dir, f"{module}.log")
                if os.path.exists(log_file):
                    log_files.append(log_file)
            else:
                for file in os.listdir(self.log_dir):
                    if file.endswith(".log"):
                        log_files.append(os.path.join(self.log_dir, file))
            for log_file in log_files:
                with open(log_file, 'r') as f:
                    for line in f:
                        try:
                            parts = line.strip().split(' - ', 3)
                            if len(parts) >= 4:
                                timestamp_str = parts[0]
                                logger_name = parts[1]
                                log_level = parts[2]
                                message = parts[3]
                                timestamp = datetime.strptime(timestamp_str, '%Y-%m-%d %H:%M:%S,%f')
                                if start_time and timestamp < start_time:
                                    continue
                                if end_time and timestamp > end_time:
                                    continue
                                if level and log_level != level.upper():
                                    continue
                                if module and module.lower() not in logger_name.lower():
                                    continue
                                logs.append({
                                    "timestamp": timestamp.isoformat(),
                                    "logger": logger_name,
                                    "level": log_level,
                                    "message": message
                                })
                        except Exception:
                            continue
            logs.sort(key=lambda x: x["timestamp"])
            with open(output_file, 'w') as f:
                json.dump(logs, f, indent=2)
            return True
        except Exception as e:
            self.system_logger.error(f"Error exporting logs: {e}", exc_info=True)
            return False

    def clear_logs(self, module: Optional[str] = None) -> bool:
        try:
            if module:
                log_file = os.path.join(self.log_dir, f"{module}.log")
                if os.path.exists(log_file):
                    with open(log_file, 'w') as f:
                        pass
            else:
                for file in os.listdir(self.log_dir):
                    if file.endswith(".log"):
                        with open(os.path.join(self.log_dir, file), 'w') as f:
                            pass
            return True
        except Exception as e:
            self.system_logger.error(f"Error clearing logs: {e}", exc_info=True)
            return False

_kai_logger = None

def get_logger(name: str = "system") -> logging.Logger:
    global _kai_logger
    if _kai_logger is None:
        _kai_logger = KaiLogger()
    return _kai_logger.get_logger(name)

def set_log_level(level: Union[str, int], logger_name: Optional[str] = None):
    global _kai_logger
    if _kai_logger is None:
        _kai_logger = KaiLogger()
    _kai_logger.set_level(level, logger_name)

def get_live_logs(limit: int = 100, level: Optional[str] = None, module: Optional[str] = None) -> List[Dict[str, Any]]:
    global _kai_logger
    if _kai_logger is None:
        _kai_logger = KaiLogger()
    return _kai_logger.get_live_logs(limit, level, module)

def export_logs(output_file: str, start_time: Optional[datetime] = None,
                end_time: Optional[datetime] = None, level: Optional[str] = None,
                module: Optional[str] = None) -> bool:
    global _kai_logger
    if _kai_logger is None:
        _kai_logger = KaiLogger()
    return _kai_logger.export_logs(output_file, start_time, end_time, level, module)

def clear_logs(module: Optional[str] = None) -> bool:
    global _kai_logger
    if _kai_logger is None:
        _kai_logger = KaiLogger()
    return _kai_logger.clear_logs(module)

# Create a global KaiLogger instance on import for immediate access.
_kai_logger = KaiLogger()
