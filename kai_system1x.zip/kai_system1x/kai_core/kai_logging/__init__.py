"""
__init__.py - Initialize the logging package for the Kai System.

This package exposes the centralized logging interface,
providing unified logging functions for all Kai modules.
"""

from kai_core.kai_logging import (
    get_logger,
    set_log_level,
    get_live_logs,
    export_logs,
    clear_logs
)
