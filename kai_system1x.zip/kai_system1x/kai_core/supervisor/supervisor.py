import time
import logging

class Supervisor:
    """
    Supervisor: Robust process supervision and orchestration layer.

    - Monitors and manages subordinate processes, agents, or microservices.
    - Health checks, restarts, and isolation of unhealthy or compromised processes.
    - Coordinates with a "junior agent" for deeper self-repair, diagnostics, or auto-remediation.
    - Publishes audit and event logs for all actions.
    - Ready for API, CLI, or event-driven integration.
    - Thread-safe; supports concurrent supervision.
    """

    def __init__(self, event_bus, audit_layer, junior_agent, logger=None):
        self.event_bus = event_bus
        self.audit_layer = audit_layer
        self.junior_agent = junior_agent
        self.monitored_processes = {}   # {name: {"object": process_obj, "type": "thread"/"process", ...}}
        self.logger = logger or logging.getLogger("Supervisor")
        self.status = {
            "monitored": set(),
            "last_action": None,
            "last_result": None,
            "last_check": None,
            "alerts_sent": 0,
            "incidents": 0,
        }
        self._stop_tracking = False
        self._tracker_thread = None
        self.logger.info("Supervisor: Initialized as supervision tree.")

    def add_process_to_monitor(self, process_name, process_object, process_type="thread"):
        """
        Register a process/thread for monitoring.
        process_type: "thread" or "process"
        """
        self.monitored_processes[process_name] = {
            "object": process_object,
            "type": process_type,
            "name": process_name,
        }
        self.status["monitored"].add(process_name)
        self.logger.info(f"Supervisor: Added {process_name} ({process_type}) to monitoring list.")
        self.audit_layer.log({
            "type": "process_added",
            "details": {"process": process_name, "process_type": process_type, "time": time.time()}
        })

    def remove_process_from_monitor(self, process_name):
        if process_name in self.monitored_processes:
            self.monitored_processes.pop(process_name)
            self.status["monitored"].discard(process_name)
            self.logger.info(f"Supervisor: Removed {process_name} from monitoring list.")
            self.audit_layer.log({
                "type": "process_removed",
                "details": {"process": process_name, "time": time.time()}
            })

    def check_process_health(self, process_name):
        """
        Perform a health check for the given process.
        Returns True if healthy, False otherwise.
        """
        entry = self.monitored_processes.get(process_name)
        if not entry:
            self.logger.warning(f"Supervisor: Process {process_name} not found for health check.")
            return False
        obj = entry["object"]
        typ = entry["type"]
        is_healthy = False
        if typ == "thread":
            is_healthy = getattr(obj, "is_alive", lambda: False)()
        elif typ == "process":
            is_healthy = getattr(obj, "is_alive", lambda: False)()
        elif hasattr(obj, "health_check"):
            is_healthy = obj.health_check()
        else:
            self.logger.warning(f"Supervisor: Unknown process type for {process_name}.")
        self.logger.info(f"Supervisor: Checking health of {process_name}: {'Healthy' if is_healthy else 'Unhealthy'}")
        self.audit_layer.log({
            "type": "process_health_check",
            "details": {"process": process_name, "healthy": is_healthy, "time": time.time()}
        })
        self.status["last_check"] = time.time()
        return is_healthy

    def restart_process(self, process_name):
        """
        Attempt to restart a process (requires the process object to implement .restart() or similar).
        If restart fails, escalate to Junior Agent for self-repair.
        """
        entry = self.monitored_processes.get(process_name)
        if not entry:
            self.logger.warning(f"Supervisor: Process {process_name} not found for restart.")
            return False
        obj = entry["object"]
        self.logger.info(f"Supervisor: Attempting to restart {process_name}...")
        self.audit_layer.log({"type": "process_restart_attempt", "details": {"process": process_name, "time": time.time()}})
        self.event_bus.publish("process_event", {"process": process_name, "status": "restarting"})
        # Try to call a restart method, else log error
        success = False
        try:
            if hasattr(obj, "restart"):
                obj.restart()
                time.sleep(1)
                if self.check_process_health(process_name):
                    self.logger.info(f"Supervisor: {process_name} restarted successfully.")
                    self.event_bus.publish("process_event", {"process": process_name, "status": "restarted"})
                    success = True
            elif hasattr(obj, "start") and hasattr(obj, "terminate"):
                obj.terminate()
                obj.start()
                time.sleep(1)
                if self.check_process_health(process_name):
                    self.logger.info(f"Supervisor: {process_name} started via terminate/start.")
                    self.event_bus.publish("process_event", {"process": process_name, "status": "restarted"})
                    success = True
            else:
                self.logger.error(f"Supervisor: {process_name} does not support restart operations.")
        except Exception as e:
            self.logger.error(f"Supervisor: Exception during restart of {process_name}: {e}")

        if not success:
            self.logger.error(f"Supervisor: {process_name} failed to restart. Escalating to Junior.")
            self.status["incidents"] += 1
            self.junior_agent.trigger_self_repair(process_name, "failed_to_restart")
            self.event_bus.publish("process_event", {"process": process_name, "status": "restart_failed_escalated"})
        return success

    def isolate_process(self, process_name):
        """
        Isolate a process (quarantine, suspend, or block).
        Delegates to Junior Agent for actual isolation logic.
        """
        entry = self.monitored_processes.get(process_name)
        if not entry:
            self.logger.warning(f"Supervisor: Process {process_name} not found for isolation.")
            return False
        self.logger.info(f"Supervisor: Isolating {process_name}...")
        self.audit_layer.log({"type": "process_isolation", "details": {"process": process_name, "time": time.time()}})
        self.event_bus.publish("process_event", {"process": process_name, "status": "isolating"})
        self.junior_agent.handle_quarantine_logic(process_name, "isolation_requested_by_supervisor")
        time.sleep(0.1)
        self.logger.info(f"Supervisor: {process_name} isolated (quarantine requested).")
        self.event_bus.publish("process_event", {"process": process_name, "status": "isolated"})
        return True

    def coordinate_with_junior(self, process_name, issue_details):
        """
        Actively ask Junior Agent to handle a process issue.
        """
        self.logger.info(f"Supervisor: Coordinating with Junior for {process_name} issue: {issue_details}")
        self.junior_agent.trigger_self_repair(process_name, issue_details)
        self.status["last_action"] = f"Coordinated repair for {process_name}"

    def start_background_supervision(self, interval=30):
        """
        Start background thread to periodically check all monitored processes.
        """
        if self._tracker_thread and self._tracker_thread.is_alive():
            self.logger.info("Supervisor: Background supervision already running.")
            return
        self._stop_tracking = False
        def tracker():
            while not self._stop_tracking:
                for pname in list(self.monitored_processes.keys()):
                    healthy = self.check_process_health(pname)
                    if not healthy:
                        self.logger.warning(f"Supervisor: {pname} unhealthy. Attempting auto-restart.")
                        self.restart_process(pname)
                time.sleep(interval)
        self._tracker_thread = threading.Thread(target=tracker, daemon=True)
        self._tracker_thread.start()
        self.logger.info("Supervisor: Background supervision started.")

    def stop_background_supervision(self):
        self._stop_tracking = True
        self.logger.info("Supervisor: Background supervision stopped.")

    def get_status(self):
        """
        Return a status dictionary for UI, dashboard, or monitoring API.
        """
        return {
            "monitored_processes": list(self.monitored_processes.keys()),
            "last_action": self.status["last_action"],
            "last_result": self.status["last_result"],
            "last_check": self.status["last_check"],
            "alerts_sent": self.status["alerts_sent"],
            "incidents": self.status["incidents"]
        }

    def execute(self, command_details):
        """
        Unified entry for supervisor actions (API, CLI, Router, etc).
        """
        task = command_details.get("task", "")
        details = command_details.get("details", "")

        if "check health" in details.lower():
            process_name = details.split("check health of ")[-1].strip()
            is_healthy = self.check_process_health(process_name)
            status = "healthy" if is_healthy else "unhealthy"
            return (
                f"Supervisor: Process {process_name} is {status}.",
                True,
                1.0,
                {
                    "success_probability": 1.0,
                    "cost_estimate": 0.01,
                    "risk_assessment": 0.0,
                    "overall_score": 1.0,
                },
            )
        elif "restart" in details.lower():
            process_name = details.split("restart ")[-1].strip()
            success = self.restart_process(process_name)
            status = "restarted" if success else "failed to restart"
            return (
                f"Supervisor: Process {process_name} {status}.",
                success,
                1.0 if success else 0.5,
                {
                    "success_probability": 1.0 if success else 0.5,
                    "cost_estimate": 0.05,
                    "risk_assessment": 0.2,
                    "overall_score": 0.8 if success else 0.4,
                },
            )
        elif "isolate" in details.lower():
            process_name = details.split("isolate ")[-1].strip()
            success = self.isolate_process(process_name)
            return (
                f"Supervisor: Process {process_name} isolated.",
                success,
                1.0 if success else 0.5,
                {
                    "success_probability": 1.0 if success else 0.0,
                    "cost_estimate": 0.03,
                    "risk_assessment": 0.1,
                    "overall_score": 0.9 if success else 0.3,
                },
            )
        elif "remove" in details.lower():
            process_name = details.split("remove ")[-1].strip()
            self.remove_process_from_monitor(process_name)
            return f"Supervisor: Process {process_name} removed from monitoring.", True, 1.0, {}
        elif "status" in details.lower():
            return self.get_status(), True, 1.0, {}
        else:
            return (
                "Supervisor: Understood. Performing general supervision tasks.",
                True,
                0.8,
                {
                    "success_probability": 0.8,
                    "cost_estimate": 0.02,
                    "risk_assessment": 0.1,
                    "overall_score": 0.7,
                },
            )
