"""
EnvironmentLibraries - Manages Kai's standardized environments and their metadata.

- Keeps track of all environments (coding, learning, trading, legal, etc.)
- Provides per-environment metadata (description, icon, last_updated, etc.)
- Optionally integrates tool listings from ToolManager.
- Supports metadata from environment-level 'env.yaml' or 'env.json' files.

Author: dainius1234
Copyright: (c) 2025
"""

import os
import json
from datetime import datetime
from typing import Dict, Optional, List

try:
    import yaml
except ImportError:
    yaml = None

# Standard Kai Environments
KAI_ENVIRONMENTS = [
    "coding",
    "office",
    "engineering",
    "survey",
    "training",
    "accounting",
    "learning",
    "trading",
    "legal",
    "admin",
    "intel",
    "defense",
    "offense",
    "eco",
    "prime",
    "debug",
    "planner_sub",
    "construction_planning",
    "engineering_squad"
]

ENV_METADATA_FILENAMES = ["env.yaml", "env.json"]

class EnvironmentLibraries:
    """
    Manages metadata and indexing for all Kai environments.
    """

    def __init__(self, env_root: str, event_bus=None, audit_layer=None, memory=None, tool_manager=None):
        """
        env_root: Path to the /env directory (e.g., './env')
        tool_manager: (optional) ToolManager instance for listing tools in environments
        """
        self.env_root = env_root
        self.event_bus = event_bus
        self.audit_layer = audit_layer
        self.memory = memory
        self.tool_manager = tool_manager
        self.environments = KAI_ENVIRONMENTS.copy()
        self.env_metadata: Dict[str, Dict] = {}
        self._ensure_env_folders()
        self.refresh()

    def _ensure_env_folders(self):
        """Ensure all standard environments exist as folders under env_root."""
        if not os.path.exists(self.env_root):
            os.makedirs(self.env_root)
        for env in self.environments:
            env_path = os.path.join(self.env_root, env)
            if not os.path.exists(env_path):
                os.makedirs(env_path)

    def refresh(self):
        """Re-scan and index all environments for metadata."""
        self.env_metadata = {}
        for env in self.environments:
            env_path = os.path.join(self.env_root, env)
            metadata = self._load_env_metadata(env_path)
            metadata.setdefault("name", env)
            metadata.setdefault("path", env_path)
            metadata.setdefault("last_updated", self._get_last_updated(env_path))
            # Optionally, include tool listing if ToolManager present
            if self.tool_manager and hasattr(self.tool_manager, "list_tools"):
                try:
                    metadata["tools"] = self.tool_manager.list_tools(env)
                except Exception:
                    metadata["tools"] = []
            self.env_metadata[env] = metadata

    def _load_env_metadata(self, env_path: str) -> Dict:
        """
        Load environment metadata from env.yaml or env.json if present.
        """
        meta = {}
        for filename in ENV_METADATA_FILENAMES:
            meta_file = os.path.join(env_path, filename)
            if os.path.exists(meta_file):
                try:
                    if filename.endswith(".yaml") and yaml:
                        with open(meta_file, "r") as f:
                            loaded = yaml.safe_load(f)
                            if isinstance(loaded, dict):
                                meta.update(loaded)
                    elif filename.endswith(".json"):
                        with open(meta_file, "r") as f:
                            loaded = json.load(f)
                            if isinstance(loaded, dict):
                                meta.update(loaded)
                except Exception:
                    continue
        return meta

    def _get_last_updated(self, env_path: str) -> str:
        """Get last modified time for the environment folder (as ISO string)."""
        try:
            return datetime.utcfromtimestamp(os.path.getmtime(env_path)).isoformat()
        except Exception:
            return ""

    def list_environments(self) -> List[str]:
        """List all environment names."""
        return self.environments

    def get_metadata(self, env: str) -> Dict:
        """Return metadata for a given environment."""
        return self.env_metadata.get(env, {})

    def list_environments_with_metadata(self) -> List[Dict]:
        """List all environments with their metadata."""
        return [self.env_metadata[env] for env in self.environments]

    def get_environment_path(self, env: str) -> Optional[str]:
        """Get the filesystem path for a given environment."""
        meta = self.env_metadata.get(env, {})
        return meta.get("path")

    def get_tools(self, env: str) -> List[Dict]:
        """Get tool list for an environment if ToolManager is linked."""
        meta = self.env_metadata.get(env, {})
        return meta.get("tools", [])

    def set_metadata(self, env: str, metadata: Dict):
        """Update metadata for an environment and save to env.yaml (if possible)."""
        env_path = os.path.join(self.env_root, env)
        yaml_path = os.path.join(env_path, "env.yaml")
        if yaml:
            try:
                with open(yaml_path, "w") as f:
                    yaml.safe_dump(metadata, f)
                self.refresh()
                return True
            except Exception:
                pass
        return False

    def _log_action(self, message: str, error: bool = False):
        """Log actions to audit layer and event bus."""
        log_entry = {
            "event": "environment_libraries_action",
            "message": message,
            "timestamp": datetime.now().isoformat(),
            "level": "error" if error else "info"
        }
        if self.audit_layer:
            self.audit_layer.log(log_entry)
        if self.event_bus:
            self.event_bus.publish("environment_libraries_log", log_entry)