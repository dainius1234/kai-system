

import json
import os
import threading
import logging
from typing import Any, Dict, Optional

class Memory:
    """
    Thread-safe persistent key-value store using a JSON file.
    """
    def __init__(self, memory_file: str = 'kai_memory.json'):
        """
        Initialize the Memory object and load data from the file if it exists.
        """
        self.memory_file = memory_file
        self.lock = threading.Lock()
        self.data = self._load_memory()
        self.logger = logging.getLogger("kai_core.memory")
        
    def _load_memory(self) -> Dict[str, Any]:
        """
        Load data from the memory file. If file is corrupted, backs up and starts fresh.
        """
        if os.path.exists(self.memory_file):
            try:
                with open(self.memory_file, 'r') as f:
                    return json.load(f)
            except Exception as e:
                backup_file = self.memory_file + ".bak"
                os.rename(self.memory_file, backup_file)
                self.logger.error(f"Corrupted memory file. Backed up to {backup_file}. Error: {e}")
        return {}

    def _save_memory(self) -> None:
        """
        Save the current data to the memory file atomically.
        """
        tmp_file = self.memory_file + ".tmp"
        with self.lock:
            with open(tmp_file, 'w') as f:
                json.dump(self.data, f, indent=4)
            os.replace(tmp_file, self.memory_file)
            self.logger.debug(f"Memory saved to {self.memory_file}")

    def get(self, key: str, default: Optional[Any] = None) -> Any:
        """
        Get a value by key, or return default if not found.
        """
        return self.data.get(key, default)

    def set(self, key: str, value: Any) -> None:
        """
        Set a value by key and persist the change.
        """
        with self.lock:
            self.data[key] = value
            self._save_memory()

    def delete(self, key: str) -> None:
        """
        Delete a key from memory and persist the change.
        """
        with self.lock:
            if key in self.data:
                del self.data[key]
                self._save_memory()

    def clear(self) -> None:
        """
        Clear all memory and persist the change.
        """
        with self.lock:
            self.data.clear()
            self._save_memory()

    def keys(self):
        """
        Return all keys in memory.
        """
        return list(self.data.keys())

    def items(self):
        """
        Return all items in memory.
        """
        return self.data.items()

    def load_paths(self) -> Dict[str, Any]:
        """
        Convenience method to get 'paths' from memory.
        """
        return self.get('paths', {})

    def save_paths(self, paths: Dict[str, Any]) -> None:
        """
        Convenience method to set 'paths' in memory.
        """
        self.set('paths', paths)
