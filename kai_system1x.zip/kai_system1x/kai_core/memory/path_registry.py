

import os
import threading
from datetime import datetime
from typing import Dict, Any
from kai_core.memory.memory import Memory
import logging

class PathRegistry:
    """
    Manages named filesystem paths with descriptions and timestamps, 
    persisting them using a Memory instance.
    Thread-safe and robust for production use.
    """
    def __init__(self, memory_instance: Memory):
        if not isinstance(memory_instance, Memory):
            raise TypeError("memory_instance must be an instance of Memory class")
        self.memory = memory_instance
        self._lock = threading.Lock()
        self._paths = self.memory.load_paths()
        self.logger = logging.getLogger("kai_core.memory.path_registry")

    def register_path(self, key: str, path: str, description: str = "") -> None:
        """
        Adds or updates a path in the registry.
        """
        if not isinstance(key, str) or not key:
            raise ValueError("Key must be a non-empty string")
        if not isinstance(path, str) or not path:
            raise ValueError("Path must be a non-empty string")
        
        absolute_path = os.path.abspath(path)
        # Optionally: check if path exists
        # if not os.path.exists(absolute_path):
        #     self.logger.warning(f"Registering non-existent path: {absolute_path}")
        
        with self._lock:
            self._paths[key] = {
                "path": absolute_path,
                "description": description,
                "registered_at": datetime.now().isoformat()
            }
            self.save_paths()
        self.logger.info(f"Path registered: {key} -> {absolute_path}")

    def get_path(self, key: str) -> str:
        """
        Retrieves a registered path by key.
        """
        with self._lock:
            if key not in self._paths:
                self.logger.error(f"Key not found: {key}")
                raise KeyError(f"Path with key '{key}' not found in registry.")
            return self._paths[key]["path"]

    def update_path(self, key: str, new_path: str) -> None:
        """
        Updates the path for an existing key.
        """
        with self._lock:
            if key not in self._paths:
                self.logger.error(f"Key not found for update: {key}")
                raise KeyError(f"Path with key '{key}' not found in registry.")
            if not isinstance(new_path, str) or not new_path:
                raise ValueError("New path must be a non-empty string")
            absolute_path = os.path.abspath(new_path)
            self._paths[key]["path"] = absolute_path
            self._paths[key]["updated_at"] = datetime.now().isoformat()
            self.save_paths()
        self.logger.info(f"Path updated: {key} -> {absolute_path}")

    def delete_path(self, key: str) -> None:
        """
        Deletes a path from the registry.
        """
        with self._lock:
            if key in self._paths:
                del self._paths[key]
                self.save_paths()
                self.logger.info(f"Path deleted: {key}")
            else:
                self.logger.warning(f"Attempted to delete non-existent key: {key}")

    def list_paths(self) -> Dict[str, Any]:
        """
        Returns all registered paths.
        """
        with self._lock:
            return dict(self._paths)  # Return a copy

    def save_paths(self) -> None:
        """
        Persists the current paths to memory.
        """
        self.memory.save_paths(self._paths)
