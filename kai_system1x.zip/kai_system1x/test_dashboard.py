import sys
import os
import copy

# Add the parent directory of kai_core to the Python path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from kai_core.kai import Kai
from kai_core.dashboard.dashboard import KaiDashboard

def test_dashboard_integration():
    print("\n--- Starting Dashboard Integration Test ---")

    # Initialize Kai (without voice and monitoring for simpler testing)
    kai_instance = Kai(enable_voice=False, enable_monitoring=False)
    print("Kai instance initialized.")

    # Start Kai services (this will also start the dashboard GUI placeholder)
    kai_instance.start_services()
    print("Kai services started.")

    # Get the dashboard instance from Kai
    dashboard = kai_instance.dashboard
    if not dashboard:
        print("Error: Dashboard not initialized in Kai instance.")
        return
    print("Dashboard instance retrieved from Kai.")

    # Test updating metrics
    print("\n--- Testing Dashboard Metric Update ---")
    initial_metrics = copy.deepcopy(dashboard.get_dashboard_data()["metrics"])
    print(f"Initial metrics: {initial_metrics}")

    # Simulate a successful command execution
    successful_scorecard = {"success_probability": 0.9, "overall_score": 0.8, "squad_name": "engineering"}
    dashboard.update_metrics(successful_scorecard)
    print("Simulated successful command.")

    updated_metrics_success = copy.deepcopy(dashboard.get_dashboard_data()["metrics"])
    print(f"Metrics after success: {updated_metrics_success}")

    assert updated_metrics_success["command_count"] == initial_metrics["command_count"] + 1
    assert updated_metrics_success["success_count"] == initial_metrics["success_count"] + 1
    print("Metric update for success: PASSED")

    # Simulate a failed command execution
    failed_scorecard = {"success_probability": 0.1, "overall_score": 0.2, "squad_name": "debug"}
    dashboard.update_metrics(failed_scorecard)
    print("Simulated failed command.")

    updated_metrics_fail = dashboard.get_dashboard_data()["metrics"]
    print(f"Metrics after failure: {updated_metrics_fail}")

    print(f"updated_metrics_success[command_count]: {updated_metrics_success['command_count']}")
    print(f"updated_metrics_fail[command_count]: {updated_metrics_fail['command_count']}")
    print(f"Expected updated_metrics_fail[command_count]: {updated_metrics_success['command_count'] + 1}")

    assert updated_metrics_fail["command_count"] == initial_metrics["command_count"] + 2
    assert updated_metrics_fail["error_count"] == updated_metrics_success["error_count"] + 1
    assert updated_metrics_fail["squad_activity"]["debug"] == initial_metrics["squad_activity"].get("debug", 0) + 1
    print("Metric update for failure: PASSED")

    # Test processing a command through the dashboard
    print("\n--- Testing Command Processing via Dashboard ---")
    command_to_process = "accounting generate report"
    print(f"Sending command to dashboard: '{command_to_process}'")
    
    # The dashboard's process_dashboard_command now calls kai_instance.process_command
    response_from_dashboard = dashboard.process_dashboard_command(command_to_process)
    print(f"Response from dashboard: {response_from_dashboard}")

    assert response_from_dashboard["success"] is not None # Check if a response was received
    assert "response" in response_from_dashboard # Check if response key exists
    print("Command processing via dashboard: PASSED")

    # Stop Kai services
    kai_instance.stop_services()
    print("Kai services stopped.")

    print("\n--- Dashboard Integration Test Complete ---")

if __name__ == "__main__":
    test_dashboard_integration()


