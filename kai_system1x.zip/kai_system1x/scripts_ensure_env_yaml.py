"""
Algorithm for Ensuring All Kai Environments Have Proper env.yaml Files

This script guarantees every Kai environment directory has a valid env.yaml
with required metadata, and updates incomplete files. Intended for use after
deploying or reorganizing Kai environments.
"""

import os
import yaml

kai_environments = [
    "coding", "office", "engineering", "survey", "training", "accounting", "learning",
    "trading", "legal", "admin", "intel", "defense", "offense", "eco", "prime",
    "debug", "planner_sub", "construction_planning", "engineering_squad"
]

default_metadata = {
    "coding": {
        "description": "Programming environments, IDEs, code editors, and developer tools.",
        "icon": "💻",
        "tags": ["development", "programming", "IDE"]
    },
    "office": {
        "description": "Productivity tools for documents, spreadsheets, and collaboration.",
        "icon": "🏢",
        "tags": ["office", "productivity", "documents"]
    },
    "engineering": {
        "description": "Tools for engineering calculations, simulation, and design.",
        "icon": "🛠️",
        "tags": ["engineering", "simulation", "design"]
    },
    "survey": {
        "description": "Surveying and geospatial data processing environments.",
        "icon": "📐",
        "tags": ["survey", "geospatial", "mapping"]
    },
    "training": {
        "description": "Environments for agent training and evaluation.",
        "icon": "🏋️",
        "tags": ["training", "evaluation", "learning"]
    },
    "accounting": {
        "description": "Accounting and financial record-keeping environments.",
        "icon": "📒",
        "tags": ["accounting", "finance", "records"]
    },
    "learning": {
        "description": "Learning management and educational environments.",
        "icon": "📚",
        "tags": ["learning", "education", "lms"]
    },
    "trading": {
        "description": "Financial trading and market analysis environments.",
        "icon": "💹",
        "tags": ["trading", "markets", "finance"]
    },
    "legal": {
        "description": "Legal research and compliance environments.",
        "icon": "⚖️",
        "tags": ["legal", "compliance", "law"]
    },
    "admin": {
        "description": "System administration and configuration environments.",
        "icon": "🛡️",
        "tags": ["admin", "system", "configuration"]
    },
    "intel": {
        "description": "Intelligence gathering and analysis environments.",
        "icon": "🕵️",
        "tags": ["intel", "analysis", "osint"]
    },
    "defense": {
        "description": "Cyber defense and monitoring environments.",
        "icon": "🛡️",
        "tags": ["defense", "security", "monitoring"]
    },
    "offense": {
        "description": "Penetration testing and red teaming environments.",
        "icon": "⚔️",
        "tags": ["offense", "redteam", "pentest"]
    },
    "eco": {
        "description": "Environmental monitoring and sustainability environments.",
        "icon": "🌱",
        "tags": ["eco", "environment", "sustainability"]
    },
    "prime": {
        "description": "Strategic planning and high-level decision environments.",
        "icon": "👑",
        "tags": ["prime", "strategy", "planning"]
    },
    "debug": {
        "description": "Debugging and troubleshooting environments.",
        "icon": "🐞",
        "tags": ["debug", "troubleshooting", "testing"]
    },
    "planner_sub": {
        "description": "Subordinate planning and task breakdown environments.",
        "icon": "📅",
        "tags": ["planner_sub", "planning", "tasks"]
    },
    "construction_planning": {
        "description": "Construction project planning and resource allocation.",
        "icon": "🏗️",
        "tags": ["construction", "planning", "projects"]
    },
    "engineering_squad": {
        "description": "Engineering squad operations and coordination.",
        "icon": "🤖",
        "tags": ["engineering_squad", "coordination", "operations"]
    }
}

def ensure_env_yaml(env_root="./env"):
    for env in kai_environments:
        env_path = os.path.join(env_root, env)
        os.makedirs(env_path, exist_ok=True)
        yaml_path = os.path.join(env_path, "env.yaml")
        meta = {
            "name": env,
            "description": default_metadata.get(env, {}).get("description", f"Environment for {env}."),
            "icon": default_metadata.get(env, {}).get("icon", "🧩"),
            "tags": default_metadata.get(env, {}).get("tags", [env])
        }
        if not os.path.exists(yaml_path):
            with open(yaml_path, "w") as f:
                yaml.safe_dump(meta, f)
        else:
            # Validate and update existing env.yaml if needed
            with open(yaml_path, "r") as f:
                try:
                    current = yaml.safe_load(f) or {}
                except Exception:
                    current = {}
            updated = False
            for k in ["name", "description", "icon", "tags"]:
                if k not in current or current[k] in [None, '', []]:
                    current[k] = meta[k]
                    updated = True
            if updated:
                with open(yaml_path, "w") as f:
                    yaml.safe_dump(current, f)

if __name__ == "__main__":
    ensure_env_yaml()
    print("All Kai environment env.yaml files checked and updated.")